import { ClientOnly, createFileRoute } from "@tanstack/react-router";
import { lazy, Suspense } from "react";

// The 3D experience needs WebGL and window, so it loads only in the browser.
const Experience = lazy(() => import("@/experience/Experience"));

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "QUANTUM FRONTIER — Jump to the Moon or Mars" },
      {
        name: "description",
        content:
          "Put on a spacesuit, jump to the Moon or Mars, and walk the surface to discover the real spacecraft left behind — from Surveyor 3 and the Apollo Moon Buggy to Viking, InSight and Ingenuity.",
      },
      { property: "og:title", content: "QUANTUM FRONTIER — Jump to the Moon or Mars" },
      {
        property: "og:description",
        content: "Walk the Moon and Mars in first person and discover eight real spacecraft left behind by their missions.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Loading() {
  return (
    <main className="fixed inset-0 grid place-items-center bg-[#020308]">
      <div className="hud-label animate-breathe">Pressurising airlock…</div>
    </main>
  );
}

function Index() {
  return (
    <ClientOnly fallback={<Loading />}>
      <Suspense fallback={<Loading />}>
        <Experience />
      </Suspense>
    </ClientOnly>
  );
}
