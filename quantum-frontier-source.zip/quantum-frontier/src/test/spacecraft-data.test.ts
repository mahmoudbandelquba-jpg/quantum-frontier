import { describe, expect, it } from "vitest";
import { getToolInfo, TOOL_INFO } from "@/experience/data/toolInfo";
import { PLACEMENTS, placementsFor } from "@/experience/data/toolTypes";

describe("spacecraft sheets from the uploaded documents", () => {
  it("has exactly the eight documented spacecraft", () => {
    expect(TOOL_INFO.map(t => t.id).sort()).toEqual(
      ["apollo-12-alsep", "apollo-15-lrv", "ingenuity", "insight", "sojourner", "spirit-opportunity", "surveyor-3", "viking-1"].sort(),
    );
  });

  it("puts three on the Moon and five on Mars", () => {
    expect(placementsFor("moon")).toHaveLength(3);
    expect(placementsFor("mars")).toHaveLength(5);
  });

  it("gives every placed spacecraft a sheet on the same world", () => {
    for (const p of PLACEMENTS) {
      expect(getToolInfo(p.id)?.planet).toBe(p.planet);
    }
  });
});
