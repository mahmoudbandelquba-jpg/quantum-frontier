import OrbitStage from "./orbit/OrbitStage";
import { useExperience } from "./store";
import SurfaceStage from "./surface/SurfaceStage";

/** QUANTUM FRONTIER: orbit → suit up → choose a world → jump → explore. */
export default function Experience() {
  const phase = useExperience(s => s.phase);
  const onSurface = phase === "landing" || phase === "explore";
  return (
    <main className="fixed inset-0 overflow-hidden bg-[#020308] text-[var(--hud)]">
      {onSurface ? <SurfaceStage /> : <OrbitStage />}
    </main>
  );
}
