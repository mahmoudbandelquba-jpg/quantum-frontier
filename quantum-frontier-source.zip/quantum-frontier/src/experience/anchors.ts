import * as THREE from "three";

/**
 * Screen-space anchors written by the 3D scene each frame and read by DOM
 * overlays (planet labels, paper icons). Keeps interactive UI in the normal
 * React tree instead of nested portal roots.
 */
export interface Anchor {
  /** CSS pixels relative to the canvas. */
  x: number;
  y: number;
  /** In front of the camera and roughly on screen. */
  visible: boolean;
  /** World distance from the camera. */
  dist: number;
}

export const anchors = new Map<string, Anchor>();

const v = new THREE.Vector3();

export function projectAnchor(
  id: string,
  world: THREE.Vector3,
  camera: THREE.Camera,
  size: { width: number; height: number },
) {
  const dist = camera.position.distanceTo(world);
  v.copy(world).project(camera);
  const anchor = anchors.get(id) ?? { x: 0, y: 0, visible: false, dist: 0 };
  anchor.x = ((v.x + 1) / 2) * size.width;
  anchor.y = ((1 - v.y) / 2) * size.height;
  anchor.visible = v.z < 1 && v.z > -1 && Math.abs(v.x) < 1.25 && Math.abs(v.y) < 1.25;
  anchor.dist = dist;
  anchors.set(id, anchor);
  return anchor;
}

export function clearAnchors(prefix: string) {
  for (const key of Array.from(anchors.keys())) {
    if (key.startsWith(prefix)) anchors.delete(key);
  }
}
