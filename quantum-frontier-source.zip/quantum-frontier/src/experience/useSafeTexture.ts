import { useEffect, useState } from "react";
import * as THREE from "three";

const loader = new THREE.TextureLoader();
const textureCache = new Map<string, Promise<THREE.Texture | null>>();

function load(url: string) {
  let p = textureCache.get(url);
  if (!p) {
    p = new Promise(resolve => {
      loader.load(
        url,
        tex => resolve(tex),
        undefined,
        () => resolve(null),
      );
    });
    textureCache.set(url, p);
  }
  return p;
}

export interface TextureOptions {
  repeat?: number;
  srgb?: boolean;
  anisotropy?: number;
}

/**
 * Loads a texture without suspending; returns null until (or if never) loaded,
 * so the scene can render with plain materials as a fallback.
 */
export function useSafeTexture(url: string | null | undefined, opts: TextureOptions = {}) {
  const [texture, setTexture] = useState<THREE.Texture | null>(null);
  const { repeat, srgb = true, anisotropy = 8 } = opts;

  useEffect(() => {
    let alive = true;
    let owned: THREE.Texture | null = null;
    if (!url) {
      setTexture(null);
      return;
    }
    load(url).then(base => {
      if (!alive || !base) return;
      const tex = base.clone();
      owned = tex;
      tex.colorSpace = srgb ? THREE.SRGBColorSpace : THREE.NoColorSpace;
      tex.anisotropy = anisotropy;
      if (repeat) {
        tex.wrapS = THREE.RepeatWrapping;
        tex.wrapT = THREE.RepeatWrapping;
        tex.repeat.set(repeat, repeat);
      }
      tex.needsUpdate = true;
      setTexture(tex);
    });
    return () => {
      alive = false;
      // The clone belongs to this hook (the cached base is shared); free its GPU copy.
      owned?.dispose();
    };
  }, [url, repeat, srgb, anisotropy]);

  return texture;
}
