import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { useEffect, useMemo, useRef } from "react";
import * as THREE from "three";
import { anchors, projectAnchor } from "../anchors";
import { TEXTURES } from "../assets";
import { useExperience, type PlanetId } from "../store";
import { useSafeTexture } from "../useSafeTexture";

const JUMP_DURATION = 3.1;

interface PlanetDef {
  id: PlanetId;
  title: string;
  sub: string;
  radius: number;
  map: string;
  fallback: string;
  glow: string;
  tilt: number;
}

export const DEFS: PlanetDef[] = [
  {
    id: "moon",
    title: "Jump to the Moon",
    sub: "384,400 km away · 1/6 of Earth's gravity",
    radius: 1.15,
    map: TEXTURES.moonMap,
    fallback: "#9b9a96",
    glow: "#dfe7ff",
    tilt: 0.12,
  },
  {
    id: "mars",
    title: "Jump to Mars",
    sub: "≈225 million km away · 38% of Earth's gravity",
    radius: 1.3,
    map: TEXTURES.marsMap,
    fallback: "#c1643c",
    glow: "#ff9a5a",
    tilt: 0.44,
  },
];

function glowMaterial(color: string) {
  return new THREE.ShaderMaterial({
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
    side: THREE.BackSide,
    uniforms: { uColor: { value: new THREE.Color(color) }, uStrength: { value: 0.6 } },
    vertexShader: `
      varying vec3 vNormal;
      void main() {
        vNormal = normalize(normalMatrix * normal);
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
      }`,
    fragmentShader: `
      uniform vec3 uColor;
      uniform float uStrength;
      varying vec3 vNormal;
      void main() {
        float i = pow(0.68 - dot(vNormal, vec3(0.0, 0.0, 1.0)), 2.6);
        gl_FragColor = vec4(uColor, 1.0) * i * uStrength;
      }`,
  });
}

function useLayout() {
  const viewport = useThree(s => s.viewport);
  const size = useThree(s => s.size);
  const portrait = size.width / size.height < 0.9;
  return useMemo(() => {
    if (portrait) {
      // Stack vertically: Moon centred ~37% down the screen, Mars ~70%, each
      // sized so the planet plus its label fits between the title and the bottom.
      const targetRadius = Math.min(viewport.width * 0.3, viewport.height * 0.1);
      return {
        moon: new THREE.Vector3(0, viewport.height * 0.13, 0),
        mars: new THREE.Vector3(0, -viewport.height * 0.2, 0),
        scale: Math.min(1, targetRadius / 1.3),
      };
    }
    const x = THREE.MathUtils.clamp(viewport.width * 0.22, 1.9, 3.6);
    return {
      moon: new THREE.Vector3(-x, 0.35, 0),
      mars: new THREE.Vector3(x, 0.35, 0),
      scale: 1,
    };
  }, [viewport.width, viewport.height, portrait]);
}

function Planet({ def, home, scale }: { def: PlanetDef; home: THREE.Vector3; scale: number }) {
  const group = useRef<THREE.Group>(null);
  const body = useRef<THREE.Mesh>(null);
  const mat = useRef<THREE.MeshStandardMaterial>(null);
  const glow = useMemo(() => glowMaterial(def.glow), [def.glow]);
  const map = useSafeTexture(def.map);
  const hoverPlanet = useExperience(s => s.hoverPlanet);
  const setHover = useExperience(s => s.setHoverPlanet);
  const jumpTo = useExperience(s => s.jumpTo);
  const phase = useExperience(s => s.phase);
  const chosen = useExperience(s => s.planet);
  const hovered = hoverPlanet === def.id;
  const anim = useRef({ s: 1, t: 0 });
  const labelPoint = useMemo(() => new THREE.Vector3(), []);
  const anchorId = `planet:${def.id}`;

  useEffect(() => () => void anchors.delete(anchorId), [anchorId]);

  useFrame(({ camera, size }, rawDt) => {
    const dt = Math.min(rawDt, 0.05);
    const g = group.current;
    if (!g || !body.current) return;
    body.current.rotation.y += dt * 0.06;
    const jumping = phase === "jumping";
    const isChosen = chosen === def.id;
    const a = anim.current;

    if (jumping) {
      a.t = Math.min(1, a.t + dt / JUMP_DURATION);
      if (isChosen) {
        const k = 1 - Math.exp(-dt * 3.2);
        g.position.lerp(new THREE.Vector3(0, 0, 0), k);
        a.s += (1.05 - a.s) * k;
        glow.uniforms["uStrength"]!.value = 0.8 + a.t * 1.6;
        // dolly the camera into the planet
        const e = a.t * a.t * a.t;
        camera.position.z = THREE.MathUtils.lerp(10, def.radius * scale * 1.04, e);
        camera.position.x = (Math.random() - 0.5) * 0.02 * a.t;
        camera.position.y = (Math.random() - 0.5) * 0.02 * a.t;
        if (a.t >= 1) useExperience.getState().startLanding();
      } else {
        g.position.x += Math.sign(home.x || 1) * dt * 4;
        g.position.z -= dt * 6;
        if (mat.current) mat.current.opacity = Math.max(0, mat.current.opacity - dt * 1.5);
        glow.uniforms["uStrength"]!.value = Math.max(0, glow.uniforms["uStrength"]!.value - dt);
      }
    } else {
      a.t = 0;
      g.position.lerp(home, 1 - Math.exp(-dt * 4));
      const target = hovered ? 1.12 : 1;
      a.s += (target - a.s) * (1 - Math.exp(-dt * 6));
      glow.uniforms["uStrength"]!.value += ((hovered ? 1.25 : 0.6) - glow.uniforms["uStrength"]!.value) * (1 - Math.exp(-dt * 6));
      if (mat.current) mat.current.opacity = 1;
    }
    g.scale.setScalar(a.s * scale);
    labelPoint.set(g.position.x, g.position.y - def.radius * a.s * scale - 0.12, g.position.z);
    projectAnchor(anchorId, labelPoint, camera, size);
  });

  const select = () => jumpTo(def.id);

  return (
    <group ref={group} position={home}>
      <mesh
        ref={body}
        rotation={[def.tilt, 0, 0]}
        onPointerOver={e => {
          e.stopPropagation();
          setHover(def.id);
          document.body.style.cursor = "pointer";
        }}
        onPointerOut={() => {
          setHover(null);
          document.body.style.cursor = "";
        }}
        onClick={e => {
          e.stopPropagation();
          select();
        }}
      >
        <sphereGeometry args={[def.radius, 96, 96]} />
        <meshStandardMaterial
          ref={mat}
          key={map ? "tex" : "plain"}
          map={map ?? null}
          color={map ? "#ffffff" : def.fallback}
          roughness={0.95}
          metalness={0}
          transparent
        />
      </mesh>
      <mesh material={glow} scale={def.radius * 1.18}>
        <sphereGeometry args={[1, 48, 48]} />
      </mesh>
    </group>
  );
}

/** Destination buttons placed under each planet (DOM layer above the canvas). */
export function PlanetLabels() {
  const phase = useExperience(s => s.phase);
  const hoverPlanet = useExperience(s => s.hoverPlanet);
  const setHover = useExperience(s => s.setHoverPlanet);
  const jumpTo = useExperience(s => s.jumpTo);
  const refs = useRef(new Map<PlanetId, HTMLDivElement>());
  const choosing = phase === "choose";

  useEffect(() => {
    let raf = 0;
    const tick = () => {
      refs.current.forEach((el, id) => {
        const a = anchors.get(`planet:${id}`);
        if (!a) return;
        el.style.transform = `translate3d(${a.x.toFixed(1)}px, ${a.y.toFixed(1)}px, 0) translate(-50%, 0)`;
        el.style.visibility = "visible";
      });
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, []);

  return (
    <div className="pointer-events-none absolute inset-0 z-20">
      {DEFS.map(def => {
        const hovered = hoverPlanet === def.id;
        return (
          <div
            key={def.id}
            ref={el => {
              if (el) refs.current.set(def.id, el);
              else refs.current.delete(def.id);
            }}
            className="absolute left-0 top-0 flex w-[300px] flex-col items-center text-center transition-opacity duration-500"
            style={{ visibility: "hidden", opacity: choosing ? 1 : 0 }}
          >
            <button
              type="button"
              disabled={!choosing}
              onClick={() => jumpTo(def.id)}
              onPointerEnter={() => setHover(def.id)}
              onPointerLeave={() => setHover(null)}
              onFocus={() => setHover(def.id)}
              onBlur={() => setHover(null)}
              className={`pointer-events-auto relative overflow-hidden whitespace-nowrap border px-6 py-3 font-display text-[13px] uppercase tracking-[0.18em] text-white backdrop-blur-md transition-all duration-300 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[var(--suit)] ${
                hovered
                  ? "border-[var(--suit)] bg-[rgba(255,95,31,0.2)] shadow-[0_0_30px_rgba(255,95,31,0.25)]"
                  : "border-white/35 bg-[rgba(6,10,20,0.45)]"
              }`}
            >
              {def.title}
            </button>
            <span className="mt-2 bg-[rgba(3,5,12,0.62)] px-2.5 py-1 font-hud text-[10.5px] uppercase tracking-[0.14em] text-[var(--hud)] backdrop-blur-sm">
              {def.sub}
            </span>
          </div>
        );
      })}
    </div>
  );
}

function Scene() {
  const layout = useLayout();
  return (
    <>
      <ambientLight intensity={0.08} />
      {/* key light from the sun flare in the upper left of the backdrop */}
      <directionalLight position={[-6, 4, 5]} intensity={3.2} color="#fff6ea" />
      <directionalLight position={[4, -3, 2]} intensity={0.25} color="#6f9cff" />
      <Planet def={DEFS[0]!} home={layout.moon} scale={layout.scale} />
      <Planet def={DEFS[1]!} home={layout.mars} scale={layout.scale} />
    </>
  );
}

export default function PlanetPicker() {
  return (
    <Canvas
      className="!absolute inset-0"
      dpr={[1, 2]}
      gl={{ alpha: true, antialias: true }}
      camera={{ fov: 40, near: 0.01, far: 100, position: [0, 0, 10] }}
      style={{ background: "transparent" }}
    >
      <Scene />
    </Canvas>
  );
}
