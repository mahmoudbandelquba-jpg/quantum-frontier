import { useEffect, useRef } from "react";

interface Star {
  x: number;
  y: number;
  r: number;
  phase: number;
  speed: number;
  /** For warp: polar coordinates around the centre. */
  ang: number;
  dist: number;
}

/** Lightweight twinkling stars that turn into warp streaks during the jump. */
export default function StarField({ warp }: { warp: boolean }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const warpRef = useRef(warp);
  warpRef.current = warp;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    let w = 0;
    let h = 0;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const stars: Star[] = [];

    const resize = () => {
      w = canvas.clientWidth;
      h = canvas.clientHeight;
      canvas.width = w * dpr;
      canvas.height = h * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    resize();
    window.addEventListener("resize", resize);

    for (let i = 0; i < 320; i++) {
      stars.push({
        x: Math.random(),
        y: Math.random() * 0.75,
        r: Math.random() < 0.08 ? 1.4 : 0.5 + Math.random() * 0.7,
        phase: Math.random() * Math.PI * 2,
        speed: 0.6 + Math.random() * 2.2,
        ang: Math.random() * Math.PI * 2,
        dist: 0.02 + Math.random() * 0.9,
      });
    }

    let raf = 0;
    let last = performance.now();
    let warpT = 0;
    const frame = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      ctx.clearRect(0, 0, w, h);
      if (warpRef.current) {
        warpT = Math.min(1, warpT + dt / 2.6);
        const cx = w / 2;
        const cy = h / 2;
        const maxR = Math.hypot(cx, cy);
        const accel = 0.25 + warpT * warpT * 3.2;
        ctx.lineCap = "round";
        for (const s of stars) {
          const prev = s.dist;
          s.dist += s.dist * accel * dt * s.speed;
          if (s.dist > 1.1) {
            s.dist = 0.02 + Math.random() * 0.1;
            s.ang = Math.random() * Math.PI * 2;
            continue;
          }
          const tail = Math.max(prev - (s.dist - prev) * (2 + warpT * 10), 0.01);
          const x1 = cx + Math.cos(s.ang) * tail * maxR;
          const y1 = cy + Math.sin(s.ang) * tail * maxR;
          const x2 = cx + Math.cos(s.ang) * s.dist * maxR;
          const y2 = cy + Math.sin(s.ang) * s.dist * maxR;
          ctx.strokeStyle = `rgba(220,232,255,${0.25 + s.dist * 0.75})`;
          ctx.lineWidth = s.r * (0.8 + s.dist * 1.6);
          ctx.beginPath();
          ctx.moveTo(x1, y1);
          ctx.lineTo(x2, y2);
          ctx.stroke();
        }
      } else {
        warpT = 0;
        const t = now / 1000;
        for (const s of stars) {
          const a = 0.35 + 0.65 * (0.5 + 0.5 * Math.sin(t * s.speed + s.phase));
          ctx.fillStyle = `rgba(235,242,255,${a * 0.85})`;
          ctx.beginPath();
          ctx.arc(s.x * w, s.y * h, s.r, 0, Math.PI * 2);
          ctx.fill();
        }
      }
      raf = requestAnimationFrame(frame);
    };
    raf = requestAnimationFrame(frame);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
    };
  }, []);

  return <canvas ref={canvasRef} className="pointer-events-none absolute inset-0 h-full w-full" aria-hidden />;
}
