import { useEffect, useRef, useState } from "react";
import { ART } from "../assets";
import Brand from "../hud/Brand";
import { PLANETS } from "../planets";
import { useExperience } from "../store";
import Gloves, { type GloveMode } from "../suit/Gloves";
import Visor, { SuitReadouts } from "../suit/Visor";
import PlanetPicker, { PlanetLabels } from "./PlanetPicker";
import StarField from "./StarField";

const SUIT_STEPS = [
  ["Helmet lock", "Engaged"],
  ["Glove seals", "Engaged"],
  ["Suit pressure", "4.3 psi"],
  ["Primary O₂", "100%"],
  ["Comm link", "Nominal"],
];

function SuitUpSequence() {
  const [step, setStep] = useState(0);
  useEffect(() => {
    const id = window.setInterval(() => setStep(s => s + 1), 380);
    return () => window.clearInterval(id);
  }, []);
  return (
    <div className="pointer-events-none absolute inset-x-0 top-[22%] flex flex-col items-center px-6">
      <div className="hud-panel w-full max-w-[380px] px-5 py-4">
        <div className="hud-label mb-3 text-[var(--suit)]">Suit-up sequence</div>
        {SUIT_STEPS.map(([k, v], i) => (
          <div
            key={k}
            className="flex items-end font-hud text-[12px] uppercase tracking-[0.14em] transition-opacity duration-300"
            style={{ opacity: step > i + 1 ? 1 : 0.12 }}
          >
            <span className="text-[var(--hud)]">{k}</span>
            <span className="mx-2 mb-[3px] flex-1 border-b border-dotted border-white/25" />
            <span className={step > i + 1 ? "text-emerald-300" : "text-[var(--hud-dim)]"}>{v}</span>
          </div>
        ))}
      </div>
      <div
        className="mt-8 text-center font-display text-[clamp(1.2rem,3vw,2.2rem)] uppercase tracking-[0.2em] text-white transition-all duration-700"
        style={{ opacity: step > 6 ? 1 : 0, transform: step > 6 ? "none" : "translateY(10px)" }}
      >
        Spacesuit sealed
      </div>
    </div>
  );
}

function JumpReadout() {
  const planet = useExperience(s => s.planet);
  const [dist, setDist] = useState(planet ? PLANETS[planet].distanceKm : 0);
  useEffect(() => {
    if (!planet) return;
    const total = PLANETS[planet].distanceKm;
    const start = performance.now();
    let raf = 0;
    const tick = () => {
      const t = Math.min(1, (performance.now() - start) / 3000);
      setDist(Math.round(total * Math.pow(1 - t, 3)));
      if (t < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [planet]);
  if (!planet) return null;
  return (
    <div className="pointer-events-none absolute left-1/2 top-[12%] -translate-x-1/2 text-center">
      <div className="hud-label text-[var(--suit)]">Trajectory locked</div>
      <div className="mt-2 font-display text-[clamp(1.4rem,3.6vw,2.6rem)] uppercase tracking-[0.24em] text-white">
        {PLANETS[planet].name}
      </div>
      <div className="mt-2 font-hud text-[12px] tracking-[0.2em] text-[var(--hud)]">
        DIST {dist.toLocaleString("en-US")} KM
      </div>
    </div>
  );
}

export default function OrbitStage() {
  const phase = useExperience(s => s.phase);
  const planet = useExperience(s => s.planet);
  const hoverPlanet = useExperience(s => s.hoverPlanet);
  const wearSuit = useExperience(s => s.wearSuit);
  const finishSuiting = useExperience(s => s.finishSuiting);
  const root = useRef<HTMLDivElement>(null);
  const backdropImg = useRef<HTMLImageElement>(null);
  const [backdropReady, setBackdropReady] = useState(false);

  // The load event can fire before React attaches onLoad (cached image).
  useEffect(() => {
    const img = backdropImg.current;
    if (img?.complete && img.naturalWidth > 0) setBackdropReady(true);
  }, []);

  // Suit-up sequence timing
  useEffect(() => {
    if (phase !== "suiting") return;
    const id = window.setTimeout(finishSuiting, 3600);
    return () => window.clearTimeout(id);
  }, [phase, finishSuiting]);

  // Gentle mouse parallax on the orbital backdrop
  useEffect(() => {
    const el = root.current;
    if (!el) return;
    const move = (e: PointerEvent) => {
      const x = e.clientX / window.innerWidth - 0.5;
      const y = e.clientY / window.innerHeight - 0.5;
      el.style.setProperty("--px", x.toFixed(3));
      el.style.setProperty("--py", y.toFixed(3));
    };
    window.addEventListener("pointermove", move);
    return () => window.removeEventListener("pointermove", move);
  }, []);

  // Keyboard: any key also suits up on the intro screen
  useEffect(() => {
    if (phase !== "intro") return;
    const key = (e: KeyboardEvent) => {
      if (e.code === "Enter" || e.code === "Space") wearSuit();
    };
    window.addEventListener("keydown", key);
    return () => window.removeEventListener("keydown", key);
  }, [phase, wearSuit]);

  const sealed = phase !== "intro";
  const jumping = phase === "jumping";
  const gloveMode: GloveMode =
    phase === "intro" ? "hidden" : jumping ? "thrust" : "rest";
  const flashColor = planet ? PLANETS[planet].flashColor : "#ffffff";

  return (
    <div
      ref={root}
      className="absolute inset-0 overflow-hidden bg-[#020308]"
      style={{ ["--px" as string]: 0, ["--py" as string]: 0 }}
      onClick={() => phase === "intro" && wearSuit()}
      role={phase === "intro" ? "button" : undefined}
      aria-label={phase === "intro" ? "Click on the screen to wear your spacesuit" : undefined}
    >
      {/* Orbital backdrop: Earth's limb, sun flare, stars */}
      <div
        className="absolute inset-[-4%]"
        style={{
          transform: jumping
            ? "translate3d(0, 34%, 0) scale(1.35)"
            : "translate3d(calc(var(--px) * -18px), calc(var(--py) * -12px), 0) scale(1.04)",
          filter: jumping ? "blur(10px) brightness(0.6)" : phase === "choose" ? "brightness(0.82)" : "none",
          opacity: jumping ? 0 : backdropReady ? 1 : 0,
          transition: jumping
            ? "transform 2.6s cubic-bezier(0.6, 0, 0.9, 0.4), filter 2s ease, opacity 2.4s ease-in"
            : "transform 0.6s ease-out, filter 1.2s ease, opacity 1.6s ease",
        }}
      >
        <img
          ref={backdropImg}
          src={ART.orbitBackdrop}
          alt="Earth's curved horizon seen from low orbit, with the Sun flaring above it"
          className="h-full w-full object-cover"
          draggable={false}
          fetchPriority="high"
          onLoad={() => setBackdropReady(true)}
        />
      </div>

      <StarField warp={jumping} />

      {(phase === "choose" || jumping) && <PlanetPicker />}

      <Gloves mode={gloveMode} reach={phase === "choose" ? hoverPlanet : null} />
      <Visor sealed={sealed} />
      {(phase === "choose" || jumping) && <PlanetLabels />}

      {/* Atmospheric entry glow as the planet fills the view */}
      {jumping && (
        <div
          className="pointer-events-none absolute inset-0"
          style={{
            background: `radial-gradient(circle at 50% 50%, transparent 30%, ${flashColor}55 75%, ${flashColor} 100%)`,
            animation: "flash-out 3.1s ease-in reverse both",
          }}
        />
      )}

      {/* Top bar */}
      <div className="pointer-events-none absolute inset-x-0 top-0 flex items-start justify-between px-[clamp(1.25rem,4vw,3.5rem)] pt-[clamp(1.25rem,4vh,2.75rem)]">
        <Brand />
        <div className="shrink-0 text-right">
          <div className="hud-label">Low Earth orbit</div>
          <div className="mt-1 whitespace-nowrap font-hud text-[11px] tracking-[0.2em] text-[var(--hud)] max-sm:text-[9.5px] max-sm:tracking-[0.12em]">
            ALT 408 KM<span className="max-sm:hidden"> · 7.66 KM/S</span>
          </div>
          <SuitReadouts visible={sealed} className="ml-auto mt-4 w-[150px] text-left animate-rise-in max-sm:hidden" />
        </div>
      </div>

      {phase === "intro" && (
        <div
          className="pointer-events-none absolute inset-x-0 bottom-0 h-[55%]"
          style={{ background: "linear-gradient(to top, rgba(2,4,10,0.82) 0%, rgba(2,4,10,0.55) 45%, transparent 100%)" }}
        />
      )}
      {phase === "intro" && (
        <div className="pointer-events-none absolute inset-x-0 bottom-[16%] flex flex-col items-center px-6 text-center [text-shadow:0_2px_18px_rgba(0,0,0,0.85)]">
          <div className="relative mb-7 grid h-14 w-14 place-items-center">
            <span className="absolute inset-0 rounded-full border border-white/40 animate-ping [animation-duration:2.4s]" />
            <span className="h-2.5 w-2.5 rounded-full bg-[var(--suit)] shadow-[0_0_18px_var(--suit)]" />
          </div>
          <p className="max-w-[22ch] font-display text-[clamp(1.15rem,2.6vw,2.1rem)] leading-[1.5] tracking-[0.08em] text-white animate-breathe sm:max-w-none">
            Click on the screen to wear your spacesuit.
          </p>
          <p className="mt-5 hud-label">EVA prep · Airlock depressurised</p>
        </div>
      )}

      {phase === "suiting" && <SuitUpSequence />}

      {phase === "choose" && (
        <div className="pointer-events-none absolute inset-x-0 top-[13%] flex flex-col items-center px-6 text-center animate-rise-in sm:top-[15%]">
          <div className="hud-label text-[var(--suit)]">Life support nominal</div>
          <h1 className="mt-3 font-display text-[clamp(1.2rem,2.8vw,2.3rem)] uppercase tracking-[0.16em] text-white">
            Pick your world
          </h1>
          <p className="mt-3 max-w-[46ch] font-sans text-[14px] text-[var(--hud-dim)]">
            Eight real spacecraft left behind by their missions are waiting on the surface. Touch a planet to jump.
          </p>
        </div>
      )}

      {jumping && <JumpReadout />}
    </div>
  );
}
