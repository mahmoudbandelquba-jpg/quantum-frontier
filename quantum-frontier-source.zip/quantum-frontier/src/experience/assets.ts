import orbitBackdrop from "@/assets/art/orbit-backdrop.webp.asset.json";
import gloveRight from "@/assets/art/glove-right.webp.asset.json";
import gloveLeft from "@/assets/art/glove-left.webp.asset.json";

/** Artwork used in DOM layers (orbit backdrop and first-person gloves). */
export const ART = {
  orbitBackdrop: orbitBackdrop.url,
  gloveRight: gloveRight.url,
  gloveLeft: gloveLeft.url,
};

/**
 * WebGL textures are bundled with the site so they are always same-origin
 * (cross-origin images cannot be uploaded to the GPU without CORS headers).
 */
export const TEXTURES = {
  moonMap: "/textures/moon.jpg",
  marsMap: "/textures/mars.jpg",
  earthMap: "/textures/earth.jpg",
  moonGround: "/textures/moon-ground.jpg",
  marsGround: "/textures/mars-ground.jpg",
};
