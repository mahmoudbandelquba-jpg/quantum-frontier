import type { PlanetId } from "../store";

/** A titled paragraph inside an information sheet. */
export interface SheetPoint {
  title: string;
  body: string;
  /** Optional bullet list shown under the paragraph. */
  items?: string[];
}

export interface ToolInfo {
  id: string;
  planet: PlanetId;
  name: string;
  nickname: string | null;
  category: string;
  missions: string;
  agency: string;
  /** Landing date shown in the quick facts. */
  landed: string;
  /** Landing site name. */
  site: string;
  /** One-line current state. */
  status: string;
  /** "What is it?" */
  intro: string;
  /** Heading for the parts list ("Key parts", "Left on the surface", ...). */
  partsTitle: string;
  parts: SheetPoint[];
  /** Fun facts and side notes (landing details, what was not left behind). */
  notes: SheetPoint[];
  /** "Why was it left behind?" */
  whyLeftBehind: SheetPoint[];
  image: { url: string; credit: string; sourceUrl: string };
}

/** A solid circle (local coordinates, before rotation) the walker cannot enter. */
export interface Solid {
  x: number;
  z: number;
  r: number;
}

export interface ToolPlacement {
  id: string;
  planet: PlanetId;
  /** World position on the surface (y is sampled from the terrain). */
  x: number;
  z: number;
  rotY: number;
  scale: number;
  /** Distance at which the astronaut stops to examine the exhibit. */
  examineRadius: number;
  /** Solid circles the walker cannot pass through (local, unscaled). */
  solids: Solid[];
  /** Radius kept flat and free of rocks and craters. */
  footprint: number;
  /** Height the camera looks at while examining. */
  focusHeight: number;
  /** Height of the paper icon above the ground. */
  iconHeight: number;
}

export const PLACEMENTS: ToolPlacement[] = [
  // ---- Moon ----
  { id: "surveyor-3", planet: "moon", x: 9, z: -20, rotY: 0.5, scale: 1, examineRadius: 5.2, solids: [{ x: 0, z: 0, r: 1.9 }], footprint: 4, focusHeight: 1.3, iconHeight: 3.9 },
  { id: "apollo-12-alsep", planet: "moon", x: -27, z: -12, rotY: 1.2, scale: 1, examineRadius: 8, solids: [{ x: 0, z: 0, r: 3.55 }, { x: 4.6, z: 1.6, r: 0.6 }], footprint: 8, focusHeight: 1.6, iconHeight: 5.6 },
  { id: "apollo-15-lrv", planet: "moon", x: 24, z: 14, rotY: -2.2, scale: 1, examineRadius: 6, solids: [{ x: 0, z: 0, r: 1.7 }, { x: 0, z: -7.5, r: 3.55 }], footprint: 12, focusHeight: 0.9, iconHeight: 3.2 },
  // ---- Mars ----
  { id: "sojourner", planet: "mars", x: 9, z: -18, rotY: 0.4, scale: 1, examineRadius: 4.8, solids: [{ x: 0, z: 0, r: 1.7 }], footprint: 4.5, focusHeight: 0.4, iconHeight: 2.4 },
  { id: "spirit-opportunity", planet: "mars", x: -18, z: -27, rotY: -0.6, scale: 1, examineRadius: 5.4, solids: [{ x: 0, z: 0, r: 1.25 }, { x: -3.6, z: -2.4, r: 1.5 }], footprint: 6.5, focusHeight: 0.9, iconHeight: 2.8 },
  { id: "viking-1", planet: "mars", x: 25, z: -36, rotY: 1.3, scale: 1, examineRadius: 5, solids: [{ x: 0, z: 0, r: 1.6 }], footprint: 4.5, focusHeight: 1.1, iconHeight: 3.2 },
  { id: "insight", planet: "mars", x: -32, z: 4, rotY: 0.9, scale: 1, examineRadius: 6.2, solids: [{ x: 0, z: 0, r: 3.0 }], footprint: 6, focusHeight: 0.8, iconHeight: 2.9 },
  { id: "ingenuity", planet: "mars", x: 33, z: 10, rotY: 0.6, scale: 1.4, examineRadius: 3.6, solids: [{ x: 0, z: 0, r: 1.0 }], footprint: 2.5, focusHeight: 0.45, iconHeight: 1.4 },
];

export function placementsFor(planet: PlanetId) {
  return PLACEMENTS.filter(p => p.planet === planet);
}
