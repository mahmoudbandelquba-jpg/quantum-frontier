// Sheet content comes from the user's research documents (Surveyor, ALSEP, Lunar Roving Vehicle,
// Sojourner, Spirit & Opportunity, Viking, InSight, Ingenuity). Photos: NASA public-domain imagery.
import surveyorPhoto from "@/assets/photos/surveyor-3.jpg.asset.json";
import alsepPhoto from "@/assets/photos/apollo-12-alsep.jpg.asset.json";
import lrvPhoto from "@/assets/photos/apollo-15-lrv.jpg.asset.json";
import sojournerPhoto from "@/assets/photos/sojourner.jpg.asset.json";
import merPhoto from "@/assets/photos/spirit-opportunity.jpg.asset.json";
import vikingPhoto from "@/assets/photos/viking-1.jpg.asset.json";
import insightPhoto from "@/assets/photos/insight.jpg.asset.json";
import ingenuityPhoto from "@/assets/photos/ingenuity.jpg.asset.json";
import type { ToolInfo } from "./toolTypes";

const nasa = (id: string) => `https://images.nasa.gov/details/${id}`;

export const TOOL_INFO: ToolInfo[] = [
  // ======================= MOON =======================
  {
    id: "surveyor-3",
    planet: "moon",
    name: "Surveyor 3 Lander",
    nickname: null,
    category: "Robotic lunar lander",
    missions: "Surveyor 3",
    agency: "NASA",
    landed: "April 1967",
    site: "Ocean of Storms",
    status: "Final contact on May 4, 1967. The main body still rests on the Moon.",
    intro:
      "Surveyor 3 was an uncrewed, three-legged robotic lander that NASA sent to the Moon before astronauts ever walked on the lunar surface. It carried two main tools to study the landing site.",
    partsTitle: "Main tools",
    parts: [
      {
        title: "TV Camera",
        body: "A camera mounted under a movable mirror that looked around the landing area and sent thousands of pictures back to Earth.",
      },
      {
        title: "Surface-Sampler Arm",
        body: "A robotic claw and scoop, the first of its kind on the Moon, that reached out to dig small trenches and test the strength of the lunar soil.",
      },
    ],
    notes: [
      {
        title: "Fun landing detail",
        body: "During touchdown, the descent engine failed to shut off at the expected time, causing Surveyor 3 to bounce twice off the Moon's surface before settling down safely!",
      },
      {
        title: "What wasn't completely left behind",
        body: "Over two and a half years later, the Apollo 12 astronauts landed right next to Surveyor 3, walked over to inspect it, and brought its TV camera and soil scoop back to Earth so scientists could study how years on the Moon affected Earth-made materials.",
      },
    ],
    whyLeftBehind: [
      {
        title: "Built as a one-way robotic scout",
        body: "Unlike the Apollo spaceships that carried astronauts home, Surveyor 3 had no return rocket or crew cabin. NASA designed it from the start to land once, explore its surroundings, and stay permanently on the Moon.",
      },
      {
        title: "To prove the lunar surface could support landers",
        body: "Before risking human lives, NASA needed to know if the Moon's surface could hold a heavy spaceship without sinking into deep dust. By digging trenches and testing the ground, the experiments showed that the Moon's surface was capable of supporting landing spacecraft, and that the soil was more cohesive than had been feared.",
      },
      {
        title: "Lost contact after the lunar night began",
        body: "After completing its photo and digging experiments, NASA had its final contact with Surveyor 3 on May 4, 1967, after the lunar night began, leaving the main body of the lander resting quietly on the Moon ever since.",
      },
    ],
    image: {
      url: surveyorPhoto.url,
      credit: "NASA (Apollo 12, AS12-48-7134)",
      sourceUrl: nasa("AS12-48-7134"),
    },
  },
  {
    id: "apollo-12-alsep",
    planet: "moon",
    name: "Apollo 12: “Intrepid” & ALSEP",
    nickname: "ALSEP scientific packages",
    category: "Crewed landing site · science station",
    missions: "Apollo 12",
    agency: "NASA",
    landed: "November 1969",
    site: "Ocean of Storms, beside Surveyor 3",
    status: "ALSEP reported back to Earth for nearly eight years. The descent stage remains on the Moon.",
    intro:
      "This NASA mission made a pinpoint landing in the Moon's Ocean of Storms, right next to an older robotic spacecraft named Surveyor 3, and left behind several pieces of equipment.",
    partsTitle: "Left on the surface",
    parts: [
      {
        title: "Lunar Module “Intrepid”",
        body: "A two-part, spider-legged spaceship with a bottom landing platform and a top crew cabin that carried astronauts Pete Conrad and Alan Bean safely to the lunar surface.",
      },
      {
        title: "ALSEP (Apollo Lunar Surface Experiments Package)",
        body: "The very first full-scale, long-term science station on the Moon. Powered by a special heat-powered battery (called an RTG) instead of solar panels, it could stay awake through freezing lunar nights to listen for moonquakes, measure magnetic fields, track Moon dust, and study the Moon's super-thin atmosphere and particles from the Sun.",
      },
      {
        title: "Color TV Camera",
        body: "A tripod-mounted camera set up to broadcast live video of the moonwalk back to Earth, until it was accidentally pointed at the Sun during setup, which burned out its image sensor.",
      },
    ],
    notes: [
      {
        title: "What wasn't left behind",
        body: "Just like on Apollo 11, the astronauts rolled up and brought back their Solar Wind Composition foil sheet, along with Moon rocks and actual pieces removed from the older Surveyor 3 spacecraft so scientists could study how years on the Moon affected Earth-made materials!",
      },
    ],
    whyLeftBehind: [
      {
        title: "To work as a launchpad and save weight",
        body: "The bottom half of “Intrepid” was designed to stay on the Moon as a sturdy launchpad so the top cabin could blast back into orbit. Leaving heavy landing legs and empty fuel tanks behind also kept the return ship light enough to carry Moon rocks and Surveyor 3 parts back to Earth.",
      },
      {
        title: "To create a scientific “moonquake”",
        body: "After the astronauts safely docked with their main spaceship in orbit, NASA released the empty top cabin of “Intrepid” and intentionally crashed it into the Moon. The impact shook the ground like a giant hammer, letting Apollo 12's new seismometer record the first artificial moonquake so scientists could study what the inside of the Moon is made of!",
      },
      {
        title: "To monitor the Moon for years",
        body: "Because the ALSEP station didn't rely on sunlight for power, it stayed behind to send moonquake, magnetic, and space-weather reports back to Earth for nearly eight years after the astronauts flew home.",
      },
      {
        title: "No longer working",
        body: "Once the TV camera's sensor was damaged by the Sun and could no longer send pictures, it was left behind at the landing site rather than taking up space in the return cabin.",
      },
    ],
    image: {
      url: alsepPhoto.url,
      credit: "NASA (Apollo 12, AS12-47-6919)",
      sourceUrl: nasa("as12-47-6919"),
    },
  },
  {
    id: "apollo-15-lrv",
    planet: "moon",
    name: "Apollo 15: Lunar Roving Vehicle",
    nickname: "The Moon Buggy",
    category: "Lunar roving vehicle · landing site",
    missions: "Apollo 15",
    agency: "NASA",
    landed: "July 1971",
    site: "Near the Apennine Mountains",
    status: "The rover, descent stage and memorial remain on the Moon. ALSEP reported for more than six years.",
    intro:
      "This NASA mission landed near the Moon's towering Apennine Mountains and left behind a whole collection of exploration gear.",
    partsTitle: "Left on the surface",
    parts: [
      {
        title: "Lunar Module “Falcon”",
        body: "A two-part spaceship with four landing legs that carried astronauts David Scott and James Irwin safely down to the lunar surface.",
      },
      {
        title: "Lunar Roving Vehicle (the “Moon Buggy”)",
        body: "The very first electric car ever driven on another world! It traveled to the Moon folded up inside “Falcon” and unfolded so the astronauts could drive across rough craters and along the edges of deep lunar valleys.",
      },
      {
        title: "ALSEP (Apollo Lunar Surface Experiments Package)",
        body: "A full-scale science station connected by cables to a central radio box. Unlike Apollo 11's solar-powered station, this one ran on a special heat-powered battery (called an RTG) so it could keep working even during the freezing, pitch-black lunar nights. Its instruments listened for moonquakes, measured heat rising from deep inside the Moon, tracked magnetic fields, and studied solar wind and Moon dust.",
      },
      {
        title: "Memorial Plaque and Figurine",
        body: "A metal plaque and a tiny aluminum astronaut figure placed gently in the lunar dust.",
      },
    ],
    notes: [],
    whyLeftBehind: [
      {
        title: "To work as a launchpad and save weight",
        body: "Just like on Apollo 11, the bottom half of “Falcon” stayed on the Moon to act as a sturdy launchpad so the top cabin could blast off cleanly. Leaving heavy landing legs and empty fuel tanks behind also kept the return ship light enough to carry a huge collection of Moon rocks back to Earth. (After the crew docked with their main spaceship in orbit, the empty top cabin was released and intentionally crashed into the Moon so the new science station could record the vibrations!)",
      },
      {
        title: "Designed as a one-way lunar vehicle",
        body: "Returning the Lunar Rover to Earth was never part of the mission plan. From the very start, NASA engineered the buggy to stay permanently on the Moon once its driving work was done. Before blasting off, the astronauts parked it nearby so its remote-controlled camera could film “Falcon” leaving the Moon.",
      },
      {
        title: "To keep sending science back to Earth for years",
        body: "Because the ALSEP station didn't need sunlight to stay powered, it stayed behind to send moonquake, space-radiation, and lunar-heat reports back to Earth for more than six years after the astronauts flew home.",
      },
      {
        title: "To honor fallen space explorers",
        body: "The astronauts left the plaque and tiny astronaut figure on the Moon as a peaceful tribute to honor all the American and Soviet space explorers who had lost their lives helping humanity reach space.",
      },
    ],
    image: {
      url: lrvPhoto.url,
      credit: "NASA (Apollo 15, AS15-86-11603)",
      sourceUrl: nasa("as15-86-11603"),
    },
  },

  // ======================= MARS =======================
  {
    id: "sojourner",
    planet: "mars",
    name: "Mars Pathfinder & Sojourner Rover",
    nickname: "Carl Sagan Memorial Station",
    category: "Lander · first wheeled rover on another planet",
    missions: "Mars Pathfinder",
    agency: "NASA",
    landed: "July 1997",
    site: "Ares Vallis",
    status: "Last data received September 27, 1997. Mission ended March 10, 1998.",
    intro:
      "This NASA mission landed in an ancient Martian flood plain called Ares Vallis. It delivered the first wheeled robotic rover to operate on another planet, alongside a stationary science lander.",
    partsTitle: "What landed",
    parts: [
      {
        title: "Mars Pathfinder Lander (Carl Sagan Memorial Station)",
        body: "A three-petaled, solar-powered base station that opened up after touchdown. It carried:",
        items: [
          "Cameras: to capture images of the Martian surface.",
          "Weather Package: to measure Martian winds, temperature, and air pressure.",
          "Communication System: to relay Sojourner's data back to Earth.",
        ],
      },
      {
        title: "Sojourner Rover",
        body: "The very first wheeled robotic rover to operate on another planet! This small, six-wheeled, solar-powered explorer rolled down a ramp onto the Martian ground. It carried:",
        items: [
          "Cameras: to photograph nearby rocks and terrain.",
          "Alpha Proton X-ray Spectrometer (APXS): an instrument used to analyze the chemical composition of Martian rocks and soil.",
        ],
      },
      {
        title: "The Giant Airbags",
        body: "A cluster of four large, multi-lobed airbags that wrapped around the lander to protect it during touchdown.",
      },
    ],
    notes: [
      {
        title: "Fun landing fact!",
        body: "Instead of using landing legs, Pathfinder slowed down with a parachute through Mars's thin atmosphere, fired retrorockets before impact, and inflated its giant airbags. The spacecraft then bounced across the surface about 15 times, like a giant beach ball, before finally coming to a stop!",
      },
    ],
    whyLeftBehind: [
      {
        title: "Never designed to return to Earth",
        body: "NASA engineered Pathfinder and Sojourner as one-way robotic explorers. They had no system to launch themselves off Mars and return to Earth. Instead, they sent their discoveries home through radio communication.",
      },
      {
        title: "To test a bold new way to land and explore",
        body: "NASA wanted to prove that spacecraft could land safely using airbags and operate a wheeled rover on another planet. This technology helped pave the way for future Mars rovers, including Spirit, Opportunity, Curiosity, and Perseverance.",
      },
      {
        title: "To search for clues about ancient water",
        body: "Together, the lander and rover studied Martian rocks, magnetic dust, and weather. They spotted rounded pebbles and cobbles, clues suggesting that liquid water once flowed across Mars in a warmer, wetter past.",
      },
      {
        title: "The mission eventually lost contact",
        body: "Sojourner operated for 83 days, far exceeding its planned seven-day mission. NASA received the last successful data transmission from Pathfinder on September 27, 1997. After five months of unsuccessful attempts to restore communication, NASA officially ended the mission on March 10, 1998. Both machines remained on Mars, leaving behind a legacy that helped shape the future of robotic exploration.",
      },
    ],
    image: {
      url: sojournerPhoto.url,
      credit: "NASA/JPL (PIA04318)",
      sourceUrl: nasa("PIA04318"),
    },
  },
  {
    id: "spirit-opportunity",
    planet: "mars",
    name: "Spirit & Opportunity",
    nickname: "Twin Robot Geologists",
    category: "Twin Mars exploration rovers",
    missions: "Mars Exploration Rovers",
    agency: "NASA",
    landed: "January 2004",
    site: "Gusev Crater (Spirit) · Meridiani Planum (Opportunity)",
    status: "Spirit: recovery ended May 25, 2011. Opportunity: mission declared over February 13, 2019.",
    intro:
      "Two identical, six-wheeled rovers that NASA landed on opposite sides of Mars in January 2004 (Spirit in Gusev Crater, and Opportunity on Meridiani Planum). Their main scientific goal was to explore Mars's geology and search for evidence that liquid water once existed on its surface. By studying rocks and soil, Spirit and Opportunity helped scientists understand whether ancient Mars had environments that could have supported life.",
    partsTitle: "Key parts of each rover",
    parts: [
      {
        title: "“Head” & Cameras",
        body: "A tall mast with panoramic cameras to look around and plan safe driving routes.",
      },
      {
        title: "Robotic Arm",
        body: "A flexible arm with a microscope and rock tools to inspect Martian soil up close.",
      },
      {
        title: "Solar Panels",
        body: "Panels that soaked up sunlight to charge their batteries every day.",
      },
    ],
    notes: [
      {
        title: "Airbag landing system",
        body: "Each rover arrived inside a protective airbag shell and a four-petaled landing platform that unfolded like a flower after touchdown.",
      },
      {
        title: "What was left at the landing sites?",
        body: "Once both rovers rolled off onto the Martian ground, their four-petaled landing platforms and deflated airbags stayed behind at the touchdown sites.",
      },
    ],
    whyLeftBehind: [
      {
        title: "Built for a one-way mission",
        body: "NASA never designed Spirit or Opportunity with a return-to-Earth system; they were made to live permanently on Mars and send data back by radio.",
      },
      {
        title: "To search for clues of past water",
        body: "",
        items: [
          "Spirit found: silica-rich soil, suggesting ancient hot spring or steam vent environments, and carbonate-rich rocks that provided evidence of ancient water that was not strongly acidic.",
          "Opportunity found: tiny, round, iron-rich mineral formations nicknamed “blueberries,” along with gypsum veins and clay minerals that provided evidence of ancient water activity.",
        ],
      },
      {
        title: "Stopped by Mars's harsh environment",
        body: "After outlasting their planned 90-Martian-day missions:",
        items: [
          "Spirit: got stuck in soft soil in 2009 and could no longer move to a position that provided enough sunlight for its solar panels. Its last communication reached Earth on March 22, 2010. NASA officially ended recovery attempts on May 25, 2011.",
          "Opportunity: explored Mars for almost 15 years until a massive dust storm in June 2018 blocked sunlight from reaching its solar panels. Its last communication reached Earth on June 10, 2018, and NASA officially declared the mission over on February 13, 2019.",
        ],
      },
    ],
    image: {
      url: merPhoto.url,
      credit: "NASA/JPL (artist concept, PIA04413)",
      sourceUrl: nasa("PIA04413"),
    },
  },
  {
    id: "viking-1",
    planet: "mars",
    name: "Viking 1 Lander",
    nickname: "Thomas Mutch Memorial Station",
    category: "First successful long-term Mars lander",
    missions: "Viking 1 & 2",
    agency: "NASA",
    landed: "July 20, 1976",
    site: "Chryse Planitia (Golden Plain)",
    status: "Silent since a faulty command in November 1982. The orbiter was shut down August 7, 1980.",
    intro:
      "Launched in 1975, Viking 1 touched down safely on July 20, 1976, in a rocky plain called Chryse Planitia (Golden Plain) and became the first spacecraft to operate successfully on the Martian surface for years. (The Soviet Mars 3 lander touched down in 1971, but lost contact seconds later.)",
    partsTitle: "Key parts of the lander",
    parts: [
      {
        title: "Two 360-Degree Cylindrical Scan Cameras",
        body: "Two cameras that captured panoramic images of the Martian surface, including the first image and the first color photograph ever taken from the surface of Mars.",
      },
      {
        title: "Robotic Sampler Arm",
        body: "Extended out to scoop up Martian soil and drop it into the lander's onboard labs.",
      },
      {
        title: "Biology & Chemistry Labs",
        body: "Tested Martian soil for possible signs of life and analyzed its chemical composition. Although some biology experiments produced unexpected results, they provided no definitive evidence of living organisms. The chemical analysis detected abundant sulfur, while Viking's instruments found no detectable organic molecules in the soil at the levels they could measure.",
      },
      {
        title: "Weather Instruments",
        body: "Tracked daily Martian air temperature, pressure, and wind speed.",
      },
      {
        title: "Two Radioisotope Thermoelectric Generators (RTGs)",
        body: "These generators converted heat from the natural decay of plutonium into electricity, providing steady power day and night without relying on sunlight.",
      },
    ],
    notes: [
      {
        title: "Two-part mission (lander & orbiter)",
        body: "The Viking 1 Lander (later renamed the Thomas Mutch Memorial Station) was a three-legged stationary science lab that stayed on the surface of Mars. The Viking 1 Orbiter was a solar-powered spacecraft that stayed in orbit above Mars. Together, the Viking 1 and Viking 2 orbiters mapped about 97% of Mars's surface.",
      },
      {
        title: "Note",
        body: "The lander also carried a seismometer to listen for “marsquakes,” but it failed to operate properly after landing.",
      },
      {
        title: "What happened to the orbiter?",
        body: "The Viking 1 Orbiter was shut down earlier, on August 7, 1980, after running out of attitude-control propellant, and remains in orbit around Mars.",
      },
    ],
    whyLeftBehind: [
      {
        title: "Built for a one-way mission",
        body: "NASA never designed Viking 1 with a system to fly back to Earth; it was built to stay permanently on Mars and send its photos and data home by radio.",
      },
      {
        title: "To explore the surface up close",
        body: "Viking 1 gave scientists their first clear view from the Martian surface, monitored Mars's weather across seasons, and tested Martian soil for chemistry and possible signs of life.",
      },
      {
        title: "Stopped after a faulty command",
        body: "After operating for more than six years, far beyond its planned 90-day mission, a faulty command sent from Earth in November 1982 interrupted communications. NASA's attempts to restore contact were unsuccessful, and the lander never communicated again.",
      },
    ],
    image: {
      url: vikingPhoto.url,
      credit: "NASA/JPL (first color image from Viking Lander 1, PIA00563)",
      sourceUrl: nasa("PIA00563"),
    },
  },
  {
    id: "insight",
    planet: "mars",
    name: "InSight Lander",
    nickname: "The Mars Doctor",
    category: "Stationary deep-interior lander",
    missions: "InSight",
    agency: "NASA",
    landed: "November 26, 2018",
    site: "Elysium Planitia",
    status: "Final communication December 15, 2022. Mission declared over December 21, 2022.",
    intro:
      "Unlike rovers with wheels, InSight was a three-legged robotic lander that stayed in one spot on a flat plain called Elysium Planitia after landing on November 26, 2018. Instead of studying surface rocks, it was the first mission dedicated to studying the deep interior structure of Mars, checking its “vital signs” (pulse, temperature, and wobbles).",
    partsTitle: "Key parts of the lander",
    parts: [
      {
        title: "SEIS (Seismometer)",
        body: "A dome-shaped instrument placed directly on the ground to feel vibrations from “marsquakes” and crashing meteoroids.",
      },
      {
        title: "HP3 (Heat Probe / “The Mole”)",
        body: "A self-hammering probe designed to burrow underground and measure heat escaping from inside Mars (though unexpectedly sticky, clumpy soil prevented it from digging as deep as planned).",
      },
      {
        title: "RISE (Radio Antennas)",
        body: "Precisely tracked the lander's location to measure the tiny wobble of Mars's rotation axis as it orbits the Sun, helping scientists infer the size and composition of Mars's core.",
      },
      {
        title: "Robotic Arm & Solar Panels",
        body: "A mechanical arm lifted the instruments onto the ground, while two fan-shaped solar panels generated electricity from sunlight.",
      },
    ],
    notes: [],
    whyLeftBehind: [
      {
        title: "Built for a one-way mission",
        body: "NASA never designed InSight with a return system; it was made to stay permanently on Mars and send all its data home by radio.",
      },
      {
        title: "To map the inside of Mars",
        body: "Over four years, InSight detected more than 1,300 marsquakes and measured Mars's crust, mantle, and core. Later research published in 2025, using data InSight collected before its mission ended, even revealed giant rocky fragments buried deep inside the mantle from ancient impacts.",
      },
      {
        title: "Powered down by Martian dust",
        body: "Over time, thick layers of dust settled onto InSight's solar panels, cutting off its sunlight and battery power. NASA received its final communication on December 15, 2022, and officially declared the mission over on December 21, 2022, after the lander failed to respond to contact attempts, leaving it resting quietly on Mars.",
      },
    ],
    image: {
      url: insightPhoto.url,
      credit: "NASA/JPL-Caltech (PIA23203)",
      sourceUrl: nasa("PIA23203"),
    },
  },
  {
    id: "ingenuity",
    planet: "mars",
    name: "Ingenuity Mars Helicopter",
    nickname: null,
    category: "First powered flight on another planet",
    missions: "Mars 2020 (with Perseverance)",
    agency: "NASA",
    landed: "February 18, 2021",
    site: "Jezero Crater",
    status: "Flight mission ended January 25, 2024. It rests upright on Mars.",
    intro:
      "Launched on July 30, 2020, Ingenuity rode to Mars attached underneath the Perseverance rover, landing in Jezero Crater on February 18, 2021.",
    partsTitle: "Key parts of the helicopter",
    parts: [
      {
        title: "Counter-Rotating Carbon-Fiber Blades",
        body: "Two sets of blades spinning in opposite directions at ultra-high speeds to lift off in Mars's air (which is extremely thin, with a density of roughly 1% of Earth's atmosphere at sea level).",
      },
      {
        title: "Top Solar Panel",
        body: "Mounted above the blades to recharge its batteries with sunlight every day.",
      },
      {
        title: "Insulated Body & Heaters",
        body: "A small box-shaped body holding computers, flight sensors, and heaters to survive freezing Martian nights.",
      },
      {
        title: "Cameras & Four Landing Legs",
        body: "Navigation and color cameras to track the ground and take aerial photos, supported by four lightweight, springy legs.",
      },
    ],
    notes: [
      {
        title: "A “Wright Brothers moment” on Mars",
        body: "On April 19, 2021, it lifted off into the Martian sky, carrying a tiny swatch of wing fabric from the Wright brothers' 1903 airplane.",
      },
      {
        title: "From test craft to aerial scout",
        body: "Originally planned as a technology demonstration for up to 5 flights in 30 Martian days, it went on to complete 72 flights over nearly three years, scouting paths ahead for Perseverance and testing flight limits.",
      },
    ],
    whyLeftBehind: [
      {
        title: "Built for a one-way mission",
        body: "NASA never designed Ingenuity with a return-to-Earth system; it operated permanently on Mars and sent its photos and flight data back through Perseverance's radio.",
      },
      {
        title: "To prove flying works on Mars",
        body: "Ingenuity proved that helicopters can fly in thin Martian air and scout terrain from above, even photographing Perseverance's discarded landing gear, paving the way for future flying explorers on other worlds.",
      },
      {
        title: "Grounded after rotor blade damage",
        body: "During its 72nd and final flight on January 18, 2024, Ingenuity experienced navigation difficulties while flying over relatively featureless sandy terrain. NASA's investigation found that the lack of surface features likely caused navigation errors, leading to a hard landing that damaged its rotor blades and made further flights impossible. NASA officially ended the helicopter's flight mission on January 25, 2024, confirming that Ingenuity remained upright on the Martian surface and was still in contact with mission controllers at the time, resting permanently on Mars ever since.",
      },
    ],
    image: {
      url: ingenuityPhoto.url,
      credit: "NASA/JPL-Caltech (PIA23882)",
      sourceUrl: nasa("PIA23882"),
    },
  },
];

const byId = new Map(TOOL_INFO.map(t => [t.id, t]));

export function getToolInfo(id: string) {
  return byId.get(id);
}
