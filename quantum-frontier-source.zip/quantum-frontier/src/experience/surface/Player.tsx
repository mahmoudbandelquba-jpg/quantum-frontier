import { useFrame, useThree } from "@react-three/fiber";
import { useEffect, useRef } from "react";
import * as THREE from "three";
import type { ToolPlacement } from "../data/toolTypes";
import type { PlanetConfig } from "../planets";
import { input, player, resetInput } from "../runtime";
import { useExperience } from "../store";
import { emitDust } from "./Dust";
import { getTerrain, ROAM_RADIUS } from "./terrain";

export const EYE_HEIGHT = 1.7;
const LANDING_DURATION = 5.2;
const LANDING_ALTITUDE = 46;
const EXAMINE_FREEZE = 1.8;

/** A placement resolved onto the terrain, with its solid circles in world space. */
export type PlacedTool = ToolPlacement & { y: number; world: { x: number; z: number; r: number }[] };

function lerpAngle(a: number, b: number, t: number) {
  let d = b - a;
  while (d > Math.PI) d -= Math.PI * 2;
  while (d < -Math.PI) d += Math.PI * 2;
  return a + d * t;
}

const MOVE_KEYS = new Set(["KeyW", "KeyA", "KeyS", "KeyD", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"]);

export default function Player({ config, tools }: { config: PlanetConfig; tools: PlacedTool[] }) {
  const { camera, gl } = useThree();
  const terrain = getTerrain(config.id);
  const landingKey = useExperience(s => s.landingKey);

  const L = useRef({
    time: 0,
    landingT: 0,
    vx: 0,
    vz: 0,
    vy: 0,
    dip: 0,
    dipV: 0,
    shake: 0,
    freezeUntil: 0,
    yawTarget: 0,
    pitchTarget: 0,
    examining: null as string | null,
    disarmed: new Set<string>(),
  });

  // Fresh descent each time we arrive on a world.
  useEffect(() => {
    const s = L.current;
    s.landingT = 0;
    s.vx = s.vz = s.vy = 0;
    s.dip = s.dipV = 0;
    s.shake = 0;
    s.freezeUntil = 0;
    s.examining = null;
    s.disarmed.clear();
    player.x = 0;
    player.z = 16;
    player.y = terrain.height(0, 16);
    player.yaw = 0;
    player.pitch = -0.95;
    player.speed = 0;
    player.stepPhase = 0;
    player.altitude = LANDING_ALTITUDE;
    player.reach = 0;
    player.airborne = false;
    camera.rotation.order = "YXZ";
    resetInput();
  }, [landingKey, camera, terrain]);

  // Drag to look (mouse or touch); the joystick captures its own pointer.
  useEffect(() => {
    const el = gl.domElement;
    let active: number | null = null;
    let lastX = 0;
    let lastY = 0;
    const down = (e: PointerEvent) => {
      if (active !== null) return;
      active = e.pointerId;
      lastX = e.clientX;
      lastY = e.clientY;
      el.setPointerCapture?.(e.pointerId);
    };
    const move = (e: PointerEvent) => {
      if (e.pointerId !== active) return;
      const k = e.pointerType === "touch" ? 1.5 : 1;
      input.lookDX += (e.clientX - lastX) * k;
      input.lookDY += (e.clientY - lastY) * k;
      lastX = e.clientX;
      lastY = e.clientY;
    };
    const up = (e: PointerEvent) => {
      if (e.pointerId === active) active = null;
    };
    el.addEventListener("pointerdown", down);
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
    window.addEventListener("pointercancel", up);
    return () => {
      el.removeEventListener("pointerdown", down);
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
      window.removeEventListener("pointercancel", up);
    };
  }, [gl]);

  // Keyboard
  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      if (target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA")) return;
      input.keys.add(e.code);
      if (MOVE_KEYS.has(e.code)) {
        input.lastMoveAt = performance.now();
        e.preventDefault();
      }
      if (e.code === "Space") {
        input.jumpQueued = true;
        e.preventDefault();
      }
    };
    const up = (e: KeyboardEvent) => input.keys.delete(e.code);
    const blur = () => input.keys.clear();
    window.addEventListener("keydown", down);
    window.addEventListener("keyup", up);
    window.addEventListener("blur", blur);
    return () => {
      window.removeEventListener("keydown", down);
      window.removeEventListener("keyup", up);
      window.removeEventListener("blur", blur);
    };
  }, []);

  useFrame((_, rawDt) => {
    const dt = Math.min(rawDt, 0.05);
    const s = L.current;
    s.time += dt;
    const store = useExperience.getState();
    const overlayOpen = !!store.sheetToolId || store.logOpen;
    const frozen = s.time < s.freezeUntil;

    // ---- Look ----
    if (!overlayOpen && !frozen) {
      player.yaw -= input.lookDX * 0.0032;
      player.pitch -= input.lookDY * 0.0032;
      player.pitch = THREE.MathUtils.clamp(player.pitch, -1.35, 1.15);
    }
    input.lookDX = 0;
    input.lookDY = 0;

    let altitude = 0;

    if (store.phase === "landing") {
      // ---- Descent onto the surface ----
      s.landingT += dt;
      const t = Math.min(s.landingT / LANDING_DURATION, 1);
      altitude = LANDING_ALTITUDE * Math.pow(1 - t, 2.1);
      player.z = 16 - 16 * (1 - Math.pow(1 - t, 2));
      player.x = Math.sin(t * Math.PI) * 1.5;
      player.y = terrain.height(player.x, player.z);
      const scriptedPitch = THREE.MathUtils.lerp(-0.95, -0.12, Math.pow(t, 0.8));
      player.pitch = THREE.MathUtils.lerp(player.pitch, scriptedPitch, 1 - Math.exp(-dt * 2.2));
      player.altitude = altitude;
      if (t >= 1) {
        altitude = 0;
        player.altitude = 0;
        s.dipV = config.id === "moon" ? -2.2 : -2.8;
        s.shake = 1;
        emitDust(player.x, player.y, player.z, 1);
        resetInput();
        store.touchdown();
      }
    } else if (store.phase === "explore") {
      // ---- Walking ----
      let fx = 0;
      let fz = 0;
      const k = input.keys;
      if (k.has("KeyW") || k.has("ArrowUp")) fz += 1;
      if (k.has("KeyS") || k.has("ArrowDown")) fz -= 1;
      if (k.has("KeyA") || k.has("ArrowLeft")) fx -= 1;
      if (k.has("KeyD") || k.has("ArrowRight")) fx += 1;
      fx += input.joy.x;
      fz += input.joy.y;
      const mag = Math.hypot(fx, fz);
      if (mag > 1) {
        fx /= mag;
        fz /= mag;
      }
      const blocked = frozen || overlayOpen;
      if (blocked) {
        fx = 0;
        fz = 0;
      }
      const run = k.has("ShiftLeft") || k.has("ShiftRight") ? 1.7 : 1;
      const speed = config.walkSpeed * run;
      const sin = Math.sin(player.yaw);
      const cos = Math.cos(player.yaw);
      const tx = (-sin * fz + cos * fx) * speed;
      const tz = (-cos * fz - sin * fx) * speed;
      const traction = player.airborne ? 0.5 : blocked ? 9 : config.traction;
      const a = 1 - Math.exp(-traction * dt);
      s.vx += (tx - s.vx) * a;
      s.vz += (tz - s.vz) * a;
      player.x += s.vx * dt;
      player.z += s.vz * dt;

      // solid tools
      for (const tool of tools) {
        for (const solid of tool.world) {
          const dx = player.x - solid.x;
          const dz = player.z - solid.z;
          const d = Math.hypot(dx, dz);
          const min = solid.r + 0.35;
          if (d < min && d > 0.0001) {
            player.x = solid.x + (dx / d) * min;
            player.z = solid.z + (dz / d) * min;
          }
        }
      }
      // soft boundary of the exploration zone
      const r = Math.hypot(player.x, player.z);
      if (r > ROAM_RADIUS) {
        player.x *= ROAM_RADIUS / r;
        player.z *= ROAM_RADIUS / r;
      }

      // vertical motion with the planet's real gravity
      const ground = terrain.height(player.x, player.z);
      if (input.jumpQueued && !player.airborne && !blocked) {
        s.vy = config.jumpVelocity;
        player.airborne = true;
      }
      input.jumpQueued = false;
      if (player.airborne) {
        s.vy -= config.gravity * dt;
        player.y += s.vy * dt;
        if (player.y <= ground) {
          const impact = Math.abs(s.vy);
          player.y = ground;
          player.airborne = false;
          s.dipV = -impact * 0.55;
          if (impact > 1.5) emitDust(player.x, ground, player.z, Math.min(0.6, impact * 0.15));
          s.vy = 0;
        }
      } else {
        player.y = THREE.MathUtils.lerp(player.y, ground, 1 - Math.exp(-dt * 18));
      }

      player.speed = Math.hypot(s.vx, s.vz);
      if (!player.airborne) {
        player.stepPhase += player.speed * dt * (config.id === "moon" ? 1.25 : 2.1);
      }

      // ---- Stop and examine nearby tools ----
      let nearest: PlacedTool | null = null;
      let nearestD = Infinity;
      for (const tool of tools) {
        const d = Math.hypot(tool.x - player.x, tool.z - player.z);
        if (s.disarmed.has(tool.id) && d > tool.examineRadius + 2.5) s.disarmed.delete(tool.id);
        if (d < nearestD) {
          nearestD = d;
          nearest = tool;
        }
      }
      if (nearest && nearestD < nearest.examineRadius && !s.disarmed.has(nearest.id) && !overlayOpen) {
        s.disarmed.add(nearest.id);
        s.freezeUntil = s.time + EXAMINE_FREEZE;
        s.vx *= 0.2;
        s.vz *= 0.2;
        const dx = nearest.x - player.x;
        const dz = nearest.z - player.z;
        s.yawTarget = Math.atan2(-dx, -dz);
        const eyeY = player.y + EYE_HEIGHT;
        const focusY = nearest.y + nearest.focusHeight;
        s.pitchTarget = THREE.MathUtils.clamp(Math.atan2(focusY - eyeY, Math.max(nearestD, 0.6)), -1.1, 0.6);
        s.examining = nearest.id;
        store.examine(nearest.id);
      }
      if (s.time < s.freezeUntil) {
        const f = 1 - Math.exp(-dt * 4.5);
        player.yaw = lerpAngle(player.yaw, s.yawTarget, f);
        player.pitch = THREE.MathUtils.lerp(player.pitch, s.pitchTarget, f);
      }
      if (s.examining) {
        const tool = tools.find(t => t.id === s.examining);
        const d = tool ? Math.hypot(tool.x - player.x, tool.z - player.z) : Infinity;
        if (!tool || d > tool.examineRadius + 1.2) {
          s.examining = null;
          if (useExperience.getState().examiningId) store.stopExamining();
        }
      }
    }

    // gloves reach forward while examining
    const reachTarget = s.examining ? 1 : 0;
    player.reach += (reachTarget - player.reach) * (1 - Math.exp(-dt * 4));

    // ---- Camera ----
    s.dipV += (-s.dip * 55 - s.dipV * 9) * dt;
    s.dip += s.dipV * dt;
    s.shake *= Math.exp(-dt * 3.5);
    const moving = Math.min(1, player.speed / 2.2);
    const bob =
      config.id === "moon"
        ? Math.abs(Math.sin(player.stepPhase)) * 0.17 * moving
        : Math.sin(player.stepPhase * 2) * 0.045 * moving;
    const shakeAmp = s.shake * 0.08;
    camera.position.set(
      player.x + (Math.random() - 0.5) * shakeAmp,
      player.y + EYE_HEIGHT + bob + s.dip + altitude,
      player.z + (Math.random() - 0.5) * shakeAmp,
    );
    camera.rotation.set(player.pitch + (Math.random() - 0.5) * shakeAmp * 0.3, player.yaw, 0, "YXZ");
  });

  return null;
}
