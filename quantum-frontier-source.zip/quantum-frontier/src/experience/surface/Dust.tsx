import { useFrame } from "@react-three/fiber";
import { useEffect, useMemo, useRef } from "react";
import * as THREE from "three";
import type { PlanetConfig } from "../planets";

function dotTexture() {
  const size = 64;
  const c = document.createElement("canvas");
  c.width = c.height = size;
  const ctx = c.getContext("2d")!;
  const g = ctx.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
  g.addColorStop(0, "rgba(255,255,255,1)");
  g.addColorStop(0.4, "rgba(255,255,255,0.45)");
  g.addColorStop(1, "rgba(255,255,255,0)");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, size, size);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

type BurstListener = (x: number, y: number, z: number, strength: number) => void;
const listeners = new Set<BurstListener>();

/** Fire a dust burst at a world position (used on touchdown and hops). */
export function emitDust(x: number, y: number, z: number, strength = 1) {
  listeners.forEach(l => l(x, y, z, strength));
}

const BURST_COUNT = 700;

export function DustBursts({ config }: { config: PlanetConfig }) {
  const points = useRef<THREE.Points>(null);
  const tex = useMemo(dotTexture, []);
  const state = useMemo(() => {
    const positions = new Float32Array(BURST_COUNT * 3).fill(-9999);
    const velocities = new Float32Array(BURST_COUNT * 3);
    const life = new Float32Array(BURST_COUNT);
    return { positions, velocities, life, cursor: 0 };
  }, []);

  const geometry = useMemo(() => {
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.BufferAttribute(state.positions, 3));
    return g;
  }, [state]);

  useEffect(() => {
    const listener: BurstListener = (x, y, z, strength) => {
      const n = Math.floor(BURST_COUNT * 0.9 * Math.min(1, strength));
      for (let k = 0; k < n; k++) {
        const i = state.cursor;
        state.cursor = (state.cursor + 1) % BURST_COUNT;
        const ang = Math.random() * Math.PI * 2;
        const sp = (1.4 + Math.random() * 3.6) * strength;
        const r0 = 0.9 + Math.random() * 1.4;
        state.positions[i * 3] = x + Math.cos(ang) * r0;
        state.positions[i * 3 + 1] = y + 0.03;
        state.positions[i * 3 + 2] = z + Math.sin(ang) * r0;
        state.velocities[i * 3] = Math.cos(ang) * sp;
        state.velocities[i * 3 + 1] = (0.25 + Math.random() * 0.95) * strength;
        state.velocities[i * 3 + 2] = Math.sin(ang) * sp;
        state.life[i] = 1;
      }
    };
    listeners.add(listener);
    return () => {
      listeners.delete(listener);
    };
  }, [state]);

  const material = useRef<THREE.PointsMaterial>(null);
  // Without air (Moon) dust flies on clean ballistic arcs; on Mars a thin atmosphere drags it.
  const drag = config.id === "moon" ? 0 : 1.6;

  useFrame((_, rawDt) => {
    const dt = Math.min(rawDt, 0.05);
    let alive = 0;
    for (let i = 0; i < BURST_COUNT; i++) {
      const life = state.life;
      const vel = state.velocities;
      const pos = state.positions;
      if (life[i]! <= 0) continue;
      alive++;
      const o = i * 3;
      vel[o + 1] = vel[o + 1]! - config.gravity * dt;
      if (drag) {
        const f = Math.exp(-drag * dt);
        vel[o] = vel[o]! * f;
        vel[o + 2] = vel[o + 2]! * f;
      }
      pos[o] = pos[o]! + vel[o]! * dt;
      pos[o + 1] = pos[o + 1]! + vel[o + 1]! * dt;
      pos[o + 2] = pos[o + 2]! + vel[o + 2]! * dt;
      life[i] = life[i]! - dt * (config.id === "moon" ? 0.45 : 0.3);
      if (life[i]! <= 0) pos[o + 1] = -9999;
    }
    if (points.current) {
      (points.current.geometry.attributes["position"] as THREE.BufferAttribute).needsUpdate = true;
      points.current.visible = alive > 0;
    }
  });

  return (
    <points ref={points} geometry={geometry} frustumCulled={false}>
      <pointsMaterial
        ref={material}
        map={tex}
        color={config.dustColor}
        size={0.045}
        sizeAttenuation
        transparent
        opacity={0.6}
        depthWrite={false}
      />
    </points>
  );
}

const DRIFT_COUNT = 900;

/** Fine Martian dust drifting in the wind around the astronaut. */
export function DriftingDust({ config }: { config: PlanetConfig }) {
  const ref = useRef<THREE.Points>(null);
  const tex = useMemo(dotTexture, []);
  const geometry = useMemo(() => {
    const g = new THREE.BufferGeometry();
    const p = new Float32Array(DRIFT_COUNT * 3);
    for (let i = 0; i < DRIFT_COUNT; i++) {
      p[i * 3] = (Math.random() - 0.5) * 40;
      p[i * 3 + 1] = Math.random() * 8;
      p[i * 3 + 2] = (Math.random() - 0.5) * 40;
    }
    g.setAttribute("position", new THREE.BufferAttribute(p, 3));
    return g;
  }, []);

  useFrame(({ camera, clock }, rawDt) => {
    const dt = Math.min(rawDt, 0.05);
    const pos = geometry.attributes["position"] as THREE.BufferAttribute;
    const arr = pos.array as Float32Array;
    const t = clock.elapsedTime;
    for (let i = 0; i < DRIFT_COUNT; i++) {
      const o = i * 3;
      let x = arr[o]! + (1.4 + Math.sin(t * 0.3 + i) * 0.4) * dt;
      let y = arr[o + 1]! + Math.sin(t * 0.8 + i * 1.7) * 0.08 * dt;
      let z = arr[o + 2]! + 0.35 * dt;
      // wrap around the camera
      const dx = x - camera.position.x;
      const dz = z - camera.position.z;
      if (dx > 20) x -= 40;
      if (dx < -20) x += 40;
      if (dz > 20) z -= 40;
      if (dz < -20) z += 40;
      const dy = y - camera.position.y;
      if (dy > 6) y -= 9;
      if (dy < -3) y += 9;
      arr[o] = x;
      arr[o + 1] = y;
      arr[o + 2] = z;
    }
    pos.needsUpdate = true;
    if (ref.current) ref.current.position.set(0, 0, 0);
  });

  return (
    <points ref={ref} geometry={geometry} frustumCulled={false}>
      <pointsMaterial
        map={tex}
        color={config.dustColor}
        size={0.05}
        sizeAttenuation
        transparent
        opacity={0.55}
        depthWrite={false}
      />
    </points>
  );
}
