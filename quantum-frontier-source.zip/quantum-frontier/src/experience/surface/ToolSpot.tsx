import { useFrame } from "@react-three/fiber";
import { useEffect, useLayoutEffect, useMemo, useRef } from "react";
import * as THREE from "three";
import { anchors, projectAnchor } from "../anchors";
import { useExperience } from "../store";
import { ToolModel } from "./models/ToolModel";
import type { PlacedTool } from "./Player";
import { getTerrain } from "./terrain";

function useConformingRing(tool: PlacedTool, radius: number, width: number) {
  return useMemo(() => {
    const terrain = getTerrain(tool.planet);
    const geo = new THREE.RingGeometry(radius, radius + width, 72, 1);
    geo.rotateX(-Math.PI / 2);
    const pos = geo.attributes["position"] as THREE.BufferAttribute;
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i);
      const z = pos.getZ(i);
      pos.setY(i, terrain.height(tool.x + x, tool.z + z) - tool.y + 0.035);
    }
    return geo;
  }, [tool, radius, width]);
}

const beaconMaterial = () =>
  new THREE.ShaderMaterial({
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
    side: THREE.DoubleSide,
    uniforms: { uTime: { value: 0 }, uColor: { value: new THREE.Color("#ff5f1f") } },
    vertexShader: `
      varying float vH;
      void main() {
        vH = uv.y;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
      }`,
    fragmentShader: `
      uniform float uTime;
      uniform vec3 uColor;
      varying float vH;
      void main() {
        float a = (1.0 - vH) * (0.32 + 0.12 * sin(uTime * 2.4));
        gl_FragColor = vec4(uColor, a);
      }`,
  });

export default function ToolSpot({ tool }: { tool: PlacedTool }) {
  const discovered = useExperience(s => (s.planet ? s.discovered[s.planet].includes(tool.id) : false));
  const examining = useExperience(s => s.examiningId === tool.id);

  const modelRef = useRef<THREE.Group>(null);
  const ringMat = useRef<THREE.MeshBasicMaterial>(null);
  const beacon = useMemo(beaconMaterial, []);
  const ring = useConformingRing(tool, tool.examineRadius * 0.62, 0.07);
  const iconPoint = useMemo(
    () => new THREE.Vector3(tool.x, tool.y + tool.iconHeight, tool.z),
    [tool],
  );
  const anchorId = `tool:${tool.id}`;

  useEffect(() => () => void anchors.delete(anchorId), [anchorId]);

  useLayoutEffect(() => {
    modelRef.current?.traverse(obj => {
      if ((obj as THREE.Mesh).isMesh) {
        obj.castShadow = true;
        obj.receiveShadow = true;
      }
    });
  }, []);

  useFrame(({ camera, clock, size }) => {
    const t = clock.elapsedTime;
    beacon.uniforms["uTime"]!.value = t;
    if (ringMat.current) {
      ringMat.current.opacity = examining ? 0.9 : discovered ? 0.28 : 0.45 + Math.sin(t * 2.4) * 0.2;
    }
    projectAnchor(anchorId, iconPoint, camera, size);
  });

  return (
    <group position={[tool.x, tool.y, tool.z]}>
      <group ref={modelRef} rotation={[0, tool.rotY, 0]} scale={tool.scale}>
        <ToolModel id={tool.id} />
      </group>

      <mesh geometry={ring}>
        <meshBasicMaterial
          ref={ringMat}
          color={discovered && !examining ? "#eaf2ff" : "#ff5f1f"}
          transparent
          depthWrite={false}
          side={THREE.DoubleSide}
        />
      </mesh>

      {!discovered && (
        <mesh position={[0, 7, 0]} material={beacon}>
          <cylinderGeometry args={[0.05, 0.05, 14, 8, 1, true]} />
        </mesh>
      )}
    </group>
  );
}
