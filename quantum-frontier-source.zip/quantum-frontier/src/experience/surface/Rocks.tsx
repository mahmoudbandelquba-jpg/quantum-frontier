import { useLayoutEffect, useMemo, useRef } from "react";
import * as THREE from "three";
import type { PlanetConfig } from "../planets";
import { placementsFor } from "../data/toolTypes";
import { getTerrain, mulberry32 } from "./terrain";
import { makeRockGeometry } from "./models/materials";

export default function Rocks({ config }: { config: PlanetConfig }) {
  const smallRef = useRef<THREE.InstancedMesh>(null);
  const bigRef = useRef<THREE.InstancedMesh>(null);
  const terrain = getTerrain(config.id);

  const geoSmall = useMemo(() => makeRockGeometry(7), []);
  const geoBig = useMemo(() => makeRockGeometry(42), []);

  const { small, big } = useMemo(() => {
    const rand = mulberry32(config.id === "moon" ? 11 : 23);
    const keep = placementsFor(config.id).map(p => ({ x: p.x, z: p.z, r: p.footprint }));
    keep.push({ x: 0, z: 0, r: 0 });
    const ok = (x: number, z: number, clear: number) =>
      keep.every(p => Math.hypot(p.x - x, p.z - z) > clear + p.r);

    const small: THREE.Matrix4[] = [];
    const big: THREE.Matrix4[] = [];
    const m = new THREE.Matrix4();
    const q = new THREE.Quaternion();
    const e = new THREE.Euler();
    const s = new THREE.Vector3();
    const p = new THREE.Vector3();

    let guard = 0;
    const smallCount = config.id === "moon" ? 520 : 680;
    while (small.length < smallCount && guard++ < 6000) {
      const ang = rand() * Math.PI * 2;
      const dist = 3 + Math.sqrt(rand()) * 140;
      const x = Math.cos(ang) * dist;
      const z = Math.sin(ang) * dist;
      if (!ok(x, z, 2.2)) continue;
      const scale = 0.06 + Math.pow(rand(), 3) * 0.55;
      e.set(rand() * 0.6, rand() * Math.PI * 2, rand() * 0.6);
      q.setFromEuler(e);
      s.set(scale * (0.8 + rand() * 0.6), scale, scale * (0.8 + rand() * 0.6));
      p.set(x, terrain.height(x, z) + scale * 0.15, z);
      small.push(m.compose(p, q, s).clone());
    }
    guard = 0;
    const bigCount = config.id === "moon" ? 26 : 40;
    while (big.length < bigCount && guard++ < 3000) {
      const ang = rand() * Math.PI * 2;
      const dist = 14 + Math.sqrt(rand()) * 120;
      const x = Math.cos(ang) * dist;
      const z = Math.sin(ang) * dist;
      if (!ok(x, z, 7)) continue;
      const scale = 0.8 + rand() * 1.9;
      e.set(rand() * 0.3, rand() * Math.PI * 2, rand() * 0.3);
      q.setFromEuler(e);
      s.set(scale * (0.9 + rand() * 0.7), scale * (0.8 + rand() * 0.5), scale);
      p.set(x, terrain.height(x, z) + scale * 0.05, z);
      big.push(m.compose(p, q, s).clone());
    }
    return { small, big };
  }, [config.id, terrain]);

  useLayoutEffect(() => {
    small.forEach((mat, i) => smallRef.current?.setMatrixAt(i, mat));
    big.forEach((mat, i) => bigRef.current?.setMatrixAt(i, mat));
    if (smallRef.current) smallRef.current.instanceMatrix.needsUpdate = true;
    if (bigRef.current) bigRef.current.instanceMatrix.needsUpdate = true;
  }, [small, big]);

  return (
    <group>
      <instancedMesh ref={smallRef} args={[geoSmall, undefined, small.length]} castShadow receiveShadow>
        <meshStandardMaterial color={config.rockColor} roughness={0.95} flatShading />
      </instancedMesh>
      <instancedMesh ref={bigRef} args={[geoBig, undefined, big.length]} castShadow receiveShadow>
        <meshStandardMaterial color={config.rockColor} roughness={0.92} flatShading />
      </instancedMesh>
    </group>
  );
}
