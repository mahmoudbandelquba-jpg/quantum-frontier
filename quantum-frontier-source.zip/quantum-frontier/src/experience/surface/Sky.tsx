import { Stars } from "@react-three/drei";
import { useFrame } from "@react-three/fiber";
import { useEffect, useMemo, useRef } from "react";
import * as THREE from "three";
import { TEXTURES } from "../assets";
import type { PlanetConfig } from "../planets";
import { useSafeTexture } from "../useSafeTexture";

function glowTexture(inner: string, outer: string) {
  const size = 256;
  const canvas = document.createElement("canvas");
  canvas.width = canvas.height = size;
  const ctx = canvas.getContext("2d")!;
  const g = ctx.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
  g.addColorStop(0, inner);
  g.addColorStop(0.12, inner);
  g.addColorStop(0.35, outer);
  g.addColorStop(1, "rgba(0,0,0,0)");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, size, size);
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

/** Sun sprite that stays locked to the sky (follows the camera). */
function Sun({ config, size }: { config: PlanetConfig; size: number }) {
  const ref = useRef<THREE.Sprite>(null);
  const dir = useMemo(() => new THREE.Vector3(...config.sunDirection).normalize(), [config]);
  const tex = useMemo(
    () =>
      config.sky === "space"
        ? glowTexture("rgba(255,255,255,1)", "rgba(200,220,255,0.18)")
        : glowTexture("rgba(255,250,240,1)", "rgba(190,215,255,0.22)"),
    [config.sky],
  );
  useFrame(({ camera }) => {
    if (!ref.current) return;
    ref.current.position.copy(camera.position).addScaledVector(dir, 900);
  });
  return (
    <sprite ref={ref} scale={[size, size, 1]} renderOrder={-1}>
      <spriteMaterial map={tex} transparent depthWrite={false} fog={false} blending={THREE.AdditiveBlending} />
    </sprite>
  );
}

function EarthInSky({ config }: { config: PlanetConfig }) {
  const group = useRef<THREE.Group>(null);
  const earth = useRef<THREE.Mesh>(null);
  const map = useSafeTexture(TEXTURES.earthMap);
  // Earth hangs above the horizon, to the right of the landing view.
  const dir = useMemo(() => new THREE.Vector3(0.55, 0.3, -1).normalize(), []);
  const material = useMemo(() => {
    // Light Earth from the Sun's side so it shows a gibbous phase.
    const sun = new THREE.Vector3(...config.sunDirection).normalize();
    const light = sun.clone().add(dir.clone().negate().multiplyScalar(0.9)).normalize();
    return new THREE.ShaderMaterial({
      fog: false,
      uniforms: {
        uMap: { value: null as THREE.Texture | null },
        uHasMap: { value: 0 },
        uLight: { value: light },
      },
      vertexShader: `
        varying vec2 vUv;
        varying vec3 vNormalW;
        varying vec3 vViewDirW;
        void main() {
          vUv = uv;
          vec4 wp = modelMatrix * vec4(position, 1.0);
          vNormalW = normalize(mat3(modelMatrix) * normal);
          vViewDirW = normalize(cameraPosition - wp.xyz);
          gl_Position = projectionMatrix * viewMatrix * wp;
        }`,
      fragmentShader: `
        uniform sampler2D uMap;
        uniform float uHasMap;
        uniform vec3 uLight;
        varying vec2 vUv;
        varying vec3 vNormalW;
        varying vec3 vViewDirW;
        void main() {
          vec3 base = mix(vec3(0.16, 0.34, 0.7), texture2D(uMap, vUv).rgb, uHasMap);
          float ndl = dot(normalize(vNormalW), uLight);
          float day = smoothstep(-0.08, 0.35, ndl);
          vec3 col = base * (0.02 + 1.35 * day);
          float fres = pow(1.0 - max(dot(normalize(vNormalW), vViewDirW), 0.0), 2.4);
          col += vec3(0.32, 0.56, 1.0) * fres * (0.15 + 0.85 * smoothstep(-0.25, 0.4, ndl));
          gl_FragColor = vec4(col, 1.0);
          #include <colorspace_fragment>
        }`,
    });
  }, [config.sunDirection, dir]);

  useEffect(() => {
    material.uniforms["uMap"]!.value = map;
    material.uniforms["uHasMap"]!.value = map ? 1 : 0;
  }, [map, material]);

  useFrame(({ camera }, dt) => {
    if (group.current) group.current.position.copy(camera.position).addScaledVector(dir, 760);
    if (earth.current) earth.current.rotation.y += dt * 0.01;
  });
  return (
    <group ref={group}>
      <mesh ref={earth} material={material} rotation={[0.41, 2.2, 0]}>
        <sphereGeometry args={[30, 64, 64]} />
      </mesh>
    </group>
  );
}

function MarsSky({ config }: { config: PlanetConfig }) {
  const ref = useRef<THREE.Mesh>(null);
  const material = useMemo(
    () =>
      new THREE.ShaderMaterial({
        side: THREE.BackSide,
        depthWrite: false,
        fog: false,
        uniforms: {
          uSun: { value: new THREE.Vector3(...config.sunDirection).normalize() },
        },
        vertexShader: `
          varying vec3 vDir;
          void main() {
            vDir = normalize(position);
            gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
          }`,
        fragmentShader: `
          uniform vec3 uSun;
          varying vec3 vDir;
          void main() {
            float h = clamp(vDir.y, -0.2, 1.0);
            vec3 horizon = vec3(0.86, 0.66, 0.50);
            vec3 mid = vec3(0.74, 0.52, 0.38);
            vec3 zenith = vec3(0.42, 0.28, 0.24);
            vec3 col = mix(horizon, mid, smoothstep(0.0, 0.25, h));
            col = mix(col, zenith, smoothstep(0.25, 1.0, h));
            float s = max(dot(normalize(vDir), uSun), 0.0);
            // Martian daytime sky: pale, slightly bluish halo around the sun
            col += vec3(0.55, 0.62, 0.72) * pow(s, 24.0) * 0.55;
            col += vec3(0.95, 0.85, 0.7) * pow(s, 6.0) * 0.18;
            col = mix(col, vec3(0.79, 0.6, 0.45), smoothstep(0.02, -0.2, h));
            gl_FragColor = vec4(col, 1.0);
          }`,
      }),
    [config.sunDirection],
  );
  useFrame(({ camera }) => {
    ref.current?.position.copy(camera.position);
  });
  return (
    <mesh ref={ref} material={material} renderOrder={-2}>
      <sphereGeometry args={[1000, 48, 24]} />
    </mesh>
  );
}

export default function Sky({ config }: { config: PlanetConfig }) {
  if (config.sky === "space") {
    return (
      <>
        <Stars radius={600} depth={120} count={7000} factor={5} saturation={0} fade speed={0.3} />
        <EarthInSky config={config} />
        <Sun config={config} size={140} />
      </>
    );
  }
  return (
    <>
      <MarsSky config={config} />
      <Sun config={config} size={70} />
    </>
  );
}
