import { createNoise2D } from "simplex-noise";
import type { PlanetId } from "../store";
import { placementsFor } from "../data/toolTypes";

export const TERRAIN_SIZE = 420;
export const TERRAIN_SEGMENTS = 300;
/** Radius the astronaut can roam before hitting the soft boundary. */
export const ROAM_RADIUS = 96;

export function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function smoothstep(e0: number, e1: number, x: number) {
  const t = Math.min(1, Math.max(0, (x - e0) / (e1 - e0)));
  return t * t * (3 - 2 * t);
}

interface Crater {
  x: number;
  z: number;
  r: number;
  depth: number;
  rim: number;
}

export interface Terrain {
  height: (x: number, z: number) => number;
  /** 0..1 value used to tint vertices (crater floors, dunes...). */
  shade: (x: number, z: number) => number;
  craters: Crater[];
}

function makeCraters(planet: PlanetId, rand: () => number, count: number, maxR: number): Crater[] {
  const keepClear = placementsFor(planet).map(p => ({ x: p.x, z: p.z, r: p.footprint }));
  keepClear.push({ x: 0, z: 0, r: 0 });
  const craters: Crater[] = [];
  let guard = 0;
  while (craters.length < count && guard++ < 4000) {
    const r = 2.5 + Math.pow(rand(), 2.2) * maxR;
    const ang = rand() * Math.PI * 2;
    const dist = Math.sqrt(rand()) * 150;
    const x = Math.cos(ang) * dist;
    const z = Math.sin(ang) * dist;
    const blocked = keepClear.some(p => Math.hypot(p.x - x, p.z - z) < r * 1.45 + 3.5 + p.r);
    if (blocked) continue;
    craters.push({ x, z, r, depth: r * (planet === "moon" ? 0.2 : 0.12), rim: r * 0.07 });
  }
  return craters;
}

function craterProfile(d: number, c: Crater) {
  // d is distance / radius
  if (d < 1) {
    const bowl = c.depth * (d * d - 1);
    const rim = c.rim * Math.exp(-Math.pow((d - 1) / 0.22, 2));
    return bowl + rim;
  }
  return c.rim * Math.exp(-Math.pow((d - 1) / 0.38, 2));
}

const cache: Partial<Record<PlanetId, Terrain>> = {};

export function getTerrain(planet: PlanetId): Terrain {
  const existing = cache[planet];
  if (existing) return existing;

  const rand = mulberry32(planet === "moon" ? 1969 : 2021);
  const n1 = createNoise2D(rand);
  const n2 = createNoise2D(rand);
  const n3 = createNoise2D(rand);

  const fbm = (x: number, z: number, oct: number) => {
    let amp = 1;
    let freq = 1;
    let sum = 0;
    let norm = 0;
    for (let i = 0; i < oct; i++) {
      sum += amp * n1(x * freq, z * freq);
      norm += amp;
      amp *= 0.5;
      freq *= 2.03;
    }
    return sum / norm;
  };

  const craters =
    planet === "moon" ? makeCraters(planet, rand, 46, 20) : makeCraters(planet, rand, 9, 12);

  const craterSum = (x: number, z: number) => {
    let h = 0;
    for (const c of craters) {
      const dx = x - c.x;
      const dz = z - c.z;
      const reach = c.r * 2.2;
      if (Math.abs(dx) > reach || Math.abs(dz) > reach) continue;
      const d = Math.sqrt(dx * dx + dz * dz) / c.r;
      h += craterProfile(d, c);
    }
    return h;
  };

  let height: (x: number, z: number) => number;
  let shade: (x: number, z: number) => number;

  if (planet === "moon") {
    height = (x, z) => {
      const r = Math.sqrt(x * x + z * z);
      const base = fbm(x * 0.011, z * 0.011, 4) * 2.4;
      const detail = n2(x * 0.09, z * 0.09) * 0.18 + n3(x * 0.35, z * 0.35) * 0.04;
      const ridged = 1 - Math.abs(n3(x * 0.006, z * 0.006));
      const far = smoothstep(100, 200, r) * (10 + 34 * ridged * ridged);
      return base + detail + craterSum(x, z) + far;
    };
    shade = (x, z) => {
      const v = 0.5 + 0.5 * n2(x * 0.03 + 11, z * 0.03 - 7);
      return v;
    };
  } else {
    height = (x, z) => {
      const r = Math.sqrt(x * x + z * z);
      const base = fbm(x * 0.009, z * 0.009, 4) * 1.8;
      // wind-sculpted ripples
      const dune = Math.pow(1 - Math.abs(n2(x * 0.028 + z * 0.012, z * 0.02)), 3) * 0.9;
      const detail = n3(x * 0.12, z * 0.12) * 0.12;
      const mesa = n1(x * 0.004 + 5, z * 0.004 - 3);
      const far = smoothstep(90, 190, r) * (16 + 40 * Math.max(0, mesa + 0.35));
      return base + dune + detail + craterSum(x, z) + far;
    };
    shade = (x, z) => {
      const v = 0.5 + 0.5 * n3(x * 0.02 - 4, z * 0.02 + 9);
      return v;
    };
  }

  // Level a pad under each spacecraft so landing legs and wheels sit on the ground.
  const raw = height;
  const pads = placementsFor(planet).map(p => ({ x: p.x, z: p.z, r: p.footprint, h: raw(p.x, p.z) }));
  height = (x, z) => {
    let h = raw(x, z);
    for (const p of pads) {
      const d = Math.hypot(x - p.x, z - p.z);
      if (d < p.r * 1.6) h = p.h + (h - p.h) * smoothstep(p.r * 0.75, p.r * 1.6, d);
    }
    return h;
  };

  const terrain = { height, shade, craters };
  cache[planet] = terrain;
  return terrain;
}
