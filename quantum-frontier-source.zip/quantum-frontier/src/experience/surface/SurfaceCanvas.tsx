import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { Suspense, useEffect, useMemo, useRef } from "react";
import * as THREE from "three";
import { placementsFor } from "../data/toolTypes";
import { PLANETS } from "../planets";
import { player } from "../runtime";
import type { PlanetId } from "../store";
import { DriftingDust, DustBursts } from "./Dust";
import Player, { type PlacedTool } from "./Player";
import Rocks from "./Rocks";
import Sky from "./Sky";
import { getTerrain } from "./terrain";
import Terrain from "./Terrain";
import ToolSpot from "./ToolSpot";

/** Directional sun that follows the astronaut so shadows stay crisp nearby. */
function SunLight({ planet }: { planet: PlanetId }) {
  const config = PLANETS[planet];
  const light = useRef<THREE.DirectionalLight>(null);
  const { scene } = useThree();
  const dir = useMemo(() => new THREE.Vector3(...config.sunDirection).normalize(), [config]);

  useEffect(() => {
    const l = light.current;
    if (!l) return;
    scene.add(l.target);
    return () => {
      scene.remove(l.target);
    };
  }, [scene]);

  useFrame(() => {
    const l = light.current;
    if (!l) return;
    l.target.position.set(player.x, player.y, player.z);
    l.position.set(player.x, player.y, player.z).addScaledVector(dir, 70);
    l.target.updateMatrixWorld();
  });

  return (
    <directionalLight
      ref={light}
      color={config.sunColor}
      intensity={config.sunIntensity}
      castShadow
      shadow-mapSize={[2048, 2048]}
      shadow-bias={-0.0004}
      shadow-normalBias={0.04}
      shadow-camera-left={-36}
      shadow-camera-right={36}
      shadow-camera-top={36}
      shadow-camera-bottom={-36}
      shadow-camera-near={1}
      shadow-camera-far={160}
    />
  );
}

function World({ planet }: { planet: PlanetId }) {
  const config = PLANETS[planet];
  const terrain = getTerrain(planet);
  const tools: PlacedTool[] = useMemo(
    () =>
      placementsFor(planet).map(p => {
        const cos = Math.cos(p.rotY);
        const sin = Math.sin(p.rotY);
        return {
          ...p,
          y: terrain.height(p.x, p.z),
          // Same rotation three.js applies to the model group (about +Y).
          world: p.solids.map(s => ({
            x: p.x + (s.x * cos + s.z * sin) * p.scale,
            z: p.z + (-s.x * sin + s.z * cos) * p.scale,
            r: s.r * p.scale,
          })),
        };
      }),
    [planet, terrain],
  );

  return (
    <>
      <color attach="background" args={[config.background]} />
      {config.fog && <fogExp2 attach="fog" args={[config.fog.color, config.fog.density]} />}
      <ambientLight color={config.ambient.color} intensity={config.ambient.intensity} />
      <hemisphereLight args={[config.hemi.sky, config.hemi.ground, config.hemi.intensity]} />
      <SunLight planet={planet} />
      <Sky config={config} />
      <Terrain config={config} />
      <Rocks config={config} />
      {tools.map(tool => (
        <ToolSpot key={tool.id} tool={tool} />
      ))}
      <DustBursts config={config} />
      {planet === "mars" && <DriftingDust config={config} />}
      <Player config={config} tools={tools} />
    </>
  );
}

export default function SurfaceCanvas({ planet }: { planet: PlanetId }) {
  return (
    <Canvas
      className="!absolute inset-0"
      shadows
      dpr={[1, 1.75]}
      gl={{ antialias: true, powerPreference: "high-performance" }}
      camera={{ fov: 70, near: 0.05, far: 2600, position: [0, 50, 16] }}
      style={{ touchAction: "none" }}
    >
      <Suspense fallback={null}>
        <World planet={planet} />
      </Suspense>
    </Canvas>
  );
}
