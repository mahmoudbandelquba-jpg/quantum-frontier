import FieldLog from "../hud/FieldLog";
import ExploreHUD from "../hud/ExploreHUD";
import InfoSheet from "../hud/InfoSheet";
import ToolIconLayer from "../hud/ToolIconLayer";
import TouchControls from "../hud/TouchControls";
import { PLANETS } from "../planets";
import { useExperience } from "../store";
import Gloves from "../suit/Gloves";
import Visor from "../suit/Visor";
import SurfaceCanvas from "./SurfaceCanvas";

export default function SurfaceStage() {
  const planet = useExperience(s => s.planet);
  const phase = useExperience(s => s.phase);
  const landingKey = useExperience(s => s.landingKey);
  if (!planet) return null;
  const config = PLANETS[planet];

  return (
    <div className="absolute inset-0 overflow-hidden" style={{ background: config.background }}>
      <SurfaceCanvas key={`${planet}-${landingKey}`} planet={planet} />
      <ToolIconLayer />
      <Gloves mode="surface" planet={planet} />
      <Visor sealed planet={planet} />
      <ExploreHUD />
      {phase === "explore" && <TouchControls />}
      <FieldLog />
      <InfoSheet />
      {/* arrival flash from the jump */}
      <div
        key={landingKey}
        className="pointer-events-none absolute inset-0 z-[60]"
        style={{ background: config.flashColor, animation: "flash-out 1.6s ease-out both" }}
      />
    </div>
  );
}
