import { useMemo } from "react";
import * as THREE from "three";
import { M, makeRockGeometry } from "./materials";
import { Hp3Mole, Seis } from "./MarsTools";
import { makeTriangle, Rtg, Strut, Wheel } from "./parts";

const PI = Math.PI;

/** Lumpy, deflated airbag lobes draped on the ground. */
function Airbags({ seed, count = 3, spread = 0.5, size = 0.32 }: { seed: number; count?: number; spread?: number; size?: number }) {
  const geos = useMemo(() => Array.from({ length: count }, (_, i) => makeRockGeometry(seed + i * 13, 0.42)), [seed, count]);
  return (
    <group>
      {geos.map((g, i) => {
        const t = count === 1 ? 0 : i / (count - 1) - 0.5;
        return (
          <mesh
            key={i}
            geometry={g}
            material={M.airbag}
            position={[t * spread * 2, size * 0.25, (i % 2) * 0.12]}
            scale={[size, size * 0.55, size * 0.8]}
            rotation={[0, i * 1.3, 0]}
          />
        );
      })}
    </group>
  );
}

/** Petal-style landing platform with N triangular petals opened flat on the ground. */
function PetalPlatform({ petals, base, reach, petalMaterial, baseMaterial = M.lmFoil, baseHeight = 0.35 }: {
  petals: number;
  base: number;
  reach: number;
  petalMaterial: THREE.Material;
  baseMaterial?: THREE.Material;
  baseHeight?: number;
}) {
  const geos = useMemo(() => {
    const out: { geo: THREE.BufferGeometry; mid: number }[] = [];
    for (let i = 0; i < petals; i++) {
      const a0 = PI / 2 + (i / petals) * PI * 2 - PI / petals;
      const a1 = a0 + (PI * 2) / petals;
      const mid = (a0 + a1) / 2;
      const p0: [number, number] = [Math.cos(a0) * base, Math.sin(a0) * base];
      const p1: [number, number] = [Math.cos(a1) * base, Math.sin(a1) * base];
      const apex: [number, number] = [Math.cos(mid) * reach, Math.sin(mid) * reach];
      out.push({ geo: makeTriangle(p0, p1, apex, 0.03), mid });
    }
    return out;
  }, [petals, base, reach]);
  return (
    <group>
      <mesh material={baseMaterial} position={[0, baseHeight / 2 + 0.04, 0]} rotation={[0, petals === 3 ? PI / 6 : PI / 4, 0]}>
        <cylinderGeometry args={[base * 0.92, base, baseHeight, petals]} />
      </mesh>
      {geos.map(({ geo, mid }) => (
        <group key={mid}>
          <mesh geometry={geo} material={petalMaterial} position={[0, 0.04, 0]} />
          <group position={[Math.cos(mid + PI / petals) * base * 1.25, 0, Math.sin(mid + PI / petals) * base * 1.25]} rotation={[0, -(mid + PI / petals) + PI / 2, 0]}>
            <Airbags seed={Math.round(mid * 100)} count={3} spread={0.32} size={0.3} />
          </group>
        </group>
      ))}
    </group>
  );
}

/** Sojourner: the small six-wheeled rover that rolled down Pathfinder's ramp. */
export function SojournerRover() {
  const wheels: [number, number][] = [];
  for (const x of [0.25, -0.25]) for (const z of [0.24, 0, -0.24]) wheels.push([x, z]);
  return (
    <group>
      {wheels.map(([x, z]) => (
        <group key={`${x}${z}`}>
          <group position={[x, 0.065, z]}>
            <Wheel r={0.065} w={0.075} material={M.steel} />
          </group>
          <Strut from={[x * 0.75, 0.2, z * 0.6]} to={[x, 0.065, z]} r={0.008} material={M.darkMetal} />
        </group>
      ))}
      {/* warm electronics box */}
      <mesh material={M.goldFoil} position={[0, 0.2, 0]}>
        <boxGeometry args={[0.36, 0.12, 0.42]} />
      </mesh>
      {/* solar panel */}
      <mesh material={M.solar} position={[0, 0.28, 0]}>
        <boxGeometry args={[0.48, 0.012, 0.6]} />
      </mesh>
      {/* front cameras */}
      {[0.06, -0.06].map(x => (
        <mesh key={x} material={M.black} position={[x, 0.2, 0.22]}>
          <boxGeometry args={[0.04, 0.04, 0.03]} />
        </mesh>
      ))}
      {/* APXS on the rear */}
      <Strut from={[0, 0.18, -0.21]} to={[0, 0.1, -0.31]} r={0.008} />
      <mesh material={M.aluminum} position={[0, 0.08, -0.33]}>
        <cylinderGeometry args={[0.025, 0.025, 0.05, 12]} />
      </mesh>
      {/* antenna */}
      <Strut from={[0.14, 0.29, -0.2]} to={[0.14, 0.55, -0.2]} r={0.004} material={M.black} />
    </group>
  );
}

/** Mars Pathfinder (Carl Sagan Memorial Station) with petals, airbags and Sojourner. */
export function PathfinderSite() {
  const yogi = useMemo(() => makeRockGeometry(1997, 0.65), []);
  return (
    <group>
      <PetalPlatform petals={3} base={0.55} reach={1.35} petalMaterial={M.solar} />
      {/* camera mast (IMP) */}
      <Strut from={[0, 0.4, 0]} to={[0, 1.15, 0]} r={0.025} material={M.white} />
      <group position={[0, 1.2, 0]}>
        <mesh material={M.white}>
          <boxGeometry args={[0.22, 0.1, 0.1]} />
        </mesh>
        {[0.07, -0.07].map(x => (
          <mesh key={x} material={M.lens} position={[x, 0, 0.055]} rotation={[PI / 2, 0, 0]}>
            <cylinderGeometry args={[0.025, 0.025, 0.02, 12]} />
          </mesh>
        ))}
      </group>
      {/* weather mast */}
      <Strut from={[-0.8, 0.07, -0.5]} to={[-0.8, 1.05, -0.5]} r={0.01} material={M.white} />
      {[0.45, 0.7, 0.95].map(y => (
        <mesh key={y} material={M.offWhite} position={[-0.8, y, -0.44]}>
          <boxGeometry args={[0.02, 0.06, 0.1]} />
        </mesh>
      ))}
      {/* high-gain antenna */}
      <Strut from={[0.25, 0.4, -0.15]} to={[0.25, 0.65, -0.15]} r={0.015} />
      <mesh material={M.white} position={[0.25, 0.7, -0.15]} rotation={[0.6, 0, 0]}>
        <cylinderGeometry args={[0.14, 0.14, 0.02, 20]} />
      </mesh>
      {/* ramp onto the ground */}
      <mesh material={M.silverFoil} position={[0.95, 0.06, 0.5]} rotation={[0, -1.0, 0.05]}>
        <boxGeometry args={[0.7, 0.01, 0.16]} />
      </mesh>
      {/* Sojourner beside a rock, analysing it with the APXS */}
      <group position={[1.6, 0, 1.0]} rotation={[0, 2.4, 0]}>
        <SojournerRover />
      </group>
      <mesh geometry={yogi} material={M.marsRock} position={[2.05, 0.18, 1.5]} scale={[0.4, 0.38, 0.35]} />
    </group>
  );
}

/** Mars Exploration Rover (Spirit / Opportunity). */
export function MerRover() {
  const wheels: [number, number][] = [];
  for (const x of [0.62, -0.62]) for (const z of [0.55, 0, -0.55]) wheels.push([x, z]);
  return (
    <group>
      {wheels.map(([x, z]) => (
        <group key={`${x}${z}`} position={[x, 0.13, z]}>
          <Wheel r={0.13} w={0.16} material={M.aluminum} hub={M.darkMetal} />
        </group>
      ))}
      {/* rocker-bogie suspension */}
      {[0.62, -0.62].map(x => (
        <group key={x}>
          <Strut from={[x * 0.82, 0.48, 0.05]} to={[x, 0.13, 0.55]} r={0.02} material={M.offWhite} />
          <Strut from={[x * 0.82, 0.48, 0.05]} to={[x, 0.33, -0.28]} r={0.02} material={M.offWhite} />
          <Strut from={[x, 0.33, -0.28]} to={[x, 0.13, 0]} r={0.018} material={M.offWhite} />
          <Strut from={[x, 0.33, -0.28]} to={[x, 0.13, -0.55]} r={0.018} material={M.offWhite} />
        </group>
      ))}
      {/* warm electronics box */}
      <mesh material={M.lmFoil} position={[0, 0.58, 0]}>
        <boxGeometry args={[0.8, 0.3, 1.0]} />
      </mesh>
      {/* solar arrays: deck, side wings and tail */}
      <mesh material={M.solar} position={[0, 0.76, -0.05]}>
        <boxGeometry args={[1.0, 0.03, 1.25]} />
      </mesh>
      {[1, -1].map(s => (
        <mesh key={s} material={M.solar} position={[s * 0.78, 0.76, -0.15]} rotation={[0, 0, s * -0.04]}>
          <boxGeometry args={[0.56, 0.025, 0.85]} />
        </mesh>
      ))}
      <mesh material={M.solar} position={[0, 0.76, -0.9]}>
        <boxGeometry args={[0.9, 0.025, 0.45]} />
      </mesh>
      {/* Pancam mast ("head") */}
      <Strut from={[0.25, 0.78, 0.45]} to={[0.25, 1.42, 0.45]} r={0.03} material={M.white} />
      <group position={[0.25, 1.48, 0.47]}>
        <mesh material={M.white}>
          <boxGeometry args={[0.34, 0.1, 0.1]} />
        </mesh>
        {[0.12, -0.12, 0.03, -0.03].map(x => (
          <mesh key={x} material={M.lens} position={[x, 0, 0.055]} rotation={[PI / 2, 0, 0]}>
            <cylinderGeometry args={[0.018, 0.018, 0.015, 10]} />
          </mesh>
        ))}
      </group>
      {/* high-gain dish and low-gain antenna */}
      <Strut from={[-0.3, 0.78, 0.05]} to={[-0.3, 0.98, 0.05]} r={0.02} />
      <mesh material={M.white} position={[-0.3, 1.02, 0.05]} rotation={[0.5, 0, 0.2]}>
        <cylinderGeometry args={[0.14, 0.14, 0.03, 20]} />
      </mesh>
      <Strut from={[-0.35, 0.78, -0.45]} to={[-0.35, 1.3, -0.45]} r={0.008} material={M.black} />
      {/* robotic arm with its instrument turret */}
      <Strut from={[0.15, 0.48, 0.5]} to={[0.18, 0.55, 0.85]} r={0.022} material={M.offWhite} />
      <Strut from={[0.18, 0.55, 0.85]} to={[0.12, 0.22, 1.05]} r={0.02} material={M.offWhite} />
      <mesh material={M.aluminum} position={[0.12, 0.15, 1.08]}>
        <boxGeometry args={[0.1, 0.1, 0.1]} />
      </mesh>
    </group>
  );
}

/** Spirit / Opportunity with the four-petaled landing platform and airbags left behind. */
export function MerSite() {
  return (
    <group>
      <MerRover />
      <group position={[-3.6, 0, -2.4]} rotation={[0, 0.5, 0]}>
        <PetalPlatform petals={4} base={0.6} reach={1.3} petalMaterial={M.offWhite} baseMaterial={M.lmFoil} baseHeight={0.2} />
      </group>
      {/* faint wheel tracks leading away from the lander */}
      {[0.62, -0.62].map(x => (
        <mesh key={x} material={M.marsMound} position={[x * 0.9 - 1.6, 0.005, -1.0]} rotation={[0, 0.98, 0]}>
          <boxGeometry args={[0.14, 0.01, 3.2]} />
        </mesh>
      ))}
    </group>
  );
}

/** Viking 1 Lander (Thomas Mutch Memorial Station). */
export function VikingLander() {
  const legs = [0, (2 * PI) / 3, (4 * PI) / 3];
  const furrow = useMemo(() => makeRockGeometry(76, 0.2), []);
  return (
    <group>
      {/* hexagonal body */}
      <mesh material={M.offWhite} position={[0, 0.72, 0]}>
        <cylinderGeometry args={[0.78, 0.78, 0.42, 6]} />
      </mesh>
      <mesh material={M.darkMetal} position={[0, 0.48, 0]}>
        <cylinderGeometry args={[0.7, 0.6, 0.08, 6]} />
      </mesh>
      {/* three legs with round footpads */}
      {legs.map(a => {
        const c = Math.cos(a);
        const s = Math.sin(a);
        return (
          <group key={a}>
            <Strut from={[c * 0.75, 0.6, s * 0.75]} to={[c * 1.32, 0.1, s * 1.32]} r={0.04} material={M.aluminum} />
            <Strut from={[c * 0.5 - s * 0.3, 0.5, s * 0.5 + c * 0.3]} to={[c * 1.15, 0.25, s * 1.15]} r={0.018} />
            <Strut from={[c * 0.5 + s * 0.3, 0.5, s * 0.5 - c * 0.3]} to={[c * 1.15, 0.25, s * 1.15]} r={0.018} />
            <mesh material={M.aluminum} position={[c * 1.36, 0.04, s * 1.36]}>
              <cylinderGeometry args={[0.15, 0.17, 0.07, 18]} />
            </mesh>
          </group>
        );
      })}
      {/* two RTGs under their wind covers */}
      {[0.38, -0.38].map(x => (
        <group key={x} position={[x, 1.08, -0.3]} rotation={[PI / 2, 0, 0]}>
          <Rtg r={0.1} h={0.36} fins={6} />
        </group>
      ))}
      {/* S-band high-gain dish on its mast */}
      <Strut from={[-0.35, 0.93, 0.25]} to={[-0.35, 1.65, 0.25]} r={0.03} />
      <mesh position={[-0.35, 1.75, 0.25]} rotation={[-1.0, 0, 0.3]}>
        <sphereGeometry args={[0.42, 24, 6, 0, PI * 2, 0, 0.55]} />
        <meshStandardMaterial color="#e9e8e3" roughness={0.5} side={THREE.DoubleSide} />
      </mesh>
      {/* two cylindrical scan cameras */}
      {[0.28, -0.05].map(x => (
        <group key={x} position={[x, 0.93, 0.6]}>
          <mesh material={M.offWhite} position={[0, 0.18, 0]}>
            <cylinderGeometry args={[0.07, 0.07, 0.36, 16]} />
          </mesh>
          <mesh material={M.black} position={[0, 0.3, 0.06]}>
            <boxGeometry args={[0.05, 0.08, 0.03]} />
          </mesh>
        </group>
      ))}
      {/* meteorology boom */}
      <Strut from={[0.6, 0.93, -0.25]} to={[0.75, 1.45, -0.45]} r={0.015} />
      <Strut from={[0.75, 1.45, -0.45]} to={[1.05, 1.45, -0.45]} r={0.012} />
      <mesh material={M.white} position={[1.08, 1.45, -0.45]}>
        <boxGeometry args={[0.06, 0.05, 0.1]} />
      </mesh>
      {/* surface sampler boom reaching into its furrow */}
      <mesh material={M.white} position={[0.55, 0.8, 0.6]}>
        <boxGeometry args={[0.24, 0.2, 0.24]} />
      </mesh>
      <Strut from={[0.6, 0.82, 0.68]} to={[1.2, 0.16, 1.95]} r={0.022} material={M.steel} />
      <mesh material={M.aluminum} position={[1.24, 0.1, 2.02]} rotation={[0.4, 0.4, 0]}>
        <boxGeometry args={[0.1, 0.08, 0.16]} />
      </mesh>
      <mesh geometry={furrow} material={M.marsMound} position={[1.32, 0, 2.2]} scale={[0.18, 0.05, 0.38]} rotation={[0, 0.45, 0]} />
    </group>
  );
}

/** InSight lander with dusty solar panels, robotic arm, SEIS and the HP3 mole. */
export function InsightLander() {
  const legs = [PI / 2, PI / 2 + (2 * PI) / 3, PI / 2 + (4 * PI) / 3];
  return (
    <group>
      {/* deck */}
      <mesh material={M.lmFoil} position={[0, 0.82, 0]}>
        <cylinderGeometry args={[0.78, 0.78, 0.28, 10]} />
      </mesh>
      <mesh material={M.aluminum} position={[0, 0.97, 0]}>
        <cylinderGeometry args={[0.8, 0.8, 0.03, 10]} />
      </mesh>
      {legs.map(a => {
        const c = Math.cos(a);
        const s = Math.sin(a);
        return (
          <group key={a}>
            <Strut from={[c * 0.6, 0.7, s * 0.6]} to={[c * 1.0, 0.08, s * 1.0]} r={0.035} />
            <mesh material={M.aluminum} position={[c * 1.02, 0.04, s * 1.02]}>
              <cylinderGeometry args={[0.14, 0.15, 0.06, 16]} />
            </mesh>
          </group>
        );
      })}
      {/* two fan-shaped (decagonal) solar panels, now dusty */}
      {[1, -1].map(side => (
        <group key={side} position={[side * 1.85, 0.98, 0]}>
          <mesh material={M.solarDusty}>
            <cylinderGeometry args={[1.07, 1.07, 0.03, 10]} />
          </mesh>
          {Array.from({ length: 5 }, (_, i) => (
            <mesh key={i} material={M.aluminum} position={[0, 0.02, 0]} rotation={[0, (i / 5) * PI, 0]}>
              <boxGeometry args={[2.1, 0.012, 0.02]} />
            </mesh>
          ))}
          <Strut from={[-side * 1.07, 0, 0]} to={[-side * 1.07, -0.12, 0]} r={0.03} />
        </group>
      ))}
      {/* RISE radio antennas */}
      {[0.32, -0.32].map(x => (
        <mesh key={x} material={M.silverFoil} position={[x, 1.08, -0.4]} rotation={[-0.5, 0, 0]}>
          <boxGeometry args={[0.16, 0.12, 0.08]} />
        </mesh>
      ))}
      {/* UHF helix antennas */}
      {[0.5, -0.5].map(x => (
        <Strut key={x} from={[x, 0.98, 0.35]} to={[x, 1.2, 0.35]} r={0.02} material={M.offWhite} />
      ))}
      {/* robotic arm that set the instruments on the ground */}
      <mesh material={M.white} position={[0, 1.05, 0.55]}>
        <boxGeometry args={[0.16, 0.1, 0.16]} />
      </mesh>
      <Strut from={[0, 1.05, 0.58]} to={[0.1, 1.6, 1.05]} r={0.03} material={M.white} />
      <Strut from={[0.1, 1.6, 1.05]} to={[0.15, 1.0, 1.55]} r={0.025} material={M.white} />
      <mesh material={M.darkMetal} position={[0.15, 0.92, 1.58]}>
        <boxGeometry args={[0.1, 0.14, 0.1]} />
      </mesh>
      {/* instruments on the ground */}
      <group position={[-0.5, 0, 1.95]} rotation={[0, 1.32, 0]} scale={0.9}>
        <Seis />
      </group>
      <group position={[0.95, 0, 1.75]} rotation={[0, 0.95, 0]}>
        <Hp3Mole />
      </group>
    </group>
  );
}
