import * as THREE from "three";
import { createNoise3D } from "simplex-noise";
import { mulberry32 } from "../terrain";

const std = (color: string, metalness: number, roughness: number, extra: Partial<THREE.MeshStandardMaterialParameters> = {}) =>
  new THREE.MeshStandardMaterial({ color, metalness, roughness, ...extra });

/** Shared materials for the procedural tool models. */
export const M = {
  aluminum: std("#c9cdd3", 0.85, 0.32),
  brushed: std("#a9aeb6", 0.8, 0.45),
  steel: std("#8f959d", 0.9, 0.28),
  darkMetal: std("#3a3e45", 0.7, 0.45),
  black: std("#141518", 0.2, 0.7),
  rubber: std("#1c1d20", 0, 0.85),
  white: std("#e9e8e3", 0.05, 0.55),
  offWhite: std("#d8d4ca", 0.1, 0.6),
  gold: std("#d6a03c", 1, 0.26),
  goldFoil: std("#c9932f", 1, 0.38, { flatShading: true }),
  copper: std("#b9733f", 0.95, 0.34),
  mylar: std("#d9dbdf", 1, 0.2, { flatShading: true }),
  glass: std("#0a0d14", 0.5, 0.06),
  lens: std("#1a2a44", 0.6, 0.05, { emissive: "#0b1a33", emissiveIntensity: 0.4 }),
  solar: std("#1b2c5a", 0.6, 0.25, { emissive: "#081230", emissiveIntensity: 0.25 }),
  carbon: std("#2a2b2e", 0.3, 0.5),
  orange: std("#ff5f1f", 0.1, 0.5),
  red: std("#b3261e", 0.1, 0.55),
  moonRock: std("#77756f", 0, 0.95, { flatShading: true }),
  marsRock: std("#6b3b28", 0, 0.95, { flatShading: true }),
  regolithMound: std("#8a8883", 0, 1),
  marsMound: std("#a35a35", 0, 1),
  lmFoil: std("#d19a3a", 0.45, 0.5, { flatShading: true, emissive: "#2a1a05", emissiveIntensity: 0.25 }),
  airbag: std("#d6cdbb", 0.05, 0.9, { flatShading: true }),
  solarDusty: std("#5b4134", 0.35, 0.75, { emissive: "#120806", emissiveIntensity: 0.2 }),
  blackFoil: std("#1e1f22", 0.6, 0.4, { flatShading: true }),
  silverFoil: std("#c8ccd2", 1, 0.3, { flatShading: true }),
  mesh: std("#8d9196", 0.7, 0.6, { wireframe: true }),
};

export function makeRockGeometry(seed: number, squash = 0.62) {
  const rand = mulberry32(seed);
  const noise = createNoise3D(rand);
  const geo = new THREE.IcosahedronGeometry(1, 2);
  const pos = geo.attributes["position"] as THREE.BufferAttribute;
  const v = new THREE.Vector3();
  for (let i = 0; i < pos.count; i++) {
    v.fromBufferAttribute(pos, i);
    const n = noise(v.x * 1.3, v.y * 1.3, v.z * 1.3) * 0.28 + noise(v.x * 3, v.y * 3, v.z * 3) * 0.08;
    v.multiplyScalar(1 + n);
    v.y *= squash;
    pos.setXYZ(i, v.x, v.y, v.z);
  }
  geo.computeVertexNormals();
  return geo;
}

/** A wrinkled flat disc (thermal shrouds, foil blankets). */
export function makeWrinkledDisc(radius: number, seed: number, amp = 0.012) {
  const rand = mulberry32(seed);
  const noise = createNoise3D(rand);
  const geo = new THREE.CircleGeometry(radius, 48, 0, Math.PI * 2);
  geo.rotateX(-Math.PI / 2);
  const pos = geo.attributes["position"] as THREE.BufferAttribute;
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i);
    const z = pos.getZ(i);
    const r = Math.hypot(x, z) / radius;
    const ang = Math.atan2(z, x);
    const crease = Math.sin(ang * 14) * 0.6 + noise(x * 6, z * 6, 0.5) * 0.8;
    pos.setY(i, crease * amp * r);
  }
  geo.computeVertexNormals();
  return geo;
}
