import * as THREE from "three";
import { M } from "./materials";

type V3 = [number, number, number];
const UP = new THREE.Vector3(0, 1, 0);

/** A round strut between two points. */
export function Strut({ from, to, r = 0.02, material = M.aluminum, sides = 8 }: { from: V3; to: V3; r?: number; material?: THREE.Material; sides?: number }) {
  const a = new THREE.Vector3(...from);
  const b = new THREE.Vector3(...to);
  const len = a.distanceTo(b);
  const pos = a.clone().add(b).multiplyScalar(0.5);
  const quat = new THREE.Quaternion().setFromUnitVectors(UP, b.clone().sub(a).normalize());
  return (
    <mesh material={material} position={pos} quaternion={quat}>
      <cylinderGeometry args={[r, r, len, sides]} />
    </mesh>
  );
}

/** A flat triangle lying on the ground plane (used for lander petals). */
export function makeTriangle(a: [number, number], b: [number, number], c: [number, number], thickness = 0.03) {
  const shape = new THREE.Shape();
  // Shape is drawn in XY; rotating -90° about X maps (x, y) -> (x, -y) in XZ.
  shape.moveTo(a[0], -a[1]);
  shape.lineTo(b[0], -b[1]);
  shape.lineTo(c[0], -c[1]);
  shape.closePath();
  const geo = new THREE.ExtrudeGeometry(shape, { depth: thickness, bevelEnabled: false });
  geo.rotateX(-Math.PI / 2);
  return geo;
}

/** Points on a circle, starting at angle `offset`. */
export function ring(n: number, r: number, offset = 0) {
  return Array.from({ length: n }, (_, i) => {
    const a = offset + (i / n) * Math.PI * 2;
    return [Math.cos(a) * r, Math.sin(a) * r] as [number, number];
  });
}

/** A finned radioisotope generator (RTG). */
export function Rtg({ r = 0.12, h = 0.4, fins = 8 }: { r?: number; h?: number; fins?: number }) {
  return (
    <group>
      <mesh material={M.darkMetal}>
        <cylinderGeometry args={[r, r, h, 16]} />
      </mesh>
      {Array.from({ length: fins }, (_, i) => {
        const a = (i / fins) * Math.PI * 2;
        return (
          <mesh key={i} material={M.black} position={[Math.cos(a) * r * 1.35, 0, Math.sin(a) * r * 1.35]} rotation={[0, -a, 0]}>
            <boxGeometry args={[r * 0.8, h * 0.95, 0.008]} />
          </mesh>
        );
      })}
    </group>
  );
}

/** Wheel lying along the X axis (axle along X). */
export function Wheel({ r, w, material = M.darkMetal, hub = M.aluminum }: { r: number; w: number; material?: THREE.Material; hub?: THREE.Material }) {
  return (
    <group rotation={[0, 0, Math.PI / 2]}>
      <mesh material={material}>
        <cylinderGeometry args={[r, r, w, 20]} />
      </mesh>
      <mesh material={hub}>
        <cylinderGeometry args={[r * 0.35, r * 0.35, w * 1.15, 12]} />
      </mesh>
    </group>
  );
}
