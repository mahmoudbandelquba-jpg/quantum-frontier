import { useFrame } from "@react-three/fiber";
import { useMemo, useRef } from "react";
import * as THREE from "three";
import { M, makeRockGeometry } from "./materials";

const PI = Math.PI;

/** Ingenuity Mars Helicopter, rotors gently idling in the breeze. */
export function Ingenuity() {
  const rotorA = useRef<THREE.Group>(null);
  const rotorB = useRef<THREE.Group>(null);
  useFrame((_, dt) => {
    if (rotorA.current) rotorA.current.rotation.y += dt * 0.25;
    if (rotorB.current) rotorB.current.rotation.y -= dt * 0.25;
  });
  const legs: [number, number][] = [
    [1, 1],
    [1, -1],
    [-1, 1],
    [-1, -1],
  ];
  const Blade = () => (
    <>
      {[0, PI].map(r => (
        <mesh key={r} material={M.carbon} rotation={[0.06, r, 0]} position={[0, 0, 0]}>
          <boxGeometry args={[1.2, 0.006, 0.07]} />
        </mesh>
      ))}
    </>
  );
  return (
    <group>
      {/* legs */}
      {legs.map(([sx, sz]) => {
        const top = new THREE.Vector3(0.06 * sx, 0.17, 0.06 * sz);
        const foot = new THREE.Vector3(0.27 * sx, 0.012, 0.27 * sz);
        const mid = top.clone().add(foot).multiplyScalar(0.5);
        const len = top.distanceTo(foot);
        const q = new THREE.Quaternion().setFromUnitVectors(
          new THREE.Vector3(0, 1, 0),
          top.clone().sub(foot).normalize(),
        );
        return (
          <group key={`${sx}${sz}`}>
            <mesh material={M.carbon} position={mid} quaternion={q}>
              <cylinderGeometry args={[0.006, 0.006, len, 6]} />
            </mesh>
            <mesh material={M.darkMetal} position={foot}>
              <sphereGeometry args={[0.018, 10, 8]} />
            </mesh>
          </group>
        );
      })}
      {/* fuselage */}
      <mesh material={M.goldFoil} position={[0, 0.23, 0]}>
        <boxGeometry args={[0.195, 0.136, 0.163]} />
      </mesh>
      <mesh material={M.black} position={[0, 0.2, 0.083]}>
        <boxGeometry args={[0.05, 0.03, 0.004]} />
      </mesh>
      {/* mast */}
      <mesh material={M.aluminum} position={[0, 0.38, 0]}>
        <cylinderGeometry args={[0.012, 0.012, 0.18, 10]} />
      </mesh>
      <group ref={rotorA} position={[0, 0.34, 0]}>
        <Blade />
      </group>
      <group ref={rotorB} position={[0, 0.42, 0]} rotation={[0, PI / 2, 0]}>
        <Blade />
      </group>
      <mesh material={M.darkMetal} position={[0, 0.38, 0]}>
        <cylinderGeometry args={[0.03, 0.03, 0.05, 14]} />
      </mesh>
      {/* solar panel */}
      <mesh material={M.solar} position={[0, 0.48, 0]}>
        <boxGeometry args={[0.42, 0.01, 0.17]} />
      </mesh>
      <mesh material={M.aluminum} position={[0, 0.474, 0]}>
        <boxGeometry args={[0.43, 0.004, 0.18]} />
      </mesh>
    </group>
  );
}

/** InSight SEIS under its Wind and Thermal Shield dome, tether running away. */
export function Seis() {
  const tether = useMemo(
    () =>
      new THREE.TubeGeometry(
        new THREE.CatmullRomCurve3([
          new THREE.Vector3(0.38, 0.02, 0),
          new THREE.Vector3(1.0, 0.02, 0.25),
          new THREE.Vector3(1.6, 0.03, 0.05),
          new THREE.Vector3(2.4, 0.02, 0.4),
        ]),
        40,
        0.012,
        6,
      ),
    [],
  );
  return (
    <group>
      <mesh material={M.copper} position={[0, 0.04, 0]} scale={[1, 0.9, 1]}>
        <sphereGeometry args={[0.36, 40, 20, 0, PI * 2, 0, PI / 2]} />
      </mesh>
      {/* chain-mail skirt */}
      <mesh material={M.darkMetal} position={[0, 0.03, 0]}>
        <cylinderGeometry args={[0.37, 0.44, 0.06, 40, 1, true]} />
      </mesh>
      <mesh material={M.gold} position={[0, 0.36, 0]}>
        <cylinderGeometry args={[0.05, 0.06, 0.03, 16]} />
      </mesh>
      <mesh geometry={tether} material={M.offWhite} />
    </group>
  );
}

/** InSight HP3 support structure with the Mole and its tether. */
export function Hp3Mole() {
  const tether = useMemo(
    () =>
      new THREE.TubeGeometry(
        new THREE.CatmullRomCurve3([
          new THREE.Vector3(0.0, 0.32, -0.08),
          new THREE.Vector3(0.0, 0.42, -0.25),
          new THREE.Vector3(0.0, 0.05, -0.55),
          new THREE.Vector3(0.4, 0.02, -1.4),
          new THREE.Vector3(1.0, 0.02, -2.0),
        ]),
        40,
        0.006,
        4,
      ),
    [],
  );
  const rock = useMemo(() => makeRockGeometry(77, 0.6), []);
  return (
    <group>
      {/* legs */}
      {(
        [
          [0.13, 0.08],
          [-0.13, 0.08],
          [0.13, -0.08],
          [-0.13, -0.08],
        ] as [number, number][]
      ).map(([x, z]) => (
        <mesh key={`${x}${z}`} material={M.darkMetal} position={[x, 0.08, z]}>
          <cylinderGeometry args={[0.008, 0.01, 0.16, 6]} />
        </mesh>
      ))}
      {/* support structure */}
      <mesh material={M.goldFoil} position={[0, 0.32, 0]}>
        <boxGeometry args={[0.32, 0.34, 0.2]} />
      </mesh>
      <mesh material={M.black} position={[0, 0.5, 0]}>
        <boxGeometry args={[0.3, 0.02, 0.18]} />
      </mesh>
      {/* mole emerging */}
      <mesh material={M.steel} position={[0, 0.05, 0.02]} rotation={[0.25, 0, 0]}>
        <cylinderGeometry args={[0.014, 0.014, 0.2, 12]} />
      </mesh>
      <mesh material={M.marsMound} position={[0, 0, 0.02]} scale={[0.1, 0.03, 0.1]}>
        <sphereGeometry args={[1, 12, 6]} />
      </mesh>
      <mesh geometry={tether} material={M.white} />
      <mesh geometry={rock} material={M.marsRock} position={[-0.6, 0.06, 0.5]} scale={0.18} />
    </group>
  );
}
