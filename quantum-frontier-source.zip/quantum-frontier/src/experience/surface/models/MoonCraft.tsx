import { useMemo } from "react";
import * as THREE from "three";
import { M, makeRockGeometry, makeWrinkledDisc } from "./materials";
import { Rtg, Strut, Wheel } from "./parts";

const PI = Math.PI;

/** Surveyor 3: three-legged robotic lander with its TV camera and sampler arm. */
export function Surveyor3() {
  const corners = [0, 1, 2].map(i => {
    const a = PI / 2 + (i * 2 * PI) / 3;
    return { a, c: Math.cos(a), s: Math.sin(a) };
  });
  const trench = useMemo(() => makeRockGeometry(311, 0.25), []);
  return (
    <group>
      {/* central mast */}
      <Strut from={[0, 0.55, 0]} to={[0, 3.0, 0]} r={0.045} material={M.aluminum} />
      {corners.map(({ a, c, s }) => (
        <group key={a}>
          {/* triangular frame */}
          <Strut from={[c * 0.95, 0.7, s * 0.95]} to={[0, 0.55, 0]} r={0.03} />
          <Strut from={[c * 0.95, 0.7, s * 0.95]} to={[0, 1.9, 0]} r={0.022} />
          {/* leg + crushable footpad */}
          <Strut from={[c * 0.95, 0.7, s * 0.95]} to={[c * 2.05, 0.12, s * 2.05]} r={0.045} material={M.brushed} />
          <Strut from={[c * 0.5, 0.95, s * 0.5]} to={[c * 1.55, 0.35, s * 1.55]} r={0.02} />
          <mesh material={M.aluminum} position={[c * 2.08, 0.05, s * 2.08]}>
            <cylinderGeometry args={[0.2, 0.22, 0.1, 18]} />
          </mesh>
        </group>
      ))}
      {/* frame edges */}
      {corners.map(({ a, c, s }, i) => {
        const n = corners[(i + 1) % 3]!;
        return <Strut key={`e${a}`} from={[c * 0.95, 0.7, s * 0.95]} to={[n.c * 0.95, 0.7, n.s * 0.95]} r={0.028} />;
      })}
      {/* thermal compartments */}
      <mesh material={M.white} position={[0.35, 0.95, -0.2]} rotation={[0, 0.5, 0]}>
        <boxGeometry args={[0.5, 0.32, 0.36]} />
      </mesh>
      <mesh material={M.white} position={[-0.38, 0.95, -0.15]} rotation={[0, -0.4, 0]}>
        <boxGeometry args={[0.44, 0.3, 0.34]} />
      </mesh>
      {/* planar antenna + solar panel on top of the mast */}
      <group position={[0, 3.0, 0]}>
        <mesh material={M.mesh} position={[0.32, 0.05, 0]} rotation={[0, 0, -0.5]}>
          <boxGeometry args={[0.85, 0.02, 0.85]} />
        </mesh>
        <mesh material={M.solar} position={[-0.3, -0.05, 0]} rotation={[0, 0, 0.6]}>
          <boxGeometry args={[0.8, 0.025, 0.7]} />
        </mesh>
        <mesh material={M.darkMetal}>
          <cylinderGeometry args={[0.06, 0.06, 0.14, 12]} />
        </mesh>
      </group>
      {/* TV camera with its movable mirror hood */}
      <group position={[0.15, 0.9, 0.62]}>
        <mesh material={M.offWhite} position={[0, 0.3, 0]}>
          <cylinderGeometry args={[0.07, 0.08, 0.6, 16]} />
        </mesh>
        <mesh material={M.aluminum} position={[0, 0.66, 0.02]} rotation={[0.5, 0, 0]}>
          <boxGeometry args={[0.16, 0.18, 0.12]} />
        </mesh>
        <mesh material={M.glass} position={[0, 0.66, 0.085]} rotation={[0.5, 0, 0]}>
          <boxGeometry args={[0.1, 0.1, 0.01]} />
        </mesh>
      </group>
      {/* surface-sampler arm reaching into its trench */}
      <group>
        <Strut from={[-0.55, 0.75, 0.45]} to={[-1.35, 0.42, 1.25]} r={0.022} material={M.brushed} />
        <Strut from={[-0.6, 0.65, 0.5]} to={[-1.35, 0.42, 1.25]} r={0.018} material={M.brushed} />
        <Strut from={[-1.35, 0.42, 1.25]} to={[-1.75, 0.12, 1.6]} r={0.02} material={M.brushed} />
        <mesh material={M.steel} position={[-1.8, 0.08, 1.65]} rotation={[0.3, 0.8, 0]}>
          <boxGeometry args={[0.13, 0.08, 0.06]} />
        </mesh>
        <mesh geometry={trench} material={M.regolithMound} position={[-1.95, 0, 1.85]} scale={[0.35, 0.06, 0.18]} rotation={[0, 0.8, 0]} />
      </group>
    </group>
  );
}

/** Apollo Lunar Module descent stage: the half that stays behind as a launchpad. */
export function DescentStage() {
  const legs = [0, PI / 2, PI, -PI / 2];
  return (
    <group>
      {/* octagonal gold-foil body */}
      <mesh material={M.lmFoil} position={[0, 1.95, 0]} rotation={[0, PI / 8, 0]}>
        <cylinderGeometry args={[1.85, 1.85, 1.6, 8]} />
      </mesh>
      <mesh material={M.blackFoil} position={[0, 1.12, 0]} rotation={[0, PI / 8, 0]}>
        <cylinderGeometry args={[1.8, 1.55, 0.12, 8]} />
      </mesh>
      {/* top deck where the ascent stage sat */}
      <mesh material={M.silverFoil} position={[0, 2.78, 0]} rotation={[0, PI / 8, 0]}>
        <cylinderGeometry args={[1.7, 1.85, 0.06, 8]} />
      </mesh>
      {/* descent engine bell */}
      <mesh material={M.darkMetal} position={[0, 0.78, 0]}>
        <cylinderGeometry args={[0.32, 0.6, 0.62, 20, 1, true]} />
      </mesh>
      {legs.map(a => {
        const c = Math.sin(a);
        const s = Math.cos(a);
        const top: [number, number, number] = [c * 1.75, 2.35, s * 1.75];
        const foot: [number, number, number] = [c * 3.3, 0.2, s * 3.3];
        const knee: [number, number, number] = [c * 2.75, 0.95, s * 2.75];
        return (
          <group key={a}>
            <Strut from={top} to={foot} r={0.085} material={M.lmFoil} sides={10} />
            <Strut from={[c * 1.7 + s * 0.7, 1.25, s * 1.7 - c * 0.7]} to={knee} r={0.035} />
            <Strut from={[c * 1.7 - s * 0.7, 1.25, s * 1.7 + c * 0.7]} to={knee} r={0.035} />
            <mesh material={M.aluminum} position={[c * 3.35, 0.08, s * 3.35]}>
              <cylinderGeometry args={[0.42, 0.46, 0.12, 20]} />
            </mesh>
            <Strut from={[c * 3.35, 0.12, s * 3.35]} to={[c * 3.35, -0.5, s * 3.35]} r={0.012} material={M.steel} />
          </group>
        );
      })}
      {/* porch + ladder on the forward leg */}
      <mesh material={M.aluminum} position={[0, 2.42, 1.95]}>
        <boxGeometry args={[0.9, 0.05, 0.55]} />
      </mesh>
      {[-0.24, 0.24].map(x => (
        <Strut key={x} from={[x, 2.4, 1.95]} to={[x, 0.35, 3.15]} r={0.022} />
      ))}
      {Array.from({ length: 8 }, (_, i) => {
        const t = (i + 0.5) / 8;
        const y = 2.4 + (0.35 - 2.4) * t;
        const z = 1.95 + (3.15 - 1.95) * t;
        return (
          <mesh key={i} material={M.aluminum} position={[0, y, z]} rotation={[0, 0, PI / 2]}>
            <cylinderGeometry args={[0.014, 0.014, 0.5, 6]} />
          </mesh>
        );
      })}
      {/* stowage bay hatch (MESA) */}
      <mesh material={M.silverFoil} position={[-0.95, 1.95, 1.45]} rotation={[0, -PI / 4 + PI / 8, 0]}>
        <boxGeometry args={[0.9, 1.0, 0.04]} />
      </mesh>
    </group>
  );
}

/** ALSEP: central station, RTG power source and passive seismometer, linked by cables. */
export function AlsepStation() {
  const shroud = useMemo(() => makeWrinkledDisc(0.6, 9), []);
  const cables = useMemo(() => {
    const mk = (pts: [number, number, number][]) =>
      new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts.map(p => new THREE.Vector3(...p))), 30, 0.008, 5);
    return [
      mk([[0, 0.03, 0], [0.4, 0.02, 0.3], [0.9, 0.02, 0.2]]),
      mk([[0, 0.03, 0], [-0.5, 0.02, 0.6], [-1.2, 0.02, 1.4], [-1.6, 0.02, 1.8]]),
      mk([[0, 0.03, 0], [-0.4, 0.02, -0.5], [-1.1, 0.02, -0.9]]),
    ];
  }, []);
  return (
    <group>
      {/* central station */}
      <mesh material={M.white} position={[0, 0.17, 0]}>
        <boxGeometry args={[0.42, 0.3, 0.35]} />
      </mesh>
      <mesh material={M.goldFoil} position={[0, 0.36, 0]}>
        <boxGeometry args={[0.5, 0.02, 0.42]} />
      </mesh>
      <Strut from={[0.12, 0.36, 0]} to={[0.12, 0.95, 0]} r={0.008} />
      <mesh material={M.aluminum} position={[0.12, 1.02, 0]} rotation={[0.4, 0, 0]}>
        <cylinderGeometry args={[0.035, 0.008, 0.16, 12]} />
      </mesh>
      {/* RTG */}
      <group position={[0.95, 0.28, 0.2]}>
        <Rtg r={0.13} h={0.42} />
      </group>
      <mesh material={M.aluminum} position={[0.95, 0.03, 0.2]}>
        <boxGeometry args={[0.36, 0.05, 0.36]} />
      </mesh>
      {/* passive seismometer under its foil shroud */}
      <group position={[-1.65, 0, 1.85]}>
        <mesh geometry={shroud} material={M.mylar} position={[0, 0.015, 0]} />
        <mesh material={M.gold} position={[0, 0.17, 0]}>
          <cylinderGeometry args={[0.16, 0.18, 0.3, 24]} />
        </mesh>
        <mesh material={M.aluminum} position={[0, 0.34, 0]}>
          <cylinderGeometry args={[0.17, 0.17, 0.04, 24]} />
        </mesh>
      </group>
      {/* magnetometer on its tripod with three sensor arms */}
      <group position={[-1.15, 0, -0.95]}>
        {[0, (2 * PI) / 3, (4 * PI) / 3].map(a => (
          <group key={a}>
            <Strut from={[0, 0.45, 0]} to={[Math.cos(a) * 0.3, 0, Math.sin(a) * 0.3]} r={0.01} />
            <Strut from={[0, 0.5, 0]} to={[Math.cos(a + PI / 3) * 0.45, 0.62, Math.sin(a + PI / 3) * 0.45]} r={0.012} material={M.white} />
          </group>
        ))}
        <mesh material={M.white} position={[0, 0.5, 0]}>
          <boxGeometry args={[0.14, 0.1, 0.14]} />
        </mesh>
      </group>
      {cables.map((g, i) => (
        <mesh key={i} geometry={g} material={M.black} />
      ))}
    </group>
  );
}

/** The Apollo 12 colour TV camera on its tripod, tilted toward the Sun. */
export function TvCameraTripod() {
  return (
    <group>
      {[0, (2 * PI) / 3, (4 * PI) / 3].map(a => (
        <Strut key={a} from={[0, 1.0, 0]} to={[Math.cos(a) * 0.35, 0, Math.sin(a) * 0.35]} r={0.012} material={M.darkMetal} />
      ))}
      <group position={[0, 1.08, 0]} rotation={[-0.9, 0, 0]}>
        <mesh material={M.white}>
          <boxGeometry args={[0.16, 0.14, 0.3]} />
        </mesh>
        <mesh material={M.black} position={[0, 0, 0.18]} rotation={[PI / 2, 0, 0]}>
          <cylinderGeometry args={[0.045, 0.05, 0.08, 14]} />
        </mesh>
      </group>
    </group>
  );
}

/** Apollo 12 landing site: Intrepid's descent stage, ALSEP and the TV camera. */
export function Apollo12Site() {
  return (
    <group>
      <DescentStage />
      <group position={[4.6, 0, 1.6]} rotation={[0, 0.6, 0]}>
        <AlsepStation />
      </group>
      <group position={[1.6, 0, -4.4]}>
        <TvCameraTripod />
      </group>
    </group>
  );
}

/** The Lunar Roving Vehicle, parked where its camera could film Falcon's lift-off. */
export function LunarRover() {
  const wheels: [number, number][] = [
    [0.98, 1.15],
    [-0.98, 1.15],
    [0.98, -1.15],
    [-0.98, -1.15],
  ];
  return (
    <group>
      {/* chassis */}
      <mesh material={M.aluminum} position={[0, 0.55, 0]}>
        <boxGeometry args={[1.2, 0.08, 2.5]} />
      </mesh>
      <mesh material={M.darkMetal} position={[0, 0.48, 0]}>
        <boxGeometry args={[1.05, 0.1, 2.2]} />
      </mesh>
      {wheels.map(([x, z]) => (
        <group key={`${x}${z}`}>
          <group position={[x, 0.41, z]}>
            <Wheel r={0.41} w={0.23} material={M.mesh} hub={M.darkMetal} />
            <Wheel r={0.38} w={0.2} material={M.steel} hub={M.darkMetal} />
          </group>
          {/* fender */}
          <mesh material={M.offWhite} position={[x, 0.41, z]} rotation={[0, 0, PI / 2]}>
            <cylinderGeometry args={[0.47, 0.47, 0.27, 20, 1, true, -PI / 2.6, PI / 1.3]} />
          </mesh>
          <Strut from={[Math.sign(x) * 0.6, 0.55, z]} to={[x * 0.92, 0.41, z]} r={0.03} material={M.darkMetal} />
        </group>
      ))}
      {/* seats */}
      {[0.3, -0.3].map(x => (
        <group key={x} position={[x, 0.6, -0.05]}>
          <mesh material={M.steel} position={[0, 0.08, 0]}>
            <boxGeometry args={[0.46, 0.04, 0.46]} />
          </mesh>
          <mesh material={M.steel} position={[0, 0.32, -0.23]} rotation={[-0.15, 0, 0]}>
            <boxGeometry args={[0.46, 0.46, 0.04]} />
          </mesh>
        </group>
      ))}
      {/* control console */}
      <Strut from={[0, 0.6, 0.55]} to={[0, 1.0, 0.62]} r={0.025} material={M.darkMetal} />
      <mesh material={M.darkMetal} position={[0, 1.06, 0.62]} rotation={[-0.5, 0, 0]}>
        <boxGeometry args={[0.32, 0.22, 0.06]} />
      </mesh>
      {/* high-gain umbrella antenna */}
      <Strut from={[0.38, 0.6, 1.0]} to={[0.38, 1.55, 1.08]} r={0.015} />
      <mesh material={M.mylar} position={[0.38, 1.62, 1.08]} rotation={[0.5, 0, 0.2]}>
        <coneGeometry args={[0.46, 0.18, 24, 1, true]} />
      </mesh>
      {/* low-gain antenna */}
      <Strut from={[-0.45, 0.6, 1.0]} to={[-0.45, 1.5, 1.0]} r={0.008} />
      <mesh material={M.aluminum} position={[-0.45, 1.6, 1.0]}>
        <cylinderGeometry args={[0.03, 0.03, 0.22, 10]} />
      </mesh>
      {/* remote-controlled TV camera */}
      <Strut from={[-0.1, 0.6, 1.15]} to={[-0.1, 1.1, 1.2]} r={0.012} />
      <mesh material={M.white} position={[-0.1, 1.17, 1.22]}>
        <boxGeometry args={[0.14, 0.12, 0.24]} />
      </mesh>
      {/* rear tool pallet */}
      <mesh material={M.aluminum} position={[0, 0.78, -1.05]}>
        <boxGeometry args={[0.8, 0.4, 0.3]} />
      </mesh>
    </group>
  );
}

/** Apollo 15 site: the Moon Buggy, Falcon's descent stage, ALSEP and the memorial. */
export function Apollo15Site() {
  return (
    <group>
      <LunarRover />
      <group position={[0, 0, -7.5]} rotation={[0, PI, 0]}>
        <DescentStage />
      </group>
      <group position={[-5.2, 0, -3.2]} rotation={[0, -0.9, 0]}>
        <AlsepStation />
      </group>
      {/* memorial plaque and the tiny aluminium astronaut figurine */}
      <group position={[1.75, 0, 0.9]} rotation={[0, 0.3, 0]}>
        <mesh material={M.aluminum} position={[0, 0.01, 0]}>
          <boxGeometry args={[0.24, 0.01, 0.1]} />
        </mesh>
        <mesh material={M.aluminum} position={[0.2, 0.01, 0.02]} rotation={[0, 0, PI / 2]}>
          <capsuleGeometry args={[0.012, 0.06, 4, 8]} />
        </mesh>
      </group>
    </group>
  );
}
