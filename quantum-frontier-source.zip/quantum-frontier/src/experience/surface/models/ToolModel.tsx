import type { JSX } from "react";
import { InsightLander, MerSite, PathfinderSite, VikingLander } from "./MarsCraft";
import { Ingenuity } from "./MarsTools";
import { Apollo12Site, Apollo15Site, Surveyor3 } from "./MoonCraft";

const MODELS: Record<string, () => JSX.Element> = {
  "surveyor-3": Surveyor3,
  "apollo-12-alsep": Apollo12Site,
  "apollo-15-lrv": Apollo15Site,
  sojourner: PathfinderSite,
  "spirit-opportunity": MerSite,
  "viking-1": VikingLander,
  insight: InsightLander,
  ingenuity: Ingenuity,
};

export function ToolModel({ id }: { id: string }) {
  const Model = MODELS[id];
  return Model ? <Model /> : null;
}
