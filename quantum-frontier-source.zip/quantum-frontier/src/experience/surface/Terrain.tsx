import { useMemo } from "react";
import * as THREE from "three";
import type { PlanetConfig } from "../planets";
import { useSafeTexture } from "../useSafeTexture";
import { getTerrain, TERRAIN_SEGMENTS, TERRAIN_SIZE } from "./terrain";

export default function Terrain({ config }: { config: PlanetConfig }) {
  const terrain = getTerrain(config.id);
  const map = useSafeTexture(config.groundTexture, { repeat: 70 });

  const geometry = useMemo(() => {
    const geo = new THREE.PlaneGeometry(TERRAIN_SIZE, TERRAIN_SIZE, TERRAIN_SEGMENTS, TERRAIN_SEGMENTS);
    geo.rotateX(-Math.PI / 2);
    const pos = geo.attributes["position"] as THREE.BufferAttribute;
    const colors = new Float32Array(pos.count * 3);
    const [a, b, c] = config.groundColors.map(hex => new THREE.Color(hex)) as [THREE.Color, THREE.Color, THREE.Color];
    const tmp = new THREE.Color();

    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i);
      const z = pos.getZ(i);
      const h = terrain.height(x, z);
      pos.setY(i, h);
      const s = terrain.shade(x, z);
      tmp.copy(a).lerp(b, s);
      // darken low hollows (crater floors), brighten crests
      const local = h - terrain.height(x + 3, z + 3) * 0.5 - terrain.height(x - 3, z - 3) * 0.5;
      const k = THREE.MathUtils.clamp(local * 0.35, -0.35, 0.25);
      if (k < 0) tmp.lerp(c, -k);
      else tmp.offsetHSL(0, 0, k * 0.25);
      colors[i * 3] = tmp.r;
      colors[i * 3 + 1] = tmp.g;
      colors[i * 3 + 2] = tmp.b;
    }
    geo.setAttribute("color", new THREE.BufferAttribute(colors, 3));
    geo.computeVertexNormals();
    return geo;
  }, [config, terrain]);

  return (
    <mesh geometry={geometry} receiveShadow>
      <meshStandardMaterial
        key={map ? "tex" : "plain"}
        map={map ?? null}
        vertexColors
        roughness={1}
        metalness={0}
        color={map ? "#ffffff" : "#d8d8d8"}
      />
    </mesh>
  );
}
