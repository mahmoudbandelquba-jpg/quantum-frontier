import { BookOpen, Orbit } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { placementsFor } from "../data/toolTypes";
import { getToolInfo } from "../data/toolInfo";
import { PLANETS } from "../planets";
import { input, player } from "../runtime";
import { useExperience } from "../store";
import { SuitReadouts } from "../suit/Visor";
import Brand from "./Brand";
import Compass from "./Compass";
import { useIsTouch } from "./TouchControls";

function Altimeter() {
  const alt = useRef<HTMLSpanElement>(null);
  const bar = useRef<HTMLDivElement>(null);
  useEffect(() => {
    let raf = 0;
    const tick = () => {
      if (alt.current) alt.current.textContent = player.altitude.toFixed(1);
      if (bar.current) bar.current.style.height = `${Math.min(100, (player.altitude / 46) * 100)}%`;
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, []);
  return (
    <div className="pointer-events-none absolute right-[clamp(1.25rem,6vw,5rem)] top-1/2 flex -translate-y-1/2 items-center gap-3">
      <div className="text-right">
        <div className="hud-label text-[var(--suit)]">Descent</div>
        <div className="font-hud text-[28px] leading-none text-white">
          <span ref={alt}>46.0</span>
          <span className="ml-1 text-[12px] text-[var(--hud-dim)]">M</span>
        </div>
        <div className="mt-1 hud-label">Altitude</div>
      </div>
      <div className="relative h-40 w-1.5 overflow-hidden bg-white/10">
        <div ref={bar} className="absolute bottom-0 w-full bg-[var(--suit)]" />
      </div>
    </div>
  );
}

export default function ExploreHUD() {
  const phase = useExperience(s => s.phase);
  const planetId = useExperience(s => s.planet);
  const examiningId = useExperience(s => s.examiningId);
  const discovered = useExperience(s => (s.planet ? s.discovered[s.planet] : []));
  const logOpen = useExperience(s => s.logOpen);
  const setLogOpen = useExperience(s => s.setLogOpen);
  const openSheet = useExperience(s => s.openSheet);
  const returnToOrbit = useExperience(s => s.returnToOrbit);
  const sheetOpen = useExperience(s => !!s.sheetToolId);
  const isTouch = useIsTouch();

  const [showTouchdown, setShowTouchdown] = useState(false);
  const [showHint, setShowHint] = useState(false);
  const [celebrate, setCelebrate] = useState(false);
  const celebrated = useRef<Set<string>>(new Set());

  useEffect(() => {
    if (phase !== "explore") return;
    setShowTouchdown(true);
    setShowHint(true);
    const touchdownStart = performance.now();
    const t = window.setTimeout(() => setShowTouchdown(false), 3200);
    // hide hint once the astronaut starts moving (after a minimum read time)
    const id = window.setInterval(() => {
      if (performance.now() - touchdownStart > 14000 || (input.lastMoveAt > touchdownStart + 2500 && player.speed > 0.5)) {
        setShowHint(false);
        window.clearInterval(id);
      }
    }, 400);
    return () => {
      window.clearTimeout(t);
      window.clearInterval(id);
    };
  }, [phase]);

  if (!planetId) return null;
  const planet = PLANETS[planetId];
  const tools = placementsFor(planetId);
  const examining = examiningId ? getToolInfo(examiningId) : undefined;
  const complete = discovered.length === tools.length;

  // one celebration per planet
  if (complete && !celebrated.current.has(planetId)) {
    celebrated.current.add(planetId);
    window.setTimeout(() => setCelebrate(true), 0);
  }
  const otherWorld = planetId === "moon" ? "Mars" : "the Moon";

  return (
    <div className="pointer-events-none absolute inset-0 z-30">
      {/* top-left: location */}
      <div className="absolute left-[clamp(1rem,3vw,2.5rem)] top-[clamp(1rem,3vh,2rem)]">
        <Brand compact />
        <div className="mt-4 hidden sm:block">
          <div className="font-display text-[20px] uppercase tracking-[0.22em] text-white">{planet.name}</div>
          <div className="mt-1 hud-label text-[var(--hud)]">{planet.site}</div>
          <div className="mt-3 space-y-1">
            {planet.stats.map(s => (
              <div key={s.label} className="flex gap-3 font-hud text-[10.5px] tracking-[0.1em]">
                <span className="w-[86px] uppercase text-[var(--hud-dim)]">{s.label}</span>
                <span className="text-[var(--hud)]">{s.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* top-center: compass */}
      {phase === "explore" && (
        <div className="absolute left-1/2 top-[clamp(4.2rem,9vh,5rem)] -translate-x-1/2 scale-[0.82] sm:top-[clamp(1rem,3vh,2rem)] sm:scale-100">
          <Compass tools={tools} />
        </div>
      )}

      {/* top-right: actions */}
      <div className="pointer-events-auto absolute right-[clamp(1rem,3vw,2.5rem)] top-[clamp(1rem,3vh,2rem)] flex flex-col items-end gap-2">
        <div className="flex gap-2">
          <button type="button" className="hud-btn flex items-center gap-2" onClick={() => setLogOpen(!logOpen)}>
            <BookOpen className="h-3.5 w-3.5" />
            <span>
              Log {discovered.length}/{tools.length}
            </span>
          </button>
          <button type="button" className="hud-btn flex items-center gap-2" onClick={returnToOrbit}>
            <Orbit className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">Return to orbit</span>
            <span className="sm:hidden">Orbit</span>
          </button>
        </div>
        <SuitReadouts visible className="mt-2 hidden w-[150px] lg:block" />
      </div>

      {phase === "landing" && <Altimeter />}

      {/* touchdown banner */}
      <div
        className="absolute inset-x-0 top-[30%] flex flex-col items-center text-center transition-all duration-700"
        style={{ opacity: showTouchdown ? 1 : 0, transform: showTouchdown ? "none" : "translateY(-12px)" }}
      >
        <div className="hud-label text-[var(--suit)]">Touchdown confirmed</div>
        <div className="mt-2 font-display text-[clamp(1.3rem,3.4vw,2.6rem)] uppercase tracking-[0.2em] text-white [text-shadow:0_2px_20px_rgba(0,0,0,0.6)]">
          {planet.site}
        </div>
      </div>

      {/* controls hint */}
      {phase === "explore" && (
        <div
          className="absolute inset-x-0 bottom-[clamp(9rem,22vh,12rem)] flex justify-center px-4 transition-opacity duration-700"
          style={{ opacity: showHint && !examining ? 1 : 0 }}
        >
          <div className="hud-panel max-w-[640px] px-5 py-3 text-center font-hud text-[11px] uppercase leading-relaxed tracking-[0.14em] text-[var(--hud)]">
            {isTouch ? (
              <>Left stick to walk · Drag to look around · HOP to jump</>
            ) : (
              <>
                <Kbd>W A S D</Kbd> walk · <Kbd>Drag</Kbd> look around · <Kbd>Space</Kbd> hop · <Kbd>Shift</Kbd> bound
              </>
            )}
            <div className="mt-1 normal-case tracking-[0.06em] text-[var(--hud-dim)]">
              Follow the orange beacons — you will stop to examine each spacecraft you reach.
            </div>
          </div>
        </div>
      )}

      {/* examining banner */}
      {phase === "explore" && (
        <div
          className="absolute inset-x-0 bottom-[clamp(6.5rem,16vh,9rem)] flex justify-center px-4 transition-all duration-500"
          style={{
            opacity: examining && !sheetOpen ? 1 : 0,
            transform: examining && !sheetOpen ? "none" : "translateY(14px)",
          }}
        >
          {examining && (
            <div className="hud-panel pointer-events-auto relative w-full max-w-[540px] overflow-hidden px-5 py-3.5">
              <div
                className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-[var(--suit)] to-transparent"
                style={{ animation: "scan-line 1.6s linear infinite" }}
              />
              <div className="flex items-center justify-between gap-4">
                <div className="min-w-0">
                  <div className="hud-label text-[var(--suit)]">Examining</div>
                  <div className="mt-1 line-clamp-2 font-display text-[13.5px] uppercase leading-snug tracking-[0.1em] text-white">
                    {examining.name}
                  </div>
                  <div className="mt-0.5 truncate font-hud text-[10.5px] tracking-[0.08em] text-[var(--hud-dim)]">
                    {examining.category} · {examining.missions}
                  </div>
                </div>
                <button
                  type="button"
                  className="hud-btn shrink-0 border-[var(--suit)]"
                  onClick={() => openSheet(examining.id)}
                >
                  Read sheet
                </button>
              </div>
              <div className="mt-2 font-sans text-[12px] text-[var(--hud-dim)]">
                Click the paper icon beside it to open its information sheet.
              </div>
            </div>
          )}
        </div>
      )}

      {/* completion */}
      {celebrate && (
        <div className="absolute inset-0 grid place-items-center bg-[rgba(2,4,10,0.45)] px-4">
          <div className="hud-panel pointer-events-auto w-full max-w-[440px] px-7 py-6 text-center animate-rise-in">
            <div className="hud-label text-[var(--suit)]">Survey complete</div>
            <div className="mt-3 font-display text-[18px] uppercase leading-snug tracking-[0.14em] text-white">
              All {tools.length} spacecraft on the {planet.name === "Moon" ? "Moon" : "red planet"} catalogued
            </div>
            <p className="mt-3 text-[14px] text-[var(--hud-dim)]">
              Every data sheet stays in your field log. Ready for {otherWorld}?
            </p>
            <div className="mt-5 flex justify-center gap-2">
              <button type="button" className="hud-btn" onClick={() => setCelebrate(false)}>
                Keep exploring
              </button>
              <button
                type="button"
                className="hud-btn border-[var(--suit)]"
                onClick={() => {
                  setCelebrate(false);
                  returnToOrbit();
                }}
              >
                Return to orbit
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function Kbd({ children }: { children: React.ReactNode }) {
  return <span className="mx-0.5 border border-white/30 px-1.5 py-0.5 text-white">{children}</span>;
}
