import { cn } from "@/lib/utils";

interface PaperIconProps {
  label: string;
  active: boolean;
  discovered: boolean;
  onOpen: () => void;
}

/** Small paper document icon that opens the tool's information sheet. */
export default function PaperIcon({ label, active, discovered, onOpen }: PaperIconProps) {
  return (
    <div className="pointer-events-none flex items-center gap-2" style={{ transform: "translate(34px, -50%)" }}>
      <button
        type="button"
        aria-label={`Open the information sheet for ${label}`}
        onPointerDown={e => e.stopPropagation()}
        onClick={e => {
          e.stopPropagation();
          onOpen();
        }}
        className={cn(
          "pointer-events-auto relative grid place-items-center rounded-full transition-transform duration-300",
          "border bg-[rgba(8,12,22,0.55)] backdrop-blur-md hover:scale-110 focus-visible:outline-2 focus-visible:outline-[var(--suit)]",
          active ? "h-12 w-12 border-[var(--suit)]" : "h-9 w-9 border-white/30",
        )}
        style={active ? { animation: "paper-pulse 1.8s ease-out infinite" } : undefined}
      >
        <svg viewBox="0 0 24 28" className={active ? "h-6 w-6" : "h-[18px] w-[18px]"} aria-hidden>
          <path d="M3 1.5h12.5L21 7v19.5H3z" fill="#f3eee3" stroke="#1d1f24" strokeWidth="1.2" strokeLinejoin="round" />
          <path d="M15.5 1.5V7H21" fill="#d9d1bf" stroke="#1d1f24" strokeWidth="1.2" strokeLinejoin="round" />
          <path d="M6.5 11h11M6.5 14.5h11M6.5 18h8" stroke="#55585f" strokeWidth="1.3" strokeLinecap="round" />
          <circle cx="16.5" cy="21.5" r="2.4" fill="none" stroke="#c4361c" strokeWidth="1.1" />
        </svg>
        {discovered && (
          <span className="absolute -right-1 -top-1 grid h-4 w-4 place-items-center rounded-full bg-[var(--suit)] text-[9px] font-bold text-[#0a0e1a]">
            ✓
          </span>
        )}
      </button>
      <div
        className={cn(
          "whitespace-nowrap font-hud text-[11px] uppercase tracking-[0.16em] text-white transition-opacity duration-300",
          active ? "opacity-100" : "opacity-0",
        )}
        style={{ textShadow: "0 1px 6px rgba(0,0,0,0.9)" }}
      >
        <div className="text-[var(--suit)]">Data sheet</div>
        <div>{label}</div>
      </div>
    </div>
  );
}
