import { useEffect, useRef } from "react";
import { anchors } from "../anchors";
import { placementsFor } from "../data/toolTypes";
import { getToolInfo } from "../data/toolInfo";
import { useExperience } from "../store";
import PaperIcon from "./PaperIcon";

/** Distance (m) within which a tool's paper icon becomes visible. */
const ICON_VISIBLE_DISTANCE = 38;

/** Paper icons that float next to every tool on the surface. */
export default function ToolIconLayer() {
  const planet = useExperience(s => s.planet);
  const phase = useExperience(s => s.phase);
  const examiningId = useExperience(s => s.examiningId);
  const discovered = useExperience(s => (s.planet ? s.discovered[s.planet] : []));
  const openSheet = useExperience(s => s.openSheet);
  const sheetOpen = useExperience(s => !!s.sheetToolId);
  const refs = useRef(new Map<string, HTMLDivElement>());
  const tools = planet ? placementsFor(planet) : [];

  useEffect(() => {
    let raf = 0;
    const tick = () => {
      refs.current.forEach((el, id) => {
        const a = anchors.get(`tool:${id}`);
        const show = !!a && a.visible && a.dist < ICON_VISIBLE_DISTANCE && phase === "explore";
        if (!a || !show) {
          el.style.opacity = "0";
          el.style.pointerEvents = "none";
          return;
        }
        el.style.transform = `translate3d(${a.x.toFixed(1)}px, ${a.y.toFixed(1)}px, 0)`;
        el.style.opacity = String(Math.min(1, (ICON_VISIBLE_DISTANCE - a.dist) / 8));
        el.style.pointerEvents = "auto";
        // nearer icons stack above farther ones
        el.style.zIndex = String(1000 - Math.round(a.dist * 10));
      });
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [phase]);

  if (!planet) return null;

  return (
    <div
      className="pointer-events-none absolute inset-0 z-20 overflow-hidden"
      style={{ visibility: sheetOpen ? "hidden" : "visible" }}
    >
      {tools.map(t => {
        const info = getToolInfo(t.id);
        return (
          <div
            key={t.id}
            ref={el => {
              if (el) refs.current.set(t.id, el);
              else refs.current.delete(t.id);
            }}
            className="absolute left-0 top-0 transition-opacity duration-300"
            style={{ opacity: 0 }}
          >
            <PaperIcon
              label={info?.name ?? t.id}
              active={examiningId === t.id}
              discovered={discovered.includes(t.id)}
              onOpen={() => openSheet(t.id)}
            />
          </div>
        );
      })}
    </div>
  );
}
