import { useEffect, useRef, useState } from "react";
import { input } from "../runtime";

const RADIUS = 52;

export function useIsTouch() {
  const [touch, setTouch] = useState(false);
  useEffect(() => {
    const mq = window.matchMedia("(pointer: coarse)");
    const update = () => setTouch(mq.matches || "ontouchstart" in window);
    update();
    mq.addEventListener("change", update);
    return () => mq.removeEventListener("change", update);
  }, []);
  return touch;
}

export default function TouchControls() {
  const isTouch = useIsTouch();
  const knob = useRef<HTMLDivElement>(null);
  const base = useRef<HTMLDivElement>(null);
  const active = useRef<number | null>(null);

  if (!isTouch) return null;

  const update = (clientX: number, clientY: number) => {
    const rect = base.current?.getBoundingClientRect();
    if (!rect) return;
    let dx = clientX - (rect.left + rect.width / 2);
    let dy = clientY - (rect.top + rect.height / 2);
    const len = Math.hypot(dx, dy);
    if (len > RADIUS) {
      dx = (dx / len) * RADIUS;
      dy = (dy / len) * RADIUS;
    }
    if (knob.current) knob.current.style.transform = `translate(${dx}px, ${dy}px)`;
    input.joy.x = dx / RADIUS;
    input.joy.y = -dy / RADIUS;
    input.lastMoveAt = performance.now();
  };
  const release = (pointerId: number) => {
    if (active.current !== pointerId) return;
    active.current = null;
    input.joy.x = 0;
    input.joy.y = 0;
    if (knob.current) knob.current.style.transform = "translate(0, 0)";
  };

  return (
    <>
      <div
        ref={base}
        className="absolute bottom-[calc(28px+env(safe-area-inset-bottom))] left-6 z-30 grid h-[132px] w-[132px] touch-none place-items-center rounded-full border border-white/25 bg-[rgba(8,12,22,0.35)] backdrop-blur-sm"
        onPointerDown={e => {
          e.stopPropagation();
          if (active.current !== null) return;
          active.current = e.pointerId;
          (e.target as HTMLElement).setPointerCapture(e.pointerId);
          update(e.clientX, e.clientY);
        }}
        onPointerMove={e => {
          if (active.current === e.pointerId) update(e.clientX, e.clientY);
        }}
        onPointerUp={e => release(e.pointerId)}
        onPointerCancel={e => release(e.pointerId)}
        aria-label="Movement joystick"
      >
        <div ref={knob} className="pointer-events-none h-14 w-14 rounded-full border border-[var(--suit)] bg-[rgba(255,95,31,0.25)]" />
      </div>
      <button
        type="button"
        className="absolute bottom-[calc(44px+env(safe-area-inset-bottom))] right-6 z-30 grid h-[72px] w-[72px] touch-none place-items-center rounded-full border border-white/30 bg-[rgba(8,12,22,0.45)] font-hud text-[11px] tracking-[0.18em] text-white backdrop-blur-sm active:border-[var(--suit)]"
        onPointerDown={e => {
          e.stopPropagation();
          input.jumpQueued = true;
        }}
      >
        HOP
      </button>
    </>
  );
}
