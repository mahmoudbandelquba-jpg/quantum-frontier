/** Wordmark: a visor glyph with a reflected star, set beside a wide-tracked logotype. */
export default function Brand({ compact = false }: { compact?: boolean }) {
  return (
    <div className="pointer-events-none flex items-center gap-3 text-[var(--hud)]">
      <svg viewBox="0 0 40 32" className={compact ? "h-5 w-6" : "h-7 w-9"} aria-hidden>
        <rect x="2" y="3" width="36" height="26" rx="12" fill="none" stroke="var(--suit)" strokeWidth="2.6" />
        <rect x="7" y="8" width="26" height="16" rx="8" fill="var(--suit)" opacity="0.92" />
        <path d="M13 11.5l1 2.2 2.3.3-1.7 1.5.5 2.3-2.1-1.2-2.1 1.2.5-2.3-1.7-1.5 2.3-.3z" fill="#fff" />
      </svg>
      <div className={`leading-none ${compact ? "max-sm:hidden" : ""}`}>
        <div
          className={`font-display tracking-[0.42em] ${compact ? "text-[11px]" : "text-[13px] max-sm:text-[11.5px] max-sm:tracking-[0.3em]"}`}
        >
          {compact ? "QUANTUM FRONTIER" : "QUANTUM"}
        </div>
        {!compact && (
          <div className="mt-1.5 font-display text-[13px] tracking-[0.42em] text-[var(--hud)] max-sm:text-[11.5px] max-sm:tracking-[0.3em]">
            FRONTIER
          </div>
        )}
      </div>
    </div>
  );
}
