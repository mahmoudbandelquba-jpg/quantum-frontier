import { useEffect, useRef } from "react";
import type { ToolPlacement } from "../data/toolTypes";
import { player } from "../runtime";
import { useExperience } from "../store";

const WIDTH = 360;
const FOV = 160; // degrees visible across the strip
const CARDINALS: [number, string][] = [
  [0, "N"],
  [45, "NE"],
  [90, "E"],
  [135, "SE"],
  [180, "S"],
  [225, "SW"],
  [270, "W"],
  [315, "NW"],
];

const norm = (d: number) => ((d % 360) + 540) % 360 - 180;

export default function Compass({ tools }: { tools: ToolPlacement[] }) {
  const tickRefs = useRef<(HTMLDivElement | null)[]>([]);
  const toolRefs = useRef<(HTMLDivElement | null)[]>([]);
  const headingRef = useRef<HTMLSpanElement>(null);
  const nextRef = useRef<HTMLSpanElement>(null);
  const planet = useExperience(s => s.planet);
  const discovered = useExperience(s => (s.planet ? s.discovered[s.planet] : []));
  const discoveredRef = useRef(discovered);
  discoveredRef.current = discovered;

  useEffect(() => {
    let raf = 0;
    const tick = () => {
      const heading = (((-player.yaw * 180) / Math.PI) % 360 + 360) % 360;
      if (headingRef.current) headingRef.current.textContent = String(Math.round(heading)).padStart(3, "0");
      CARDINALS.forEach(([deg], i) => {
        const el = tickRefs.current[i];
        if (!el) return;
        const rel = norm(deg - heading);
        const x = (rel / FOV) * WIDTH;
        el.style.transform = `translateX(${x}px)`;
        el.style.opacity = Math.abs(rel) > FOV / 2 ? "0" : String(1 - Math.abs(rel) / (FOV / 2) * 0.6);
      });
      let nearest = Infinity;
      tools.forEach((t, i) => {
        const el = toolRefs.current[i];
        if (!el) return;
        const dx = t.x - player.x;
        const dz = t.z - player.z;
        const bearing = (Math.atan2(dx, -dz) * 180) / Math.PI;
        const rel = norm(bearing - heading);
        const x = THREE_clamp((rel / FOV) * WIDTH, -WIDTH / 2, WIDTH / 2);
        el.style.transform = `translateX(${x}px)`;
        const found = discoveredRef.current.includes(t.id);
        el.dataset["found"] = found ? "1" : "0";
        el.style.opacity = Math.abs(rel) > FOV / 2 ? "0.35" : "1";
        if (!found) nearest = Math.min(nearest, Math.hypot(dx, dz));
      });
      if (nextRef.current) {
        nextRef.current.textContent = Number.isFinite(nearest) ? `NEXT SIGNAL ${Math.round(nearest)} M` : "ALL SIGNALS LOGGED";
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [tools, planet]);

  return (
    <div className="pointer-events-none flex flex-col items-center">
      <div
        className="hud-panel relative h-9 overflow-hidden"
        style={{
          width: WIDTH,
          maskImage: "linear-gradient(90deg, transparent, #000 18%, #000 82%, transparent)",
          WebkitMaskImage: "linear-gradient(90deg, transparent, #000 18%, #000 82%, transparent)",
        }}
      >
        <div className="absolute left-1/2 top-0 h-full w-px bg-[var(--suit)]" />
        {CARDINALS.map(([deg, label], i) => (
          <div
            key={deg}
            ref={el => {
              tickRefs.current[i] = el;
            }}
            className="absolute left-1/2 top-1 -ml-4 w-8 text-center font-hud text-[11px] tracking-[0.1em] text-[var(--hud)]"
          >
            {label}
            <div className="mx-auto mt-0.5 h-1.5 w-px bg-white/40" />
          </div>
        ))}
        {tools.map((t, i) => (
          <div
            key={t.id}
            ref={el => {
              toolRefs.current[i] = el;
            }}
            className="group absolute bottom-1 left-1/2 -ml-[5px] h-[10px] w-[10px] rotate-45 border border-[var(--suit)] bg-[var(--suit)] data-[found=1]:border-white/70 data-[found=1]:bg-transparent"
          />
        ))}
      </div>
      <div className="mt-1.5 flex gap-4 font-hud text-[10px] tracking-[0.2em] text-[var(--hud-dim)]">
        <span>
          HDG <span ref={headingRef} className="text-[var(--hud)]">000</span>
        </span>
        <span ref={nextRef} />
      </div>
    </div>
  );
}

function THREE_clamp(v: number, a: number, b: number) {
  return Math.min(b, Math.max(a, v));
}
