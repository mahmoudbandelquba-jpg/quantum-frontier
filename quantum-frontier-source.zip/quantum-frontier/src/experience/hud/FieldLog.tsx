import { X } from "lucide-react";
import { useEffect } from "react";
import { placementsFor } from "../data/toolTypes";
import { getToolInfo } from "../data/toolInfo";
import { PLANETS } from "../planets";
import { useExperience } from "../store";

export default function FieldLog() {
  const open = useExperience(s => s.logOpen);
  const planet = useExperience(s => s.planet);
  const discovered = useExperience(s => (s.planet ? s.discovered[s.planet] : []));
  const setLogOpen = useExperience(s => s.setLogOpen);
  const openSheet = useExperience(s => s.openSheet);

  useEffect(() => {
    if (!open) return;
    const key = (e: KeyboardEvent) => {
      if (e.code === "Escape") setLogOpen(false);
    };
    window.addEventListener("keydown", key);
    return () => window.removeEventListener("keydown", key);
  }, [open, setLogOpen]);

  if (!planet) return null;
  const tools = placementsFor(planet);

  return (
    <aside
      className="hud-panel absolute bottom-4 right-3 top-[86px] z-40 flex w-[min(340px,calc(100vw-24px))] flex-col transition-all duration-500 sm:right-6"
      style={{
        transform: open ? "translateX(0)" : "translateX(calc(100% + 40px))",
        opacity: open ? 1 : 0,
        pointerEvents: open ? "auto" : "none",
      }}
      aria-hidden={!open}
    >
      <div className="flex items-center justify-between border-b border-white/10 px-5 py-4">
        <div>
          <div className="hud-label">Field log · {PLANETS[planet].name}</div>
          <div className="mt-1 font-display text-[15px] tracking-[0.12em] text-white">
            {discovered.length} / {tools.length} catalogued
          </div>
        </div>
        <button
          type="button"
          onClick={() => setLogOpen(false)}
          className="grid h-8 w-8 place-items-center border border-white/20 text-white hover:border-[var(--suit)]"
          aria-label="Close field log"
        >
          <X className="h-4 w-4" />
        </button>
      </div>
      <ol className="flex-1 space-y-1 overflow-y-auto p-3">
        {tools.map((t, i) => {
          const found = discovered.includes(t.id);
          const info = getToolInfo(t.id);
          return (
            <li key={t.id}>
              <button
                type="button"
                disabled={!found}
                onClick={() => openSheet(t.id)}
                className="flex w-full items-center gap-3 px-3 py-2.5 text-left transition-colors enabled:hover:bg-white/5 disabled:cursor-default"
              >
                <span
                  className={`grid h-7 w-7 shrink-0 place-items-center font-hud text-[10px] ${
                    found ? "bg-[var(--suit)] text-[#0a0e1a]" : "border border-dashed border-white/30 text-white/50"
                  }`}
                >
                  {String(i + 1).padStart(2, "0")}
                </span>
                <span className="min-w-0 flex-1">
                  <span className={`block truncate text-[13.5px] ${found ? "text-white" : "text-white/45"}`}>
                    {found ? info?.name ?? t.id : "Unidentified signal"}
                  </span>
                  <span className="block truncate font-hud text-[10px] uppercase tracking-[0.14em] text-[var(--hud-dim)]">
                    {found ? info?.category ?? "" : "Follow the orange beacons"}
                  </span>
                </span>
                {found && <span className="font-hud text-[10px] tracking-[0.14em] text-[var(--suit)]">SHEET →</span>}
              </button>
            </li>
          );
        })}
      </ol>
    </aside>
  );
}
