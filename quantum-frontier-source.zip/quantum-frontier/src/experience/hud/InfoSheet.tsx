import { X } from "lucide-react";
import { useEffect, useRef } from "react";
import { getToolInfo } from "../data/toolInfo";
import { PLANETS } from "../planets";
import type { SheetPoint } from "../data/toolTypes";
import { useExperience } from "../store";

function PointList({ points }: { points: SheetPoint[] }) {
  return (
    <ul className="mt-2 space-y-3.5 font-paper text-[15px] leading-[1.6]">
      {points.map(p => (
        <li key={p.title} className="flex gap-3">
          <span className="mt-[9px] h-1.5 w-1.5 shrink-0 rotate-45 bg-[var(--stamp)]" />
          <div className="min-w-0">
            <span className="font-semibold">{p.title}</span>
            {p.body && <span>{p.body.startsWith(":") ? p.body : `: ${p.body}`}</span>}
            {p.items && (
              <ul className="mt-1.5 space-y-1.5 border-l border-dashed border-[var(--ink)]/25 pl-3">
                {p.items.map(item => (
                  <li key={item} className="text-[14.5px]">
                    {item}
                  </li>
                ))}
              </ul>
            )}
          </div>
        </li>
      ))}
    </ul>
  );
}

function hostOf(url: string) {
  try {
    return new URL(url).hostname.replace(/^www\./, "");
  } catch {
    return url;
  }
}

/** The paper data sheet that opens from a tool's paper icon. */
export default function InfoSheet() {
  const sheetToolId = useExperience(s => s.sheetToolId);
  const closeSheet = useExperience(s => s.closeSheet);
  const info = sheetToolId ? getToolInfo(sheetToolId) : undefined;
  const closeBtn = useRef<HTMLButtonElement>(null);
  const scroller = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!sheetToolId) return;
    closeBtn.current?.focus({ preventScroll: true });
    scroller.current?.scrollTo({ top: 0 });
    const key = (e: KeyboardEvent) => {
      if (e.code === "Escape") {
        e.preventDefault();
        closeSheet();
      }
    };
    window.addEventListener("keydown", key);
    return () => window.removeEventListener("keydown", key);
  }, [sheetToolId, closeSheet]);

  if (!sheetToolId || !info) return null;
  const planet = PLANETS[info.planet];
  const sheetNo = `${info.planet === "moon" ? "LUN" : "MAR"}-${String(
    Math.abs([...info.id].reduce((a, c) => a * 31 + c.charCodeAt(0), 7)) % 900 + 100,
  )}`;

  return (
    <div
      className="absolute inset-0 z-50 flex items-center justify-center bg-[rgba(2,4,10,0.55)] p-3 backdrop-blur-[3px] sm:p-6"
      onPointerDown={e => {
        if (e.target === e.currentTarget) closeSheet();
      }}
      role="dialog"
      aria-modal="true"
      aria-labelledby="sheet-title"
    >
      <article
        className="paper-sheet relative flex max-h-[min(92vh,900px)] w-full max-w-[760px] flex-col"
        style={{
          animation: "sheet-in 0.55s cubic-bezier(0.2, 0.9, 0.25, 1) both",
          clipPath: "polygon(0 0, calc(100% - 34px) 0, 100% 34px, 100% 100%, 0 100%)",
          userSelect: "text",
        }}
      >
        {/* folded corner */}
        <div
          className="pointer-events-none absolute right-0 top-0 h-[34px] w-[34px]"
          style={{ background: "linear-gradient(225deg, transparent 50%, #d9d1bf 50%)" }}
        />
        <button
          ref={closeBtn}
          type="button"
          onClick={closeSheet}
          className="absolute right-12 top-4 z-10 grid h-9 w-9 place-items-center rounded-full border border-[var(--ink)]/30 text-[var(--ink)] transition-colors hover:bg-[var(--ink)] hover:text-[var(--paper)] focus-visible:outline-2 focus-visible:outline-[var(--stamp)]"
          aria-label="Close information sheet"
        >
          <X className="h-4 w-4" />
        </button>

        <div ref={scroller} className="overflow-y-auto overscroll-contain px-5 pb-6 pt-5 sm:px-9 sm:pb-8 sm:pt-7">
          {/* header */}
          <div className="flex flex-wrap items-center gap-x-4 gap-y-1 pr-16 font-hud text-[10.5px] uppercase tracking-[0.2em] text-[var(--ink-soft)]">
            <span>Field data sheet</span>
            <span>No. {sheetNo}</span>
            <span>
              {planet.name} · {info.site}
            </span>
          </div>
          <div className="paper-rule mt-3" />
          <div className="mt-4 flex flex-wrap items-start justify-between gap-x-4 gap-y-3">
            <div className="min-w-0 flex-[1_1_17rem]">
              <div className="font-hud text-[11px] uppercase tracking-[0.18em] text-[var(--stamp)]">{info.category}</div>
              <h2 id="sheet-title" className="mt-1.5 font-paper text-[clamp(1.6rem,4vw,2.4rem)] font-semibold leading-[1.1]">
                {info.name}
              </h2>
              {info.nickname && (
                <div className="mt-1 font-paper text-[15px] italic text-[var(--ink-soft)]">“{info.nickname}”</div>
              )}
            </div>
            <div className="stamp mt-1 shrink-0 -rotate-6 px-3 py-1.5 text-[11px] max-sm:ml-1">{info.missions.split(",")[0]}</div>
          </div>

          <div className="mt-6 grid gap-6 sm:grid-cols-[minmax(0,1fr)_minmax(0,1.05fr)]">
            {/* photo */}
            <figure className="relative self-start">
              <div className="tape absolute -top-2 left-6 z-10 h-5 w-16 -rotate-6" />
              <div className="tape absolute -top-2 right-6 z-10 h-5 w-16 rotate-6" />
              <div className="bg-white p-2 pb-3 shadow-[0_6px_16px_rgba(0,0,0,0.18)] rotate-[0.8deg]">
                <img
                  src={info.image.url}
                  alt={`Photograph of the ${info.name}`}
                  className="mx-auto block max-h-[340px] min-h-[160px] w-full bg-[#1b1c1f] object-contain"
                  decoding="async"
                />
                <figcaption className="mt-2 font-hud text-[9.5px] uppercase tracking-[0.12em] text-[var(--ink-soft)]">
                  Photo:{" "}
                  {info.image.sourceUrl ? (
                    <a
                      href={info.image.sourceUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="underline decoration-dotted underline-offset-2 hover:text-[var(--stamp)]"
                    >
                      {info.image.credit}
                    </a>
                  ) : (
                    info.image.credit
                  )}
                </figcaption>
              </div>
            </figure>

            {/* quick facts */}
            <div>
              <dl className="space-y-3">
                {[
                  ["Mission", info.missions],
                  ["Agency", info.agency],
                  ["Landed", info.landed],
                  ["Landing site", info.site],
                ].map(([k, v]) => (
                  <div key={k}>
                    <dt className="font-hud text-[10.5px] uppercase tracking-[0.16em] text-[var(--ink-soft)]">{k}</dt>
                    <dd className="mt-0.5 font-paper text-[16px] leading-snug text-[var(--ink)]">{v}</dd>
                  </div>
                ))}
              </dl>
              <div className="mt-4 border-l-2 border-[var(--stamp)] pl-3 font-paper text-[13.5px] italic leading-relaxed text-[var(--ink-soft)]">
                Status: {info.status}
              </div>
            </div>
          </div>

          <section className="mt-7">
            <h3 className="font-hud text-[11px] uppercase tracking-[0.2em] text-[var(--ink-soft)]">What is it?</h3>
            <p className="mt-2 font-paper text-[16px] leading-[1.65]">{info.intro}</p>
          </section>

          <section className="mt-6">
            <h3 className="font-hud text-[11px] uppercase tracking-[0.2em] text-[var(--ink-soft)]">{info.partsTitle}</h3>
            <PointList points={info.parts} />
          </section>

          {info.notes.map(n => (
            <section key={n.title} className="mt-6 bg-[rgba(196,54,28,0.07)] px-4 py-3">
              <h3 className="font-display text-[10.5px] uppercase tracking-[0.2em] text-[var(--stamp)]">{n.title}</h3>
              <p className="mt-1.5 font-paper text-[15px] leading-[1.6]">{n.body}</p>
            </section>
          ))}

          <section className="mt-7">
            <h3 className="font-hud text-[11px] uppercase tracking-[0.2em] text-[var(--ink-soft)]">Why was it left behind?</h3>
            <PointList points={info.whyLeftBehind} />
          </section>

          <div className="mt-6 flex flex-wrap items-end justify-between gap-4 border-t border-dashed border-[var(--ink)]/25 pt-4">
            <div className="font-hud text-[10.5px] leading-relaxed text-[var(--ink-soft)]">
              <div className="uppercase tracking-[0.16em]">Photo source</div>
              <a
                href={info.image.sourceUrl}
                target="_blank"
                rel="noreferrer"
                className="inline-block underline decoration-dotted underline-offset-2 hover:text-[var(--stamp)]"
              >
                {hostOf(info.image.sourceUrl)}
              </a>
            </div>
            <button
              type="button"
              onClick={closeSheet}
              className="border-2 border-[var(--ink)] px-4 py-2 font-hud text-[11px] uppercase tracking-[0.18em] text-[var(--ink)] transition-colors hover:bg-[var(--ink)] hover:text-[var(--paper)]"
            >
              Resume exploring · Esc
            </button>
          </div>
        </div>
      </article>
    </div>
  );
}
