import { useEffect, useRef } from "react";
import { useIsMobile } from "@/hooks/use-mobile";
import { ART } from "../assets";
import { player } from "../runtime";
import type { PlanetId } from "../store";

export type GloveMode = "hidden" | "rest" | "thrust" | "surface";

interface GlovesProps {
  mode: GloveMode;
  /** Which hand reaches toward a hovered destination. */
  reach?: PlanetId | null;
  planet?: PlanetId | null;
}

const OUTER: Record<GloveMode, { left: string; right: string; opacity: number; duration: string }> = {
  hidden: {
    left: "translate3d(-6%, 78%, 0) rotate(-8deg)",
    right: "translate3d(6%, 78%, 0) rotate(8deg)",
    opacity: 0,
    duration: "0.6s",
  },
  rest: {
    left: "translate3d(0, 0, 0)",
    right: "translate3d(0, 0, 0)",
    opacity: 1,
    duration: "1.6s",
  },
  thrust: {
    left: "translate3d(22%, -16%, 0) scale(1.3) rotate(6deg)",
    right: "translate3d(-22%, -16%, 0) scale(1.3) rotate(-6deg)",
    opacity: 0,
    duration: "2.2s",
  },
  surface: {
    left: "translate3d(-4%, 34%, 0) scale(0.92)",
    right: "translate3d(4%, 34%, 0) scale(0.92)",
    opacity: 1,
    duration: "1.2s",
  },
};

/** Phones: larger hands that sit a little higher so they stay in frame. */
const SURFACE_COMPACT = {
  left: "translate3d(-6%, 20%, 0)",
  right: "translate3d(6%, 20%, 0)",
};

const PLANET_FILTER: Record<PlanetId, string> = {
  moon: "brightness(0.92) contrast(1.12) saturate(0.85)",
  mars: "sepia(0.28) saturate(1.15) hue-rotate(-12deg) brightness(0.9) contrast(1.05)",
};

export default function Gloves({ mode, reach = null, planet = null }: GlovesProps) {
  const leftInner = useRef<HTMLDivElement>(null);
  const rightInner = useRef<HTMLDivElement>(null);
  const compact = useIsMobile();
  const cfg = mode === "surface" && compact ? { ...OUTER.surface, ...SURFACE_COMPACT } : OUTER[mode];

  // Surface mode: sway with the walk cycle and reach forward when examining.
  useEffect(() => {
    if (mode !== "surface") {
      if (leftInner.current) leftInner.current.style.transform = "";
      if (rightInner.current) rightInner.current.style.transform = "";
      return;
    }
    let raf = 0;
    const tick = () => {
      const moving = Math.min(1, player.speed / 2.2);
      const ph = player.stepPhase;
      const sway = Math.sin(ph) * 12 * moving;
      const lift = Math.abs(Math.cos(ph)) * 10 * moving;
      const r = player.reach;
      const airborne = player.airborne ? -18 : 0;
      if (leftInner.current) {
        leftInner.current.style.transform = `translate3d(${sway + r * 70}px, ${lift - r * 120 + airborne}px, 0) rotate(${r * 6 - sway * 0.15}deg)`;
      }
      if (rightInner.current) {
        rightInner.current.style.transform = `translate3d(${sway - r * 70}px, ${-lift - r * 120 + airborne}px, 0) rotate(${-r * 6 - sway * 0.15}deg)`;
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [mode]);

  const reachLeft = mode === "rest" && reach === "moon";
  const reachRight = mode === "rest" && reach === "mars";
  const filter = planet ? PLANET_FILTER[planet] : "drop-shadow(0 -10px 40px rgba(120,170,255,0.18))";
  const idle = mode === "rest";

  const base = "pointer-events-none absolute bottom-0 select-none will-change-transform";
  const size = compact ? "w-[min(74vw,46vh)] max-w-none" : "w-[min(58vw,74vh,820px)] max-w-none";
  const leftPos = compact ? "left-[-14%] bottom-[-7%]" : "left-[-9%] bottom-[-17%]";
  const rightPos = compact ? "right-[-14%] bottom-[-6%]" : "right-[-9%] bottom-[-15%]";

  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden>
      <div
        className={`${base} ${leftPos}`}
        style={{
          transform: reachLeft ? "translate3d(7%, -7%, 0) rotate(-2deg)" : cfg.left,
          opacity: cfg.opacity,
          transition: `transform ${reachLeft ? "0.8s" : cfg.duration} cubic-bezier(0.22, 0.9, 0.24, 1) ${mode === "rest" && !reach ? "0.15s" : "0s"}, opacity ${cfg.duration} ease ${mode === "rest" ? "0.15s" : "0s"}`,
        }}
      >
        <div ref={leftInner} style={idle ? { animation: "float-slow 6s ease-in-out infinite" } : undefined}>
          <img src={ART.gloveLeft} alt="" draggable={false} className={size} style={{ filter }} />
        </div>
      </div>
      <div
        className={`${base} ${rightPos}`}
        style={{
          transform: reachRight ? "translate3d(-7%, -7%, 0) rotate(2deg)" : cfg.right,
          opacity: cfg.opacity,
          transition: `transform ${reachRight ? "0.8s" : cfg.duration} cubic-bezier(0.22, 0.9, 0.24, 1) ${mode === "rest" && !reach ? "0.35s" : "0s"}, opacity ${cfg.duration} ease ${mode === "rest" ? "0.35s" : "0s"}`,
        }}
      >
        <div ref={rightInner} style={idle ? { animation: "float-slow-alt 7s ease-in-out infinite" } : undefined}>
          <img src={ART.gloveRight} alt="" draggable={false} className={size} style={{ filter }} />
        </div>
      </div>
    </div>
  );
}
