import { useEffect, useState } from "react";
import type { PlanetId } from "../store";

let suitSealedAt: number | null = null;

function useMissionElapsed(active: boolean) {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    if (!active) return;
    if (suitSealedAt === null) suitSealedAt = Date.now();
    const id = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(id);
  }, [active]);
  const secs = suitSealedAt ? Math.max(0, Math.floor((now - suitSealedAt) / 1000)) : 0;
  const h = String(Math.floor(secs / 3600)).padStart(2, "0");
  const m = String(Math.floor((secs % 3600) / 60)).padStart(2, "0");
  const s = String(secs % 60).padStart(2, "0");
  return `${h}:${m}:${s}`;
}

interface VisorProps {
  sealed: boolean;
  planet?: PlanetId | null;
}

/** Helmet visor: edge vignette, glass reflection and thin HUD framing. */
export default function Visor({ sealed, planet = null }: VisorProps) {
  const tint =
    planet === "mars"
      ? "rgba(60, 22, 8, 0.25)"
      : planet === "moon"
        ? "rgba(8, 14, 30, 0.18)"
        : "rgba(10, 20, 45, 0.12)";
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden>
      <div
        className="absolute inset-0"
        style={{
          transform: sealed ? "translateY(0)" : "translateY(-105%)",
          transition: "transform 1.1s cubic-bezier(0.65, 0, 0.35, 1)",
        }}
      >
        {/* glass tint */}
        <div className="absolute inset-0" style={{ background: tint }} />
        {/* helmet rim vignette */}
        <div
          className="absolute inset-[-2%]"
          style={{
            background:
              "radial-gradient(ellipse 78% 74% at 50% 46%, transparent 58%, rgba(0,0,0,0.38) 76%, rgba(0,0,0,0.88) 92%, #000 100%)",
          }}
        />
        {/* curved glass reflection */}
        <div
          className="absolute -left-[10%] -top-[34%] h-[72%] w-[120%] rounded-[50%]"
          style={{
            background: "radial-gradient(ellipse 60% 40% at 50% 92%, rgba(255,255,255,0.045), transparent 70%)",
          }}
        />
        {sealed && (
          <div
            className="absolute top-0 h-full w-[18%]"
            style={{
              background: "linear-gradient(90deg, transparent, rgba(255,255,255,0.12), transparent)",
              animation: "visor-glint 2.4s 0.9s ease-out both",
            }}
          />
        )}
        {/* HUD corner brackets */}
        <svg className="absolute inset-0 h-full w-full" preserveAspectRatio="none" viewBox="0 0 100 100">
          <g stroke="rgba(234,242,255,0.28)" strokeWidth="0.12" fill="none" vectorEffect="non-scaling-stroke">
            <path d="M6 16 V9 H13" vectorEffect="non-scaling-stroke" />
            <path d="M94 16 V9 H87" vectorEffect="non-scaling-stroke" />
            <path d="M6 84 V91 H13" vectorEffect="non-scaling-stroke" />
            <path d="M94 84 V91 H87" vectorEffect="non-scaling-stroke" />
          </g>
        </svg>
      </div>
    </div>
  );
}

/** Life-support readouts shown inside the helmet once the suit is sealed. */
export function SuitReadouts({ visible, className = "" }: { visible: boolean; className?: string }) {
  const met = useMissionElapsed(visible);
  if (!visible) return null;
  const rows: [string, string][] = [
    ["O₂ PRI", "100%"],
    ["SUIT", "4.3 PSI"],
    ["TEMP", "21.4 °C"],
    ["MET", met],
  ];
  return (
    <div className={`pointer-events-none font-hud text-[10px] tracking-[0.16em] text-[var(--hud-dim)] ${className}`}>
      {rows.map(([k, v]) => (
        <div key={k} className="flex justify-between gap-6">
          <span>{k}</span>
          <span className="text-[var(--hud)]">{v}</span>
        </div>
      ))}
      <div className="mt-1 flex items-center gap-2">
        <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-blink" />
        <span>COMM LINK</span>
      </div>
    </div>
  );
}
