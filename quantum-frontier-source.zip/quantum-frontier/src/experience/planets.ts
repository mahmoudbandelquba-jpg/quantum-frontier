import type { PlanetId } from "./store";
import { TEXTURES } from "./assets";

export interface PlanetConfig {
  id: PlanetId;
  name: string;
  site: string;
  /** Surface gravity in m/s². */
  gravity: number;
  walkSpeed: number;
  jumpVelocity: number;
  /** How quickly the walker reaches target speed (higher = snappier). */
  traction: number;
  stats: { label: string; value: string }[];
  distanceKm: number;
  groundTexture: string;
  groundColors: [string, string, string];
  rockColor: string;
  sky: "space" | "mars";
  background: string;
  fog: { color: string; density: number } | null;
  sunDirection: [number, number, number];
  sunColor: string;
  sunIntensity: number;
  ambient: { color: string; intensity: number };
  hemi: { sky: string; ground: string; intensity: number };
  flashColor: string;
  dustColor: string;
}

export const PLANETS: Record<PlanetId, PlanetConfig> = {
  moon: {
    id: "moon",
    name: "Moon",
    site: "Lunar Heritage Sites",
    gravity: 1.62,
    walkSpeed: 3.1,
    jumpVelocity: 2.7,
    traction: 3.2,
    stats: [
      { label: "Gravity", value: "1.62 m/s² · 0.17 g" },
      { label: "Atmosphere", value: "Near vacuum" },
      { label: "Surface temp", value: "−173 to 127 °C" },
      { label: "Day length", value: "29.5 Earth days" },
    ],
    distanceKm: 384400,
    groundTexture: TEXTURES.moonGround,
    groundColors: ["#b4b2ad", "#d4d1ca", "#7a7874"],
    rockColor: "#8e8c87",
    sky: "space",
    background: "#000000",
    fog: null,
    sunDirection: [-0.74, 0.42, 0.2],
    sunColor: "#fffaf0",
    sunIntensity: 4.2,
    ambient: { color: "#9aa6c0", intensity: 0.14 },
    hemi: { sky: "#5b6c93", ground: "#3a3a3a", intensity: 0.34 },
    flashColor: "#f4f6ff",
    dustColor: "#b9b7b1",
  },
  mars: {
    id: "mars",
    name: "Mars",
    site: "Martian Heritage Sites",
    gravity: 3.71,
    walkSpeed: 3.6,
    jumpVelocity: 3.1,
    traction: 5.5,
    stats: [
      { label: "Gravity", value: "3.71 m/s² · 0.38 g" },
      { label: "Atmosphere", value: "95% CO₂ · ~0.6 kPa" },
      { label: "Surface temp", value: "−153 to 20 °C" },
      { label: "Day length", value: "1 sol · 24 h 39 min" },
    ],
    distanceKm: 225000000,
    groundTexture: TEXTURES.marsGround,
    groundColors: ["#c9a58a", "#e0bea0", "#94705a"],
    rockColor: "#5e3a2a",
    sky: "mars",
    background: "#c99a72",
    fog: { color: "#c99a72", density: 0.0062 },
    sunDirection: [0.62, 0.58, 0.32],
    sunColor: "#ffe7cc",
    sunIntensity: 2.4,
    ambient: { color: "#d9a27a", intensity: 0.35 },
    hemi: { sky: "#e0b48c", ground: "#5a2e1c", intensity: 0.6 },
    flashColor: "#e5874f",
    dustColor: "#c9875a",
  },
};
