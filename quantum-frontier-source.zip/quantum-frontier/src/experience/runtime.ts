/**
 * Per-frame mutable state shared between the 3D loop and DOM overlays
 * (compass, gloves, altimeter). Kept outside React to avoid re-rendering
 * every frame.
 */
export const player = {
  x: 0,
  z: 0,
  /** Feet height in world units. */
  y: 0,
  yaw: 0,
  pitch: 0,
  /** Horizontal speed (m/s). */
  speed: 0,
  /** Walk-cycle phase in radians. */
  stepPhase: 0,
  /** Height above ground during the landing descent (m). */
  altitude: 0,
  /** 0..1 how far the gloves reach forward (examining). */
  reach: 0,
  airborne: false,
};

export const input = {
  keys: new Set<string>(),
  /** Virtual joystick, x = strafe (-1..1), y = forward (-1..1). */
  joy: { x: 0, y: 0 },
  lookDX: 0,
  lookDY: 0,
  jumpQueued: false,
  lastMoveAt: 0,
};

export function resetInput() {
  input.keys.clear();
  input.joy.x = 0;
  input.joy.y = 0;
  input.lookDX = 0;
  input.lookDY = 0;
  input.jumpQueued = false;
}

if (import.meta.env.DEV && typeof window !== "undefined") {
  // Dev-only handle for automated walkthrough checks.
  (window as unknown as { __rt: { player: typeof player } }).__rt = { player };
}
