import { create } from "zustand";

export type Phase =
  | "intro" // orbital opening, waiting for the first click
  | "suiting" // helmet seals, gloves rise, HUD boots
  | "choose" // Moon or Mars
  | "jumping" // leaving orbit toward the chosen world
  | "landing" // descent onto the surface
  | "explore"; // walking on the surface

export type PlanetId = "moon" | "mars";

interface ExperienceState {
  phase: Phase;
  planet: PlanetId | null;
  hoverPlanet: PlanetId | null;
  discovered: Record<PlanetId, string[]>;
  /** Tool the astronaut has stopped to examine (null when walking freely). */
  examiningId: string | null;
  /** Tool whose paper data sheet is open. */
  sheetToolId: string | null;
  logOpen: boolean;
  /** Increments whenever a fresh landing should start. */
  landingKey: number;

  wearSuit: () => void;
  finishSuiting: () => void;
  setHoverPlanet: (p: PlanetId | null) => void;
  jumpTo: (p: PlanetId) => void;
  startLanding: () => void;
  touchdown: () => void;
  examine: (toolId: string) => void;
  stopExamining: () => void;
  openSheet: (toolId: string) => void;
  closeSheet: () => void;
  setLogOpen: (open: boolean) => void;
  returnToOrbit: () => void;
}

export const useExperience = create<ExperienceState>((set, get) => ({
  phase: "intro",
  planet: null,
  hoverPlanet: null,
  discovered: { moon: [], mars: [] },
  examiningId: null,
  sheetToolId: null,
  logOpen: false,
  landingKey: 0,

  wearSuit: () => {
    if (get().phase === "intro") set({ phase: "suiting" });
  },
  finishSuiting: () => {
    if (get().phase === "suiting") set({ phase: "choose" });
  },
  setHoverPlanet: p => set({ hoverPlanet: p }),
  jumpTo: p => {
    if (get().phase !== "choose") return;
    set({ phase: "jumping", planet: p, hoverPlanet: p });
  },
  startLanding: () => {
    if (get().phase !== "jumping") return;
    set(s => ({
      phase: "landing",
      examiningId: null,
      sheetToolId: null,
      logOpen: false,
      landingKey: s.landingKey + 1,
    }));
  },
  touchdown: () => {
    if (get().phase === "landing") set({ phase: "explore" });
  },
  examine: toolId =>
    set(s => {
      const planet = s.planet;
      if (!planet || s.phase !== "explore") return {};
      const list = s.discovered[planet];
      return {
        examiningId: toolId,
        discovered: list.includes(toolId)
          ? s.discovered
          : { ...s.discovered, [planet]: [...list, toolId] },
      };
    }),
  stopExamining: () => set({ examiningId: null }),
  openSheet: toolId =>
    set(s => {
      const planet = s.planet;
      // Sheets belong to surface exploration; ignore requests during descent or in orbit.
      if (!planet || s.phase !== "explore") return {};
      const list = s.discovered[planet];
      return {
        sheetToolId: toolId,
        logOpen: false,
        discovered: list.includes(toolId)
          ? s.discovered
          : { ...s.discovered, [planet]: [...list, toolId] },
      };
    }),
  closeSheet: () => set({ sheetToolId: null }),
  setLogOpen: open => set({ logOpen: open }),
  returnToOrbit: () =>
    set({
      phase: "choose",
      planet: null,
      hoverPlanet: null,
      examiningId: null,
      sheetToolId: null,
      logOpen: false,
    }),
}));

if (import.meta.env.DEV && typeof window !== "undefined") {
  // Dev-only handle for automated walkthrough checks.
  (window as unknown as { __exp: typeof useExperience }).__exp = useExperience;
}
